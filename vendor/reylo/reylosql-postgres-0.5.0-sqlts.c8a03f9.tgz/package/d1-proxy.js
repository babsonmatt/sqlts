// src/d1-proxy.ts
import { pathToFileURL } from "node:url";
var send = (message) => process.send?.(message);
var [wrangler, dir] = process.argv.slice(2);
process.chdir(dir);
var { getPlatformProxy } = await import(pathToFileURL(wrangler).href);
var proxy = await getPlatformProxy({ persist: false, remoteBindings: false });
var isD1 = (v) => typeof v?.prepare === "function" && typeof v.batch === "function";
var db = Object.values(proxy.env).find(isD1);
send({ kind: "ready", d1: db !== void 0 });
async function replay(d1, ddl) {
  const { results } = await d1.prepare("select type, name from sqlite_schema where type in ('view', 'table') and substr(name, 1, 7) <> 'sqlite_' and substr(name, 1, 4) <> '_cf_' order by type = 'table', rowid").all();
  for (const { type, name } of results) await d1.prepare(`drop ${type} if exists "${name.replaceAll('"', '""')}"`).run().catch(() => {
  });
  for (const statement of ddl) await d1.prepare(statement).run().catch(() => {
  });
}
async function handle(message) {
  if (message.kind === "close" || !db) {
    await proxy.dispose().catch(() => {
    });
    process.exit(0);
  }
  if (message.kind === "schema") {
    await replay(db, message.ddl).catch(() => {
    });
  } else if (message.kind === "explain") {
    try {
      await db.prepare(`explain ${message.sql}`).bind(...Array.from({ length: message.params }, () => null)).all();
      send({ kind: "explain", id: message.id });
    } catch (e) {
      send({ kind: "explain", id: message.id, error: e.message });
    }
  }
}
var queue = Promise.resolve();
process.on("message", (message) => {
  queue = queue.then(() => handle(message));
});
process.on("disconnect", () => {
  void proxy.dispose().finally(() => process.exit(0));
});
