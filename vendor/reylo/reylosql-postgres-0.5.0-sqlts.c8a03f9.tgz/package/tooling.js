// src/analyze.ts
import { existsSync as existsSync3, mkdirSync, readdirSync, readFileSync as readFileSync4, renameSync, rmSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { join as join4 } from "node:path";

// src/engine.ts
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { pathToFileURL } from "node:url";

// src/connection.ts
var UNREACHABLE = /* @__PURE__ */ Symbol.for("reylo.unreachable");
var NOT_MYSQL = /* @__PURE__ */ Symbol.for("reylo.not-mysql");
var Unreachable = class extends Error {
  [UNREACHABLE] = true;
  constructor(cause) {
    super(reason(cause), { cause });
  }
  static [Symbol.hasInstance](value) {
    return value?.[UNREACHABLE] === true;
  }
};
function refusedLogin(e) {
  const err = e?.cause ?? e;
  return err?.code === "28P01" || err?.code === "28000" || err?.code === "ER_ACCESS_DENIED_ERROR" || err?.errno === 1045;
}
function reason(e) {
  const err = e;
  return err?.message || err?.errors?.map((x) => x.message).filter(Boolean).join("; ") || err?.code || String(e);
}
var NotMysql = class extends Error {
  [NOT_MYSQL] = true;
  server;
  constructor(server) {
    super(`the server is ${server}, not MySQL`);
    this.server = server;
  }
  static [Symbol.hasInstance](value) {
    return value?.[NOT_MYSQL] === true;
  }
};

// src/engine-core.ts
var EngineCore = class {
  #memory;
  #alloc;
  #free;
  #call;
  constructor(instance) {
    const e = instance.exports;
    this.#memory = e.memory;
    this.#alloc = e.reylo_alloc;
    this.#free = e.reylo_free;
    this.#call = e.reylo_call;
  }
  call(request) {
    const bytes = new TextEncoder().encode(JSON.stringify(request));
    const ptr = this.#alloc(bytes.length);
    new Uint8Array(this.#memory.buffer, ptr, bytes.length).set(bytes);
    const out2 = this.#call(ptr, bytes.length);
    this.#free(ptr, bytes.length);
    const len = new DataView(this.#memory.buffer).getUint32(out2, true);
    const text = new TextDecoder().decode(new Uint8Array(this.#memory.buffer, out2 + 4, len));
    this.#free(out2, len + 4);
    return JSON.parse(text);
  }
  lex(sql, dialect) {
    const r = this.call({ op: "lex", sql, dialect });
    if (r.status !== "lexed") throw new Error(r.status === "error" ? r.message : `unexpected ${r.status}`);
    return r.lexed;
  }
  /** Analyze one statement, fulfilling the engine's needs through `io` until it answers. */
  async analyze(sql, dialect, io, cache = new AnswerCache()) {
    const answers = {};
    for (let round = 0; round < 16; round++) {
      const r = this.call({ op: "analyze", sql, dialect, answers });
      if (r.status === "analysis") return r.analysis;
      if (r.status !== "need") throw new Error(r.status === "error" ? r.message : `unexpected ${r.status}`);
      await Promise.all(r.needs.map(async (need) => {
        answers[need.id] = await cache.get(need, () => fulfil(need, io));
      }));
    }
    throw new Error("the analysis engine did not converge");
  }
};
async function fulfil(need, io) {
  try {
    if (need.kind === "describe") {
      const d = await io.describe(need.sql);
      if ("kind" in d) return { mysql: { columns: d.columns, params: d.params } };
      return { describe: { params: d.params.map((p) => p.oid), columns: d.columns } };
    }
    return { rows: await io.query(need.sql, need.params) };
  } catch (e) {
    if (e instanceof Unreachable) throw e;
    const err = e;
    const error = { message: err.message };
    if (err.code) error.code = err.code;
    if (err.position !== void 0) error.position = Number(err.position);
    return { error };
  }
}
var AnswerCache = class {
  #entries = /* @__PURE__ */ new Map();
  #ttl;
  constructor(ttl = { session: 6e4, statement: 5e3 }) {
    this.#ttl = ttl;
  }
  async get(need, fetch) {
    const ttl = need.kind === "query" && need.scope === "session" ? this.#ttl.session : this.#ttl.statement;
    const hit = this.#entries.get(need.id);
    if (hit && Date.now() - hit.at < ttl) return hit.answer;
    const answer = await fetch();
    if (!("error" in answer)) this.#entries.set(need.id, { at: Date.now(), answer });
    return answer;
  }
  clear() {
    this.#entries.clear();
  }
};

// src/engine.ts
var ENGINE_PACKAGES = { postgres: "@reylosql/postgres", sqlite: "@reylosql/sqlite", mysql: "@reylosql/mysql" };
var REYLO_VERSION = (() => {
  for (const at of ["./package.json", "../package.json"]) {
    try {
      return JSON.parse(readFileSync(new URL(at, import.meta.url), "utf8")).version;
    } catch {
    }
  }
  throw new Error("reylo's build steps cannot find the package.json of their own package");
})();
var MissingEngine = class _MissingEngine extends Error {
  constructor(message) {
    super(message);
    this.name = "MissingEngine";
  }
  /** No engine of `dialect` where the project or reylo finds packages. */
  static of(dialect) {
    const pkg = ENGINE_PACKAGES[dialect];
    return new _MissingEngine(`${dialect} statements need ${pkg}: npm install -D ${pkg}`);
  }
  /** No engine at all, so not even the project file can be read. */
  static none() {
    return new _MissingEngine(`reylo reads the project file with a database's engine, and none is installed: npm install -D @reylosql/postgres, @reylosql/mysql or @reylosql/sqlite, the one for your database`);
  }
};
function enginePath(dialect, projectDir, from = import.meta.url) {
  for (const base of [join(projectDir, "package.json"), from]) {
    try {
      return createRequire(base).resolve(`${ENGINE_PACKAGES[dialect]}/engine.wasm`);
    } catch {
    }
  }
  return void 0;
}
function describer(dialect, projectDir, from = import.meta.url) {
  for (const base of [join(projectDir, "package.json"), from]) {
    let path;
    try {
      path = createRequire(base).resolve(`${ENGINE_PACKAGES[dialect]}/describe`);
    } catch {
      continue;
    }
    return import(pathToFileURL(path).href);
  }
  return Promise.reject(MissingEngine.of(dialect));
}
var engines = /* @__PURE__ */ new Map();
function engine(dialect, projectDir, from) {
  const path = enginePath(dialect, projectDir, from);
  if (!path) return Promise.reject(MissingEngine.of(dialect));
  let loading = engines.get(path);
  if (!loading) {
    loading = (async () => {
      const pkg = ENGINE_PACKAGES[dialect];
      let version;
      try {
        version = JSON.parse(readFileSync(join(dirname(path), "package.json"), "utf8")).version;
      } catch {
      }
      if (version !== REYLO_VERSION) {
        throw new MissingEngine(`reylo ${REYLO_VERSION} runs with ${pkg} ${REYLO_VERSION}, and the one installed is ${version ?? "of no version"} (${dirname(path)}): npm install -D ${pkg}@${REYLO_VERSION}`);
      }
      const loaded = await Engine.load(path);
      const ping = loaded.call({ op: "ping" });
      if (ping.status !== "ok" || ping.database !== dialect) {
        const reads = ping.status === "ok" && ping.database ? `${ping.database} statements` : "no one database's statements";
        throw new MissingEngine(`${pkg} (${dirname(path)}) carries an engine that reads ${reads}, not ${dialect} ones: npm install -D ${pkg}@${REYLO_VERSION}`);
      }
      return loaded;
    })();
    loading.catch(() => engines.delete(path));
    engines.set(path, loading);
  }
  return loading;
}
async function anyEngine(projectDir, from) {
  let failed;
  for (const dialect of ["postgres", "mysql", "sqlite"]) {
    if (!enginePath(dialect, projectDir, from)) continue;
    try {
      return await engine(dialect, projectDir, from);
    } catch (e) {
      failed ??= e instanceof MissingEngine ? e : new MissingEngine(e.message);
    }
  }
  return failed ?? MissingEngine.none();
}
var WA = globalThis.WebAssembly;
var WASI_WARNING = "WASI is an experimental feature and might change at any time";
function loadWasi() {
  const emitWarning = process.emitWarning;
  process.emitWarning = function(warning, ...rest) {
    const message = typeof warning === "string" ? warning : warning.message;
    const type = typeof warning === "string" ? typeof rest[0] === "string" ? rest[0] : rest[0]?.type : warning.name;
    if (message === WASI_WARNING && type === "ExperimentalWarning") return;
    return emitWarning.call(this, warning, ...rest);
  };
  try {
    return process.getBuiltinModule("node:wasi");
  } finally {
    process.emitWarning = emitWarning;
  }
}
var Engine = class _Engine extends EngineCore {
  static async load(path) {
    const module = await WA.compile(readFileSync(path));
    const { WASI } = loadWasi();
    const wasi = new WASI({ version: "preview1", args: ["reylo-engine"], env: {} });
    const bun = typeof wasi.getImportObject !== "function";
    let instance;
    const random_get = (ptr, len) => {
      const memory = instance.exports.memory;
      for (let at = 0; at < len; at += 65536) crypto.getRandomValues(new Uint8Array(memory.buffer, ptr + at, Math.min(65536, len - at)));
      return 0;
    };
    instance = await WA.instantiate(module, bun ? { wasi_snapshot_preview1: { ...wasi.wasiImport, random_get } } : wasi.getImportObject());
    if (bun) wasi.start(instance);
    else wasi.initialize(instance);
    return new _Engine(instance);
  }
};

// src/project.ts
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync as readFileSync2 } from "node:fs";
import { createRequire as createRequire2 } from "node:module";
import { dirname as dirname2, isAbsolute, join as join2, relative, resolve, sep } from "node:path";
var PROJECT_FILE = ".reylo.yaml";
var PROJECT_FILES = [PROJECT_FILE, ".reylo.yml"];
var DEFAULT_ENV_FILES = [".env.local", ".env"];
function packageDir(from) {
  for (let dir = resolve(from); ; dir = dirname2(dir)) {
    if (existsSync(join2(dir, "package.json"))) return dir;
    if (dirname2(dir) === dir) return resolve(from);
  }
}
function sourceName(path, env = process.env) {
  const dir = dirname2(path);
  const file = findProjectFile(dir, env);
  return relative(file ? dirname2(file) : packageDir(dir), path).split(sep).join("/");
}
function findProjectFile(from, env = process.env) {
  if (env.REYLO_CONFIG) return resolve(env.REYLO_CONFIG);
  const dir = packageDir(from);
  return PROJECT_FILES.map((name) => join2(dir, name)).find((path) => existsSync(path));
}
function installedIn(root, dialect) {
  try {
    createRequire2(join2(root, "package.json")).resolve(`${ENGINE_PACKAGES[dialect]}/engine.wasm`);
    return true;
  } catch {
    return false;
  }
}
function installedEngines(root) {
  const dialects = Object.keys(ENGINE_PACKAGES);
  const own = dialects.filter((d) => installedIn(root, d));
  return own.length ? own : dialects.filter((d) => enginePath(d, root));
}
function dialectOf(url) {
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(url)?.[1]?.toLowerCase();
  if (scheme === "postgres" || scheme === "postgresql") return "postgres";
  if (scheme === "mysql" || scheme === "mariadb") return "mysql";
  if (scheme === "file" || scheme === "sqlite") return "sqlite";
  return void 0;
}
function readEnvFile(path) {
  if (!existsSync(path)) return {};
  const out2 = {};
  for (const line2 of readFileSync2(path, "utf8").split("\n")) {
    const m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line2);
    if (m) out2[m[1]] = m[2].replace(/^(["'])(.*)\1$/, "$2");
  }
  return out2;
}
function place(text, offset) {
  const before = Buffer.from(text, "utf8").subarray(0, offset).toString("utf8");
  const lines = before.split("\n");
  return `${lines.length}:${lines.at(-1).length + 1}`;
}
var TYPES_KEY = /^types[ \t]*:/m;
var COMMAND_TIMEOUT_MS = 12e4;
var FAILED_COMMAND_TTL = 6e4;
function urlParts(written) {
  const parts = [];
  let text = "";
  for (let i = 0; i < written.length; ) {
    if (written[i] !== "$" || written[i + 1] !== "(") {
      text += written[i++];
      continue;
    }
    let depth = 1;
    let quote;
    let j = i + 2;
    for (; j < written.length && depth > 0; j++) {
      const c = written[j];
      if (quote) {
        if (c === quote) quote = void 0;
        else if (c === "\\" && quote === '"') j++;
      } else if (c === "'" || c === '"') quote = c;
      else if (c === "\\") j++;
      else if (c === "(") depth++;
      else if (c === ")") depth--;
    }
    if (depth > 0) return { open: i };
    if (text) parts.push({ text });
    text = "";
    parts.push({ command: written.slice(i + 2, j - 1) });
    i = j;
  }
  if (text) parts.push({ text });
  return parts;
}
function inUserinfo(parts) {
  let skeleton = "";
  const placed = /* @__PURE__ */ new Map();
  for (const part of parts) {
    if ("text" in part) skeleton += part.text;
    else {
      placed.set(skeleton.length, part);
      skeleton += "\0";
    }
  }
  const inside = /* @__PURE__ */ new Set();
  const scheme = skeleton.indexOf("://");
  if (scheme < 0) return inside;
  const start = scheme + 3;
  const ends = ["/", "?", "#"].map((d) => skeleton.indexOf(d, start)).filter((k) => k >= 0);
  const authorityEnd = Math.min(skeleton.length, ...ends);
  const userinfoEnd = skeleton.lastIndexOf("@", authorityEnd - 1);
  for (const [at, part] of placed) if (at >= start && at < userinfoEnd) inside.add(part);
  return inside;
}
var commandOutputs = /* @__PURE__ */ new Map();
function commandOutput(command, cwd, env, fresh) {
  const key = `${cwd}\0${command}`;
  const kept = commandOutputs.get(key);
  if (!fresh && kept && ("value" in kept || Date.now() - kept.at < FAILED_COMMAND_TTL)) return kept;
  const run = spawnSync(command, { shell: true, cwd, env, encoding: "utf8", timeout: COMMAND_TIMEOUT_MS, stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
  const said = run.stderr?.split(/\r?\n/).map((line2) => line2.trim()).find(Boolean)?.slice(0, 300);
  let outcome;
  if (run.error) {
    const timedOut = run.error.code === "ETIMEDOUT";
    outcome = { error: timedOut ? `which did not finish within ${COMMAND_TIMEOUT_MS / 1e3} s` : `which could not start: ${run.error.message}` };
  } else if (run.status !== 0) {
    outcome = { error: `which ${run.status === null ? `ended on ${run.signal}` : `exited with code ${run.status}`}${said ? `: ${said}` : ""}` };
  } else {
    const value = run.stdout.replace(/(\r?\n)+$/, "");
    outcome = value ? { value } : { error: "which printed nothing" };
  }
  commandOutputs.set(key, "value" in outcome ? outcome : { ...outcome, at: Date.now() });
  return outcome;
}
function resolveProject(engine2, projectDir, env = process.env) {
  const file = findProjectFile(projectDir, env);
  const root = file ? dirname2(file) : packageDir(projectDir);
  const shown2 = (path) => isAbsolute(path) ? relative(projectDir, path) || path : path;
  let config = {};
  let error;
  if (file) {
    let text;
    try {
      text = readFileSync2(file, "utf8");
    } catch (e) {
      error = `Cannot read ${shown2(file)}: ${e.message}`;
    }
    const types = text === void 0 ? null : TYPES_KEY.exec(text);
    if (types) {
      error = `${shown2(file)}:${place(text, Buffer.byteLength(text.slice(0, types.index)))}: types: the types section was removed on 2026-10-20. Reylo now gives every value one type on every driver, whatever the driver's settings: a 64-bit integer is a BigInt, a decimal its exact text, a timestamptz its ISO 8601 text in UTC, a date and a timestamp their text, JSON parsed and binary data a Uint8Array. Delete the section.`;
    } else if (text !== void 0) {
      if (engine2 instanceof MissingEngine) error = `${shown2(file)}: ${engine2.message}`;
      else {
        const r = engine2.call({ op: "config", text });
        if (r.status === "config") config = r.config;
        else if (r.status === "configError") error = `${shown2(file)}:${place(text, r.error.start)}: ${r.error.message}`;
        else error = `${shown2(file)}: ${r.status === "error" ? r.message : `unexpected ${r.status}`}`;
      }
    }
  }
  const both = PROJECT_FILES.map((name) => join2(root, name));
  if (!env.REYLO_CONFIG && both.every((path) => existsSync(path))) error = `${both.map(shown2).join(" and ")} are both project files; keep one.`;
  const envFiles = (config.env ?? DEFAULT_ENV_FILES).map((f) => resolve(root, f));
  const lookup = (name) => {
    if (env[name] !== void 0) return { value: env[name], source: `${name} in the environment` };
    for (const path of envFiles) {
      const value = readEnvFile(path)[name];
      if (value !== void 0) return { value, source: `${name} in ${shown2(path)}` };
    }
    return void 0;
  };
  let url;
  let urlSource = "DATABASE_URL";
  const urlAlone = config.url !== void 0 && config.direct_url === void 0;
  const notice = urlAlone ? `${shown2(file)}: Reylo does not read url; set direct_url to the dev database Reylo reads your types from (it uses DATABASE_URL meanwhile)` : void 0;
  const missingUrl = urlAlone ? `No database URL: ${shown2(file)} sets url, which Reylo does not read; set direct_url there, or DATABASE_URL in the environment, .env.local or .env.` : `No database URL: set DATABASE_URL in the environment, .env.local or .env, or "direct_url" in ${file ? shown2(file) : PROJECT_FILE}.`;
  const written = config.direct_url;
  let refreshUrl;
  if (written !== void 0) {
    const missing = [];
    const sources = [];
    const parts = urlParts(written);
    urlSource = `"direct_url" in ${shown2(file)}`;
    if ("open" in parts) {
      error ??= `${shown2(file)}: "direct_url" opens $( at column ${parts.open + 1} and never closes it.`;
    } else {
      const texts = parts.map(
        (part) => "text" in part ? part.text.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (_, name) => {
          const hit = lookup(name);
          if (!hit) missing.push(name);
          else sources.push(hit.source);
          return hit?.value ?? "";
        }) : void 0
      );
      urlSource += sources.length ? `, ${sources.join(", ")}` : "";
      if (missing.length) {
        error ??= `${shown2(file)}: "direct_url" names ${missing.map((m) => `\${${m}}`).join(", ")}, which neither the environment nor ${envFiles.map(shown2).join(" nor ")} sets.`;
      } else if (parts.some((part) => "command" in part)) {
        const shellEnv = {};
        for (const path of [...envFiles].reverse()) Object.assign(shellEnv, readEnvFile(path));
        for (const [name, value] of Object.entries({ ...process.env, ...env })) if (value !== void 0) shellEnv[name] = value;
        const encoded = inUserinfo(parts);
        const build = (fresh) => {
          let built = "";
          for (const [i, part] of parts.entries()) {
            if ("text" in part) {
              built += texts[i];
              continue;
            }
            const out2 = commandOutput(part.command, root, shellEnv, fresh);
            if ("error" in out2) return { error: `${shown2(file)}: "direct_url" runs \`${part.command}\`, ${out2.error}.` };
            built += encoded.has(part) ? encodeURIComponent(out2.value) : out2.value;
          }
          return { url: built };
        };
        if (!error) {
          const first = build(false);
          if ("error" in first) error = first.error;
          else url = first.url;
          refreshUrl = () => {
            const again = build(true);
            return "url" in again ? again.url : void 0;
          };
        }
      } else url = texts.join("");
    }
  } else {
    const hit = lookup("DATABASE_URL");
    url = hit?.value;
    if (hit) urlSource = hit.source;
  }
  let dialect = url ? dialectOf(url) : "postgres";
  if (url && !dialect) error ??= `Cannot tell the database from the URL (${urlSource}): reylo reads postgres://, postgresql://, mysql://, file: and sqlite: URLs.`;
  const watched = [.../* @__PURE__ */ new Set([...file ? [file] : [], ...both]), ...envFiles];
  const installed = url ? [] : installedEngines(root);
  if (installed.length === 1) dialect = installed[0];
  return { file, root, dialect: dialect ?? "postgres", strictParams: config.strict_params ?? true, sqlcommenter: config.sqlcommenter ?? true, cli: config.cli ?? {}, url, urlSource, refreshUrl, watched, error, notice, missingUrl };
}

// src/sqlite-describe.ts
import { fileURLToPath } from "node:url";
import { isAbsolute as isAbsolute2, resolve as resolve2 } from "node:path";
function sqlitePath(url, baseDir) {
  if (url === ":memory:" || url === "file::memory:") return ":memory:";
  const raw = url.startsWith("file://") ? fileURLToPath(url) : url.replace(/^(file|sqlite):(\/\/)?/, "");
  return isAbsolute2(raw) ? raw : resolve2(baseDir, raw);
}
async function openSqliteDescriber(url, baseDir) {
  const { DatabaseSync: DatabaseSync2 } = await import("node:sqlite");
  const path = sqlitePath(url, baseDir);
  const db = new DatabaseSync2(path, { readOnly: path !== ":memory:" });
  return {
    async values(sql, params = []) {
      const stmt = db.prepare(sql);
      const names = stmt.columns().map((c) => c.name);
      return stmt.all(...params).map((row) => names.map((n) => row[n]));
    },
    async close() {
      db.close();
    }
  };
}

// src/sqlite-drivers.ts
import { fork } from "node:child_process";
import { existsSync as existsSync2, readFileSync as readFileSync3, statSync } from "node:fs";
import { createRequire as createRequire3 } from "node:module";
import { dirname as dirname3, join as join3 } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath as fileURLToPath2, pathToFileURL as pathToFileURL2 } from "node:url";
function sync(name, db) {
  const row = db.prepare("select sqlite_version() as v").get();
  return {
    name,
    says: (refusal) => `${name} runs SQLite ${row.v}, which refuses this statement: ${refusal}`,
    async refuses(sql) {
      try {
        db.prepare(sql);
        return void 0;
      } catch (e) {
        return e.message;
      }
    },
    async close() {
      db.close();
    }
  };
}
var DRIVERS = [
  [
    "better-sqlite3",
    async (require2, path) => {
      const Database = require2("better-sqlite3");
      return sync("better-sqlite3", new Database(path, { readonly: true, fileMustExist: true }));
    }
  ],
  [
    // `@libsql/client` opens a file through the `libsql` package, its own dependency.
    "@libsql/client",
    async (require2, path) => {
      const Database = createRequire3(require2.resolve("@libsql/client"))("libsql");
      return sync("@libsql/client", new Database(path, { readonly: true }));
    }
  ],
  [
    "libsql",
    async (require2, path) => {
      const Database = require2("libsql");
      return sync("libsql", new Database(path, { readonly: true }));
    }
  ],
  [
    "sqlite3",
    async (require2, path) => {
      const sqlite3 = require2("sqlite3");
      const db = await new Promise((done, fail) => {
        const d = new sqlite3.Database(path, sqlite3.OPEN_READONLY, (e) => e ? fail(e) : done(d));
      });
      const version = await new Promise((done, fail) => db.get("select sqlite_version() as v", (e, row) => e ? fail(e) : done(row.v)));
      return {
        name: "sqlite3",
        says: (refusal) => `sqlite3 runs SQLite ${version}, which refuses this statement: ${refusal}`,
        refuses: (sql) => new Promise((done) => {
          const statement = db.prepare(sql, (e) => {
            if (!e) statement.finalize();
            done(e ? e.message.replace(/^SQLITE_\w+: /, "") : void 0);
          });
        }),
        close: () => new Promise((done) => db.close(() => done()))
      };
    }
  ],
  [
    "@tursodatabase/database",
    async (require2, path) => {
      const { Database } = await import(pathToFileURL2(require2.resolve("@tursodatabase/database/compat")).href);
      return sync("@tursodatabase/database", new Database(path, { readonly: true }));
    }
  ],
  ["wrangler", openD1]
];
var D1_START = 3e4;
var d1s = /* @__PURE__ */ new Map();
function wranglerConfig(dir) {
  return ["wrangler.json", "wrangler.jsonc", "wrangler.toml"].map((name) => {
    try {
      const { size, mtimeMs } = statSync(join3(dir, name));
      return `${name} ${size} ${mtimeMs}`;
    } catch {
      return "";
    }
  }).join("\0");
}
async function openD1(require2, path) {
  const entry = require2.resolve("wrangler");
  const dir = dirname3(require2.resolve("./package.json"));
  const key = `${entry}\0${dir}`;
  const config = wranglerConfig(dir);
  let held = d1s.get(key);
  if (held?.config !== config) {
    held?.started.then((d) => d.close(), () => {
    });
    const started = startD1(entry, dir, () => {
      if (d1s.get(key)?.started === started) d1s.delete(key);
    });
    started.catch(() => {
    });
    d1s.set(key, held = { config, started });
  }
  const d1 = await held.started;
  const schema = new DatabaseSync(path, { readOnly: true });
  return {
    name: "wrangler",
    says: (refusal) => `Cloudflare D1, as wrangler ${d1.version} runs it locally, refuses this statement: ${refusal}`,
    async refuses(sql, params) {
      let ddl;
      try {
        ddl = schemaDdl(schema);
      } catch {
        return void 0;
      }
      return d1.explain(sql, params, ddl);
    },
    async close() {
      schema.close();
    }
  };
}
function schemaDdl(db) {
  return db.prepare(
    `select s.sql from sqlite_schema s where s.sql is not null and substr(s.name, 1, 7) <> 'sqlite_' and substr(s.name, 1, 4) <> '_cf_'
         and not exists (select 1 from pragma_table_list p where p.name = s.name and p.type = 'shadow') order by s.rowid`
  ).all().map((r) => r.sql);
}
async function startD1(entry, dir, ended) {
  const version = wranglerVersion(entry);
  const extension = import.meta.url.slice(import.meta.url.lastIndexOf("."));
  const child = fork(fileURLToPath2(new URL(`./d1-proxy${extension}`, import.meta.url)), [entry, dir], {
    stdio: ["ignore", "ignore", "ignore", "ipc"],
    env: { ...process.env, WRANGLER_SEND_METRICS: "false" }
  });
  child.unref();
  const pending = /* @__PURE__ */ new Map();
  let next = 0;
  let sent;
  const gone = new Promise((_, fail) => child.once("exit", () => fail(new Error("D1's process ended"))));
  gone.catch(() => {
  });
  child.on("message", (m) => {
    if (m.kind !== "explain") return;
    pending.get(m.id)?.(m.error);
    pending.delete(m.id);
    if (!pending.size) child.channel?.unref();
  });
  let running = false;
  child.once("exit", () => {
    if (running) ended();
    for (const settle of pending.values()) settle(void 0);
    pending.clear();
  });
  const stop = () => {
    if (child.connected) child.send({ kind: "close" });
    setTimeout(() => child.kill(), 2e3).unref();
  };
  try {
    const timeout = new Promise((_, fail) => setTimeout(() => fail(new Error("workerd did not start")), D1_START).unref());
    const ready = await Promise.race([gone, timeout, new Promise((done) => child.once("message", done))]);
    if (!ready.d1) throw new Error("the wrangler config binds no D1 database");
  } catch (e) {
    stop();
    throw e;
  }
  running = true;
  child.channel?.unref();
  return {
    version,
    close: stop,
    explain: (sql, params, ddl) => new Promise((done) => {
      if (!child.connected) return done(void 0);
      const id = next++;
      pending.set(id, (error) => {
        const message = error?.replace(/^D1_ERROR: /, "").replace(/ at offset \d+/, "").replace(/: SQLITE_\w+$/, "");
        done(message && !/^Wrong number of parameter bindings/.test(message) ? message : void 0);
      });
      child.channel?.ref();
      const text = JSON.stringify(ddl);
      if (text !== sent) {
        child.send({ kind: "schema", ddl });
        sent = text;
      }
      child.send({ kind: "explain", id, sql, params });
    })
  };
}
function wranglerVersion(entry) {
  for (let dir = dirname3(entry); dirname3(dir) !== dir; dir = dirname3(dir)) {
    const file = join3(dir, "package.json");
    if (!existsSync2(file)) continue;
    const pkg = JSON.parse(readFileSync3(file, "utf8"));
    if (pkg.name === "wrangler") return pkg.version ?? "";
  }
  return "";
}
function projectDrivers(root) {
  const file = join3(packageDir(root), "package.json");
  if (!existsSync2(file)) return [];
  let listed;
  try {
    const pkg = JSON.parse(readFileSync3(file, "utf8"));
    listed = new Set(["dependencies", "devDependencies", "optionalDependencies"].flatMap((key) => Object.keys(pkg[key] ?? {})));
  } catch {
    return [];
  }
  return DRIVERS.map(([name]) => name).filter((name) => listed.has(name));
}
async function openProjectDrivers(root, path) {
  if (path === ":memory:") return [];
  const names = projectDrivers(root);
  if (!names.length) return [];
  const require2 = createRequire3(join3(packageDir(root), "package.json"));
  const opened = await Promise.all(DRIVERS.filter(([name]) => names.includes(name)).map(([, open]) => open(require2, path).catch(() => void 0)));
  return opened.filter((d) => d !== void 0);
}
var utf8 = new TextEncoder();
function placeRefusal(sql, message) {
  const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const fn = /(?:no such function|not authorized to use function): ([\w$]+)/i.exec(message)?.[1] ?? /arguments to function ([\w$]+)\(\)/i.exec(message)?.[1];
  const near = /near "([^"]+)"/.exec(message)?.[1];
  const found = fn ? new RegExp(`\\b${escape(fn)}\\s*\\(`, "i").exec(sql) : near ? new RegExp(escape(near), "i").exec(sql) : null;
  const at = found ? { index: found.index, text: fn ?? near } : { index: sql.search(/\S/), text: /\S+/.exec(sql)?.[0] ?? "" };
  return { start: utf8.encode(sql.slice(0, Math.max(at.index, 0))).length, length: Math.max(utf8.encode(at.text).length, 1) };
}

// src/analyze.ts
var ENTRY_VERSION = 1;
var SCHEMA_TTL = 5e3;
var OFFLINE_TTL = 6e4;
var BUILD_IDLE = 250;
var sessions = /* @__PURE__ */ new Map();
async function openProject(dir, env) {
  const project = resolveProject(await anyEngine(dir), dir, env);
  const own = await engine(project.dialect, project.root).catch((e) => e instanceof MissingEngine ? e : new MissingEngine(e.message));
  return { project, engine: own };
}
var Session = class _Session {
  /** The project as resolved when the session opened, or again once a failed `direct_url` command succeeds (`#reread`). */
  project;
  /** The project's directory, which holds `.reylo/`. */
  root;
  /** The engine of the project's database, or why there is none, which an analysis reports. */
  #engine;
  #engineFingerprint;
  #answers = new AnswerCache();
  #idle;
  /** Where the project was resolved from, and with what environment, for `#reread`. */
  #dir;
  #env;
  #io;
  /** The URL the connection opens: the project's, until a command in `direct_url` gives a fresh one. */
  #url;
  #busy = 0;
  #timer;
  #schema;
  constructor(engine2, project, idle, dir, env) {
    this.root = project.root;
    this.#idle = idle;
    this.#dir = dir;
    this.#env = env;
    this.#adopt(engine2, project);
  }
  #adopt(engine2, project) {
    this.#engine = engine2;
    this.project = project;
    this.#url = project.url;
    const ping = engine2 instanceof MissingEngine ? void 0 : engine2.call({ op: "ping" });
    this.#engineFingerprint = ping?.status === "ok" ? ping.fingerprint : "unknown";
  }
  /**
   * Reads the project again while a `direct_url` command's failure is its error, as when a
   * password manager was locked: the command runs again once its failure has stood a minute
   * (src/project.ts), so that a session kept open, as the type check's is, recovers without a
   * restart.
   */
  async #reread() {
    if (!this.project.error || !this.project.refreshUrl) return;
    const { project, engine: engine2 } = await openProject(this.#dir, this.#env);
    if (project.error) return;
    this.#adopt(engine2, project);
    this.#schema = void 0;
    this.#answers.clear();
  }
  /** The build steps' session for the project a file or directory belongs to: one per project (and connection) and process. */
  static async for(from, env = process.env) {
    const dir = packageDir(from);
    const { project, engine: engine2 } = await openProject(dir, env);
    const key = JSON.stringify([project.root, project.url ?? null, project.error ?? null, project.sqlcommenter, engine2 instanceof MissingEngine ? engine2.message : null]);
    let session = sessions.get(key);
    if (!session) sessions.set(key, session = new _Session(engine2, project, BUILD_IDLE, dir, env));
    return session;
  }
  /** A session of its own, for a caller that must not share one (the type check, a test); it keeps its connection until closed. */
  static async open(from, env = process.env, idle = Infinity) {
    const { project, engine: engine2 } = await openProject(from, env);
    return new _Session(engine2, project, idle, from, env);
  }
  /** Every build-step session this process opened, for a caller that ends them (`reylo generate`). */
  static opened() {
    return [...sessions.values()];
  }
  lex(sql) {
    if (this.#engine instanceof MissingEngine) throw this.#engine;
    return this.#engine.lex(sql, this.project.dialect);
  }
  /**
   * Where this session's entry for a statement lives, whether or not it exists yet: named by the
   * statement, then by the server. Two databases keep an entry each, since a Postgres fingerprint
   * holds object ids, so a dev and a test database built by the same migrations still differ. A
   * session that cannot reach its database, or has no URL, reads another server's entry for the
   * statement where it has none of its own (`#offlineEntry`).
   */
  entryFile(sql) {
    return join4(this.root, ".reylo", "queries", `${this.#statementKey(sql)}-${sha256(this.#server()).slice(0, 16)}.json`);
  }
  #statementKey(sql) {
    return sha256(JSON.stringify([ENTRY_VERSION, this.#engineFingerprint, this.project.dialect, sql])).slice(0, 32);
  }
  /** The statement's entry from this session's server, else the newest from any other: for a session that cannot reach its database, or has no URL. */
  #offlineEntry(sql) {
    const own = this.entryFile(sql);
    const entry = readEntry(own);
    if (entry) return { file: own, entry };
    const dir = join4(this.root, ".reylo", "queries");
    const prefix = `${this.#statementKey(sql)}-`;
    let names;
    try {
      names = readdirSync(dir).filter((n) => n.startsWith(prefix) && n.endsWith(".json"));
    } catch {
      return void 0;
    }
    let newest;
    for (const file of names.map((n) => join4(dir, n))) {
      const other = readEntry(file);
      if (other && (!newest || (other.at ?? -Infinity) > (newest.entry.at ?? -Infinity))) newest = { file, entry: other };
    }
    return newest;
  }
  /**
   * The statement's analysis: from `.reylo/` when the entry matches the schema, else from the
   * database. `store: false` neither reads nor writes `.reylo/`, for a statement that is no file of
   * the project (`reylo play`'s, analyzed at each keystroke).
   */
  async analyze(sql, options = {}) {
    clearTimeout(this.#timer);
    this.#busy++;
    try {
      await this.#reread();
      const outcome = await this.#analyze(sql, options);
      return outcome.ok && this.project.dialect === "sqlite" ? await this.#onDrivers(sql, outcome) : outcome;
    } finally {
      if (--this.#busy === 0 && this.#io && Number.isFinite(this.#idle)) this.#timer = setTimeout(() => this.#release(), this.#idle).unref();
    }
  }
  /** Rows of a catalog query on the session's connection, as arrays of values: what `reylo play` completes. */
  async query(sql, params = []) {
    return (await this.#connection()).query(sql, params);
  }
  /**
   * A SQLite statement prepared on the app's own drivers too, whose SQLite may be older than the
   * engine's: the first that refuses it is an error at the place SQLite names. Not kept in
   * `.reylo/`, since the drivers are the project's and not the database's; a session that cannot
   * open the database checks nothing. One whose connection was released while its schema is still
   * trusted opens it again, so a `.reylo/` hit is checked however long the session sat idle.
   */
  async #onDrivers(sql, outcome) {
    const { analysis } = outcome;
    if (analysis.diagnostics.length || this.#schema?.value == null) return outcome;
    const io = await this.#connection().catch(() => void 0);
    for (const driver of io?.drivers ?? []) {
      const refusal = await driver.refuses(analysis.rewritten.sql, analysis.rewritten.order.length);
      if (refusal === void 0) continue;
      const { start, length } = placeRefusal(sql, refusal);
      const message = driver.says(refusal);
      return { ...outcome, analysis: { ...analysis, diagnostics: [{ message, start, length, code: 6 }] } };
    }
    return outcome;
  }
  async #analyze(sql, options) {
    if (this.project.error) return { ok: false, message: this.project.error, code: 11 };
    if (!this.project.url) {
      const hit = this.#engine instanceof MissingEngine || options.force ? void 0 : this.#offlineEntry(sql);
      return hit ? { ok: true, analysis: hit.entry.analysis, source: "cache", entry: hit.file } : { ok: false, message: this.project.missingUrl, code: 4 };
    }
    const engine2 = this.#engine;
    if (engine2 instanceof MissingEngine) return { ok: false, message: engine2.message, code: 11 };
    const file = this.entryFile(sql);
    const schema = await this.schema();
    if (schema.fatal) return { ok: false, message: schema.error, code: 5 };
    if (schema.value === null) {
      const hit = options.force ? void 0 : this.#offlineEntry(sql);
      if (hit) return { ok: true, analysis: hit.entry.analysis, source: "cache", entry: hit.file };
      return { ok: false, message: `${this.cannotConnect(schema.error)}; .reylo has no analysis of this statement, so run reylo generate where the database can be reached.`, code: 5 };
    }
    const entry = options.force || options.store === false ? void 0 : readEntry(file);
    if (entry && entry.schema === schema.value) return { ok: true, analysis: entry.analysis, source: "cache", entry: file };
    let analysis;
    const io = this.#connection();
    try {
      analysis = await engine2.analyze(sql, this.project.dialect, await io, this.#answers);
    } catch (e) {
      if (e instanceof Unreachable) {
        this.#drop(io);
        this.#schema = { value: null, at: Date.now(), error: reason(e) };
        return { ok: false, message: this.cannotConnect(reason(e)), code: 5 };
      }
      if (e instanceof NotMysql) {
        this.#drop(io);
        this.#schema = { value: null, at: Date.now(), error: this.notMysql(e), fatal: true };
        return { ok: false, message: this.#schema.error, code: 5 };
      }
      return { ok: false, message: e.message, code: 5 };
    }
    if (options.store !== false) writeEntry(this.root, file, { version: ENTRY_VERSION, dialect: this.project.dialect, schema: schema.value, analysis, at: Date.now() });
    return { ok: true, analysis, source: "database", entry: file };
  }
  /**
   * The fingerprint of the database's schema; null when the database cannot be reached, and
   * `fatal` when no connection can be made at all (no driver installed) or the server is one the type
   * check refuses (MariaDB, `NotMysql`). A server that refuses the
   * fingerprint query gets a value no entry matches, so every statement is analyzed live.
   */
  async schema() {
    const now = Date.now();
    if (this.#schema && now - this.#schema.at < (this.#schema.value === null ? OFFLINE_TTL : SCHEMA_TTL)) return this.#schema;
    const pending = this.#connection();
    let io;
    try {
      io = await pending;
    } catch (e) {
      this.#drop(pending);
      this.#schema = e instanceof Unreachable ? { value: null, at: now, error: reason(e) } : { value: null, at: now, error: e instanceof NotMysql ? this.notMysql(e) : e.message, fatal: true };
      return this.#schema;
    }
    try {
      const rows = await io.query(FINGERPRINT[this.project.dialect], []);
      const value = createHash("sha256").update(JSON.stringify(rows)).digest("hex").slice(0, 16);
      if (this.#schema?.value && this.#schema.value !== value) this.#answers.clear();
      this.#schema = { value, at: now };
    } catch (e) {
      if (e instanceof Unreachable) {
        this.#drop(pending);
        this.#schema = { value: null, at: now, error: reason(e) };
      } else {
        this.#schema = { value: `unverified ${process.pid} ${now}`, at: now };
      }
    }
    return this.#schema;
  }
  /** Reads the schema's fingerprint again now, however recent the last read; whether it changed. */
  async recheck() {
    const before = this.#schema?.value;
    if (this.#schema) this.#schema = { ...this.#schema, at: -Infinity };
    return (await this.schema()).value !== before;
  }
  /** Where the database was looked for, and where that came from; never the credentials. */
  cannotConnect(why) {
    const { dialect, url, root, urlSource } = this.project;
    if (dialect === "sqlite") return `Cannot open the database ${sqlitePath(url ?? "", root)} (${urlSource})${why ? `: ${why}` : ""}`;
    return `Cannot connect to the database at ${this.where()} (${urlSource})${why ? `: ${why}` : ""}`;
  }
  /** Why a server the type check cannot read is refused, and what to point it at instead. */
  notMysql(e) {
    return `Cannot type-check against the database at ${this.where()} (${this.project.urlSource}): it is ${e.server}, and Reylo type-checks MySQL statements against MySQL. Point the type check's URL at a MySQL server, 8.4 or later, with the same schema.`;
  }
  /** The server, without credentials, that names this session's entries: none with no URL, which writes none. */
  #server() {
    const { dialect, url, root } = this.project;
    if (!url) return "";
    if (dialect === "sqlite") return sqlitePath(url, root);
    try {
      const u = new URL(url);
      return `${u.protocol}//${u.username}@${u.host}${u.pathname}`;
    } catch {
      return url;
    }
  }
  /** The database as a person names it: host, port and database, or the SQLite file. */
  where() {
    const { dialect, url, root } = this.project;
    if (dialect === "sqlite") return sqlitePath(url ?? "", root);
    try {
      const u = new URL(url ?? "");
      return `${u.hostname || u.searchParams.get("host") || "localhost"}${u.port ? `:${u.port}` : ""}${u.pathname}`;
    } catch {
      return "the database";
    }
  }
  async close() {
    for (const [key, session] of sessions) if (session === this) sessions.delete(key);
    await this.release();
  }
  /** Closes the connection now, for a caller that knows no file is coming; the next analysis opens another. */
  async release() {
    clearTimeout(this.#timer);
    await this.#release();
  }
  /** Closes the connection; the next analysis opens another. */
  async #release() {
    const io = this.#io;
    this.#io = void 0;
    if (io) await io.then((i) => i.close()).catch(() => {
    });
  }
  #connection() {
    this.#io ??= (async () => {
      let first;
      try {
        first = await this.#open(this.#url);
      } catch (e) {
        const fresh = this.#freshUrl(e);
        if (fresh === void 0) throw e;
        first = await this.#open(fresh);
      }
      if (!this.project.refreshUrl) return first;
      let current = Promise.resolve(first);
      const again = async (call) => {
        const used = current;
        const on = await used;
        try {
          return await call(on);
        } catch (e) {
          if (current === used) {
            if (!refusedLogin(e)) throw e;
            current = (async () => {
              await on.close().catch(() => {
              });
              const fresh = this.#freshUrl(e);
              if (fresh === void 0) throw e;
              return this.#open(fresh);
            })();
            current.catch(() => {
            });
          }
          return call(await current);
        }
      };
      return {
        describe: (text) => again((on) => on.describe(text)),
        query: (text, params) => again((on) => on.query(text, params)),
        close: () => current.then((on) => on.close(), () => {
        }),
        ...first.drivers && { drivers: first.drivers }
      };
    })();
    const io = this.#io;
    io.catch(() => {
      if (this.#io === io) this.#io = void 0;
    });
    return io;
  }
  /**
   * Forgets a connection a call found dead, and closes it, since one opened in its place with a
   * command's fresh output may be live. Only the connection that call ran on: a call that fails
   * late never ends one opened since.
   */
  #drop(io) {
    if (this.#io !== io) return;
    this.#io = void 0;
    io.then((i) => i.close()).catch(() => {
    });
  }
  /**
   * A URL to try instead, when the server refused the login and `direct_url`'s command now prints
   * something else, as when a short-lived password has expired; else undefined, so that nothing
   * is tried twice on the same password.
   */
  #freshUrl(e) {
    if (!refusedLogin(e)) return void 0;
    const fresh = this.project.refreshUrl?.();
    if (fresh === void 0 || fresh === this.#url) return void 0;
    this.#url = fresh;
    return fresh;
  }
  async #open(url) {
    const { dialect, root } = this.project;
    if (dialect === "mysql") {
      const { openMysqlDescriber } = await describer("mysql", root);
      const m = await openMysqlDescriber(url);
      return { describe: (text) => m.describe(text), query: (text, params) => m.values(text, params), close: () => m.close() };
    }
    if (dialect === "sqlite") {
      const s = await openSqliteDescriber(url, root).catch((e) => Promise.reject(new Unreachable(e)));
      const drivers = await openProjectDrivers(root, sqlitePath(url, root));
      return {
        describe: () => Promise.reject(new Error("SQLite is described inside the engine")),
        query: (text, params) => s.values(text, params),
        close: async () => {
          await Promise.all(drivers.map((d2) => d2.close().catch(() => {
          })));
          await s.close();
        },
        drivers
      };
    }
    const { openPostgresDescriber } = await describer("postgres", root);
    const d = await openPostgresDescriber(url);
    return { describe: (text) => d.describe(text), query: (text, params) => d.values(text, params), close: () => d.close() };
  }
};
async function releaseConnections() {
  await Promise.all([...sessions.values()].map((session) => session.release()));
}
var sha256 = (text) => createHash("sha256").update(text).digest("hex");
function readEntry(file) {
  if (!existsSync3(file)) return void 0;
  try {
    const entry = JSON.parse(readFileSync4(file, "utf8"));
    return entry.version === ENTRY_VERSION ? entry : void 0;
  } catch {
    return void 0;
  }
}
function writeEntry(root, file, entry) {
  const dir = join4(root, ".reylo");
  const tmp = `${file}.${process.pid}.${Math.random().toString(36).slice(2)}.tmp`;
  try {
    mkdirSync(join4(dir, "queries"), { recursive: true });
    const ignore = join4(dir, ".gitignore");
    if (!existsSync3(ignore)) writeFileSync(ignore, "# reylo's cache: written by the type check, the build steps and reylo generate; never committed.\n*\n");
    writeFileSync(tmp, JSON.stringify(entry) + "\n");
    renameSync(tmp, file);
  } catch {
    rmSync(tmp, { force: true });
  }
}
var NS = `not (n.nspname operator(pg_catalog.=) any ('{pg_catalog,information_schema}'::pg_catalog.name[])) and n.nspname operator(pg_catalog.!~) '^pg_(toast|temp)'::pg_catalog.text`;
var cat = (...parts) => parts.join(" operator(pg_catalog.||) ");
var lit = (s) => `'${s}'::pg_catalog.text`;
var line = (tag, ...fields) => cat(lit(`${tag} `), ...fields.flatMap((f, i) => i ? [lit(" "), f] : [f]));
var out = (type, value) => `pg_catalog.textin(pg_catalog.${type}out(${value}))`;
var txt = (value) => `${value}::pg_catalog.text`;
var md5 = (value) => `pg_catalog.md5(${value})`;
var or = (value) => `coalesce(${value}, ''::pg_catalog.text)`;
var eq = (a, b) => `${a} operator(pg_catalog.=) ${b}`;
var rel = (alias, column) => `join pg_catalog.pg_class c on ${eq("c.oid", `${alias}.${column}`)} join pg_catalog.pg_namespace n on ${eq("n.oid", "c.relnamespace")}`;
var PG_CLASS = "'pg_catalog.pg_class'::pg_catalog.regclass::pg_catalog.oid";
var USER = "'16384'::pg_catalog.oid";
var POSTGRES_FINGERPRINT = `select pg_catalog.md5(coalesce(pg_catalog.string_agg(t.x, E'\\n'::pg_catalog.text order by t.x), ''::pg_catalog.text)) from (
    select ${line("v", "pg_catalog.current_setting('server_version_num'::pg_catalog.text)", "pg_catalog.current_setting('search_path'::pg_catalog.text)")} as x
    union all select ${line("r", out("oid", "c.oid"), cat(txt("n.nspname"), lit("."), txt("c.relname")), txt("c.relkind"))} from pg_catalog.pg_class c join pg_catalog.pg_namespace n on ${eq("n.oid", "c.relnamespace")} where ${NS}
    union all select ${line("a", out("oid", "a.attrelid"), out("int2", "a.attnum"), txt("a.attname"), out("oid", "a.atttypid"), txt("a.attnotnull"), out("oid", "a.attcollation"))} from pg_catalog.pg_attribute a ${rel("a", "attrelid")} where a.attnum operator(pg_catalog.>) 0 and not a.attisdropped and ${NS}
    union all select ${line("h", out("oid", "h.inhrelid"), out("oid", "h.inhparent"), out("int4", "h.inhseqno"))} from pg_catalog.pg_inherits h ${rel("h", "inhrelid")} where ${NS}
    union all select ${line("c", out("oid", "o.conrelid"), out("oid", "o.contypid"), txt("o.conname"), "pg_catalog.pg_get_constraintdef(o.oid)")} from pg_catalog.pg_constraint o join pg_catalog.pg_namespace n on ${eq("n.oid", "o.connamespace")} where ${NS}
    union all select ${line("i", out("oid", "i.indexrelid"), txt("i.indisvalid"), "pg_catalog.pg_get_indexdef(i.indexrelid)")} from pg_catalog.pg_index i ${rel("i", "indrelid")} where ${NS}
    union all select ${line("g", out("oid", "g.tgrelid"), txt("g.tgname"), out("int2", "g.tgtype"), txt("g.tgenabled"))} from pg_catalog.pg_trigger g ${rel("g", "tgrelid")} where not g.tgisinternal and ${NS}
    union all select ${line("u", out("oid", "w.ev_class"), txt("w.rulename"), txt("w.ev_type"), txt("w.ev_enabled"), md5("pg_catalog.pg_get_ruledef(w.oid)"))} from pg_catalog.pg_rewrite w ${rel("w", "ev_class")} where w.rulename operator(pg_catalog.<>) '_RETURN'::pg_catalog.name and ${NS}
    union all select ${line("o", out("oid", "o.oid"), txt("o.oprname"), out("oid", "o.oprleft"), out("oid", "o.oprright"), out("oid", "o.oprcode::pg_catalog.oid"))} from pg_catalog.pg_operator o where o.oid operator(pg_catalog.>=) ${USER}
    union all select ${line("e", out("oid", "e.enumtypid"), out("float4", "e.enumsortorder"), txt("e.enumlabel"))} from pg_catalog.pg_enum e
    union all select ${line("t", out("oid", "t.oid"), txt("t.typname"), txt("t.typtype"), out("oid", "t.typbasetype"), txt("t.typnotnull"), md5(or("t.typdefault")))} from pg_catalog.pg_type t join pg_catalog.pg_namespace n on ${eq("n.oid", "t.typnamespace")} where ${NS}
    union all select ${line("f", out("oid", "p.oid"), txt("p.proname"), out("oid", "p.prorettype"), txt("p.proretset"), out("oidvector", "p.proargtypes"), md5(or("p.prosrc")), txt("p.prokind"), txt("p.provolatile"), txt("p.proisstrict"), out("int2", "p.pronargdefaults"), out("oid", "p.provariadic"))} from pg_catalog.pg_proc p join pg_catalog.pg_namespace n on ${eq("n.oid", "p.pronamespace")} where ${NS}
    union all select ${line("k", out("oid", "k.oid"), out("oid", "k.castsource"), out("oid", "k.casttarget"), out("oid", "k.castfunc"), txt("k.castcontext"), txt("k.castmethod"))} from pg_catalog.pg_cast k where k.oid operator(pg_catalog.>=) ${USER}
    union all select ${line("w", out("oid", "c.oid"), md5("pg_catalog.pg_get_viewdef(c.oid)"))} from pg_catalog.pg_class c join pg_catalog.pg_namespace n on ${eq("n.oid", "c.relnamespace")} where c.relkind operator(pg_catalog.=) any ('{v,m}'::pg_catalog."char"[]) and ${NS}
    union all select ${line("x", out("oid", "d.adrelid"), out("int2", "d.adnum"), md5("pg_catalog.pg_get_expr(d.adbin, d.adrelid)"))} from pg_catalog.pg_attrdef d ${rel("d", "adrelid")} where ${NS}
    union all select ${line("p", out("oid", "p.polrelid"), txt("p.polname"), txt("p.polcmd"), txt("p.polpermissive"), md5(cat(or("pg_catalog.pg_get_expr(p.polqual, p.polrelid)"), lit(" "), or("pg_catalog.pg_get_expr(p.polwithcheck, p.polrelid)"))))} from pg_catalog.pg_policy p ${rel("p", "polrelid")} where ${NS}
    union all select ${line("q", out("oid", "q.oid"), txt("q.opcname"), out("oid", "q.opcmethod"), out("oid", "q.opcintype"))} from pg_catalog.pg_opclass q where q.oid operator(pg_catalog.>=) ${USER}
    union all select ${line("d", out("oid", "d.objoid"), out("int4", "d.objsubid"), md5("d.description"))} from pg_catalog.pg_description d ${rel("d", "objoid")} where ${eq("d.classoid", PG_CLASS)} and d.objsubid operator(pg_catalog.>) 0 and ${NS}
  ) t`;
var FINGERPRINT = {
  postgres: POSTGRES_FINGERPRINT,
  mysql: `select concat_ws(' ', @@version, @@sql_mode, count(*), sum(crc32(x)), bit_xor(crc32(x))) from (
    select concat_ws(' ', 'c', table_name, column_name, ordinal_position, column_type, is_nullable, column_key, extra, coalesce(generation_expression, ''), md5(column_comment)) as x from information_schema.columns where table_schema = database()
    union all select concat_ws(' ', 's', table_name, index_name, non_unique, seq_in_index, column_name) from information_schema.statistics where table_schema = database()
    union all select concat_ws(' ', 'v', table_name, md5(view_definition)) from information_schema.views where table_schema = database()
    union all select concat_ws(' ', 'r', routine_name, routine_type, coalesce(dtd_identifier, ''), md5(coalesce(routine_definition, ''))) from information_schema.routines where routine_schema = database()
    union all select concat_ws(' ', 'p', routine_schema, routine_name) from information_schema.routines where routine_schema <> database() and routine_type = 'FUNCTION'
    union all select concat_ws(' ', 'g', event_object_table, trigger_name, event_manipulation, action_timing) from information_schema.triggers where event_object_schema = database()
    union all select concat_ws(' ', 'f', table_name, constraint_name, referenced_table_name, update_rule, delete_rule) from information_schema.referential_constraints where constraint_schema = database()
    union all select concat_ws(' ', 'k', table_name, constraint_name, constraint_type) from information_schema.table_constraints where table_schema = database()
  ) t`,
  sqlite: `select type, name, tbl_name, coalesce(sql, '') from sqlite_schema
    union all select 'function', name, type, narg from pragma_function_list order by 1, 2, 3, 4`
};

// src/commands.ts
import { spawnSync as spawnSync2 } from "node:child_process";
import { existsSync as existsSync5, readFileSync as readFileSync6, statSync as statSync3 } from "node:fs";
import { glob } from "node:fs/promises";
import { dirname as dirname5, relative as relative2, resolve as resolve3 } from "node:path";
import { styleText as styleText2 } from "node:util";

// src/play.ts
import { spawn } from "node:child_process";
import { existsSync as existsSync4, readFileSync as readFileSync5, statSync as statSync2 } from "node:fs";
import { createServer } from "node:http";
import { createRequire as createRequire4 } from "node:module";
import { dirname as dirname4, extname, join as join5, sep as sep2 } from "node:path";
import { styleText } from "node:util";

// src/play-catalog.ts
var CATALOG_QUERIES = {
  postgres: {
    // The tables and views of the schemas on the search path, as an unqualified name finds them.
    tables: `select c.relname::text, a.attname::text, format_type(a.atttypid, a.atttypmod), not a.attnotnull
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
  join pg_attribute a on a.attrelid = c.oid and a.attnum > 0 and not a.attisdropped
  where n.nspname = any(current_schemas(false)) and n.nspname <> 'pg_catalog' and c.relkind in ('r', 'v', 'm', 'p', 'f') order by c.relname, a.attnum`,
    // Postgres's own and the schema's, without the ones it keeps for itself (input and output,
    // operator and planner support, aggregates' inner steps).
    functions: `select p.proname::text, bool_or(p.prokind = 'a'), array_agg(distinct format_type(p.prorettype, null)), bool_or(p.proretset)
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
  where (n.nspname = 'pg_catalog' or n.nspname = any(current_schemas(false))) and p.prokind in ('f', 'a', 'w')
    and p.prorettype not in ('internal'::regtype, 'cstring'::regtype, 'trigger'::regtype, 'event_trigger'::regtype, 'language_handler'::regtype,
      'fdw_handler'::regtype, 'index_am_handler'::regtype, 'table_am_handler'::regtype, 'tsm_handler'::regtype)
    and p.proname !~ '^(pg_|_)'
    and p.proname !~ '(_finalfn|_serialize|_deserialize|_combine|_transfn|_support|_sortsupport|_typanalyze|joinsel|sel|_cmp|_hash|_hash_extended|_in|_out|_recv|_send)$'
    and coalesce(obj_description(p.oid, 'pg_proc'), '') !~* '^(I/O|implementation of|internal|deprecated)'
  group by p.proname order by p.proname`,
    // Postgres's own types and the schema's enums and domains.
    types: `select distinct t.typname::text from pg_type t join pg_namespace n on n.oid = t.typnamespace
  where (n.nspname = 'pg_catalog' or n.nspname = any(current_schemas(false))) and t.typtype in ('b', 'e', 'd', 'r', 'm')
    and t.typname !~ '^(_|pg_|reg)' and t.typcategory not in ('A', 'P', 'X', 'Z', 'C')
    and t.typname not in ('aclitem', 'bpchar', 'cid', 'gtsvector', 'name', 'oid', 'refcursor', 'tid', 'txid_snapshot', 'xid', 'xid8')
  order by 1`
  },
  mysql: {
    tables: `select table_name, column_name, column_type, is_nullable = 'YES' from information_schema.columns
  where table_schema = database() order by table_name, ordinal_position`
  },
  sqlite: {
    // Each column named apart: a host may read a row by its columns' names.
    tables: `select m.name as table_name, p.name as column_name, p.type as column_type, not p."notnull" as nullable from sqlite_schema m join pragma_table_info(m.name) p
  where m.type in ('table', 'view') and m.name not like 'sqlite_%' order by m.name, p.cid`,
    functions: `select name, max(type = 'a') as aggregate, null as returns, 0 as set_returning from pragma_function_list where name not like 'sqlite_%' group by name order by name`
  }
};
var SPELLED = {
  postgres: ["bigint", "boolean", "char", "character", "character varying", "decimal", "double precision", "int", "integer", "real", "smallint", "timestamp with time zone"],
  mysql: ["binary", "char", "date", "datetime", "decimal", "double", "float", "json", "nchar", "real", "signed", "time", "unsigned", "year"],
  sqlite: ["blob", "integer", "numeric", "real", "text"]
};
function shortType(type) {
  return type.replace(/^timestamp with time zone/, "timestamptz").replace(/^timestamp without time zone/, "timestamp").replace(/^time with time zone/, "timetz").replace(/^time without time zone/, "time").replace(/^character varying/, "varchar");
}
function catalog(dialect, tables, functions = [], types = []) {
  const byName = /* @__PURE__ */ new Map();
  for (const [table, name, type, nullable2] of tables) {
    let t = byName.get(table);
    if (!t) byName.set(table, t = { name: table, columns: [] });
    t.columns.push({ name, type: shortType(String(type ?? "")), nullable: Boolean(Number(nullable2) || nullable2 === true) });
  }
  return {
    tables: [...byName.values()],
    functions: functions.map(([name, aggregate, returns, rows]) => {
      const real = returns?.length === 1 && !/^(any|record|void|"any")/.test(returns[0]) ? shortType(returns[0]) : void 0;
      return { name, kind: Number(aggregate) || aggregate === true ? "aggregate" : "function", ...real ? { returns: real } : {}, rows: Boolean(Number(rows) || rows === true) };
    }),
    types: [.../* @__PURE__ */ new Set([...types.map(([t]) => t), ...SPELLED[dialect]])].sort()
  };
}

// src/doc-comment.ts
function leadingComment(sql, dialect) {
  const paragraphs = [];
  let lines;
  let last;
  let i = 0;
  let end = 0;
  for (; ; ) {
    const ws = /^\s*/.exec(sql.slice(i))[0];
    const at = i + ws.length;
    const ch = sql[at];
    const next = sql[at + 1];
    const blankBefore = (ws.match(/\n/g)?.length ?? 0) > 1;
    const lineComment = ch === "-" && next === "-" && !(dialect === "mysql" && at + 2 < sql.length && sql.charCodeAt(at + 2) > 32 && sql.charCodeAt(at + 2) !== 127) || ch === "#" && dialect === "mysql";
    if (lineComment) {
      const stop = sql.indexOf("\n", at);
      const text = sql.slice(at + (ch === "#" ? 1 : 2), stop === -1 ? sql.length : stop);
      if (!lines || last !== "line" || blankBefore) paragraphs.push(lines = []);
      lines.push(text);
      last = "line";
      i = end = stop === -1 ? sql.length : stop;
      continue;
    }
    if (ch === "/" && next === "*" && !(dialect === "mysql" && (sql[at + 2] === "!" || sql[at + 2] === "+"))) {
      let depth = 1;
      let j = at + 2;
      while (j < sql.length && depth > 0) {
        if (sql.startsWith("*/", j)) {
          depth--;
          j += 2;
        } else if (dialect === "postgres" && sql.startsWith("/*", j)) {
          depth++;
          j += 2;
        } else j++;
      }
      const text = sql.slice(at + 2, depth === 0 ? j - 2 : sql.length);
      paragraphs.push(lines = block(text));
      last = "block";
      i = end = j;
      continue;
    }
    break;
  }
  const prose = paragraphs.map(dedent).filter((p) => p.length).map((p) => p.join("\n")).join("\n\n");
  return { prose, end };
}
function block(text) {
  const lines = text.replace(/^\*+/, "").split(/\r?\n/);
  const rest = lines.slice(1).filter((l) => l.trim().length);
  if (rest.length && rest.every((l) => /^\s*\*/.test(l))) return [lines[0], ...lines.slice(1).map((l) => l.replace(/^\s*\*(?!\/) ?/, ""))];
  return lines;
}
function dedent(lines) {
  const trimmed = lines.map((l) => l.replace(/\s+$/, ""));
  while (trimmed.length && !trimmed[0]) trimmed.shift();
  while (trimmed.length && !trimmed.at(-1)) trimmed.pop();
  const indent = Math.min(...trimmed.filter((l) => l).map((l) => /^[ \t]*/.exec(l)[0].length));
  return trimmed.map((l) => l.slice(Math.min(indent, /^[ \t]*/.exec(l)[0].length)));
}
function statementAfter(sql, leading) {
  return sql.slice(leading.end).trim();
}
var sqlNote = (commented) => `The statement as Reylo sends it to the database, as the module's \`sql\` export: \`:id\` is \`$1\` on Postgres and \`?\` on MySQL and SQLite, ${commented ? "each cast is the dialect's own, and a comment naming the file ends it" : "and each cast is the dialect's own"}.`;
var RAW_NOTE = "The `.sql` file's contents, exactly as written, as the module's `raw` export.";
function docComment(prose, sql, note = "", indent = "") {
  const parts = [];
  if (prose) {
    const open = openFence(prose);
    parts.push(open ? `${prose}
${open}` : prose);
  }
  if (sql) {
    const longest = Math.max(0, ...(sql.match(/`+/g) ?? []).map((run) => run.length));
    const fence = "`".repeat(Math.max(3, longest + 1));
    parts.push(`${fence}sql
${sql}
${fence}`);
  }
  if (note) parts.push(note);
  if (!parts.length) return "";
  const body = parts.join("\n\n").replaceAll("*/", "*\\/").split("\n");
  return [`${indent}/**`, ...body.map((l) => l ? `${indent} * ${l}` : `${indent} *`), `${indent} */`, ""].join("\n");
}
function openFence(text) {
  let open;
  for (const line2 of text.split("\n")) {
    const m = /^ {0,3}(`{3,}|~{3,})/.exec(line2);
    if (!m) continue;
    if (!open) open = m[1];
    else if (m[1][0] === open[0] && m[1].length >= open.length && !line2.slice(m[0].length).trim()) open = void 0;
  }
  return open;
}

// src/values.ts
var TS_TYPE = {
  bool: "boolean",
  int: "number",
  float: "number",
  int8: "bigint",
  decimal: "string",
  text: "string",
  date: "string",
  timestamp: "string",
  timestamptz: "string",
  interval: "string",
  json: "unknown",
  bytes: "Uint8Array",
  vector: "number[]",
  hstore: "Record<string, string | null>",
  unknown: "unknown"
};
var SQL_KINDS = {
  bool: "bool",
  int2: "int",
  int4: "int",
  oid: "int",
  float4: "float",
  float8: "float",
  int8: "int8",
  numeric: "decimal",
  date: "date",
  timestamp: "timestamp",
  timestamptz: "timestamptz",
  interval: "interval",
  json: "json",
  jsonb: "json",
  bytea: "bytes",
  vector: "vector",
  halfvec: "vector",
  hstore: "hstore"
};
var SQLITE_KINDS = {
  integer: "int",
  int8: "int8",
  real: "float",
  text: "text",
  blob: "bytes",
  numeric: "int|float|text",
  bool: "bool"
};
function scalarKind(name, dialect) {
  const kinds = [...new Set(name.split("|").flatMap((part) => (dialect === "sqlite" ? SQLITE_KINDS[part] ?? "unknown" : SQL_KINDS[part] ?? "text").split("|")))];
  const wide = kinds.includes("int8") && !kinds.includes("float") ? kinds.filter((k) => k !== "int") : kinds;
  return wide.join("|");
}
function arrayDelimiter(t) {
  return t.kind === "array" ? t.delimiter : void 0;
}
function columnKind(t, dialect) {
  switch (t.kind) {
    case "scalar":
      return scalarKind(t.name, dialect);
    case "enum":
      return "text";
    case "array":
      if (t.of.kind === "scalar" && t.of.name === "record" || t.of.kind === "composite") return "text";
      return `${columnKind(t.of, dialect)}[]`;
    case "object":
    case "list":
    case "json":
    case "rows":
      return "json";
    case "composite":
      return "text";
    case "unknown":
      return "unknown";
  }
}
function kindType(kind) {
  const parts = kind.split("|").map((k) => TS_TYPE[k] ?? "unknown");
  return parts.includes("unknown") ? "unknown" : [...new Set(parts)].join(" | ");
}
var NodeBuffer = globalThis.Buffer;
var Utf8 = globalThis.TextDecoder;
var utf8Decoder = new Utf8("utf-8");
var MAX_SAFE = Number.MAX_SAFE_INTEGER;

// src/render.ts
var nonFinite = `number | "NaN" | "Infinity" | "-Infinity"`;
var json = {
  bool: "boolean",
  // An oid is not one of the numbers JSON has a number for: Postgres writes its text.
  int2: "number",
  int4: "number",
  oid: "string",
  float4: nonFinite,
  float8: nonFinite,
  int8: "number",
  numeric: nonFinite,
  text: "string",
  varchar: "string",
  bpchar: "string",
  name: "string",
  char: "string",
  citext: "string",
  uuid: "string",
  time: "string",
  timetz: "string",
  interval: "string",
  date: "string",
  timestamp: "string",
  timestamptz: "string",
  bytea: "string",
  money: "string",
  inet: "string",
  cidr: "string",
  macaddr: "string",
  macaddr8: "string",
  xml: "string",
  bit: "string",
  varbit: "string",
  tsvector: "string",
  tsquery: "string",
  regclass: "string",
  regtype: "string",
  int4range: "string",
  int8range: "string",
  numrange: "string",
  tsrange: "string",
  tstzrange: "string",
  daterange: "string",
  int4multirange: "string",
  int8multirange: "string",
  nummultirange: "string",
  tsmultirange: "string",
  tstzmultirange: "string",
  datemultirange: "string",
  ltree: "string",
  lquery: "string",
  ltxtquery: "string",
  // Types with no cast to JSON, which Postgres writes inside a document as their text: built-in
  // geometric and system types, and the extensions' on Neon and Supabase (pgvector, PostGIS's
  // others, cube, seg, isn, intarray, h3, hll, ip4r, pgx_ulid, prefix, rdkit, roaringbitmap,
  // semver, unit, VectorChord).
  point: "string",
  line: "string",
  lseg: "string",
  box: "string",
  path: "string",
  polygon: "string",
  circle: "string",
  pg_lsn: "string",
  jsonpath: "string",
  xid: "string",
  xid8: "string",
  regproc: "string",
  regprocedure: "string",
  regoper: "string",
  regoperator: "string",
  regnamespace: "string",
  regrole: "string",
  regcollation: "string",
  regconfig: "string",
  regdictionary: "string",
  vector: "string",
  halfvec: "string",
  sparsevec: "string",
  geography: "string",
  box2d: "string",
  box3d: "string",
  spheroid: "string",
  raster: "string",
  cube: "string",
  seg: "string",
  ean13: "string",
  isbn: "string",
  isbn13: "string",
  ismn: "string",
  ismn13: "string",
  issn: "string",
  issn13: "string",
  upc: "string",
  query_int: "string",
  h3index: "string",
  hll: "string",
  hll_hashval: "string",
  ip4: "string",
  ip4r: "string",
  ip6: "string",
  ip6r: "string",
  ipaddress: "string",
  iprange: "string",
  ulid: "string",
  prefix_range: "string",
  mol: "string",
  qmol: "string",
  xqmol: "string",
  reaction: "string",
  bfp: "string",
  sfp: "string",
  roaringbitmap: "string",
  s3vec: "string",
  semver: "string",
  semverrange: "string",
  semvermultirange: "string",
  unit: "string",
  unitrange: "string",
  unitmultirange: "string",
  rabitq8: "string",
  rabitq4: "string",
  // An hstore is an object of its keys inside a document, each value text or null (`{"a": "1", "b": null}`).
  hstore: "Record<string, string | null>",
  // PostGIS writes a geometry through its cast to JSON: a GeoJSON geometry, `{"type":"Point","coordinates":[1,2]}`.
  geometry: "{ type: string; [key: string]: unknown }",
  // A row whose columns were not read (a subquery's): an object of them inside a document.
  record: "Record<string, unknown>"
};
var mysqlJson = { ...json, float4: "number", float8: "number", numeric: "number" };
var sqliteJson = { integer: "number", int8: "number", real: "number", numeric: "number | string", text: "string", bool: "boolean" };
var ident = (name) => /^[A-Za-z_$][\w$]*$/.test(name) ? name : JSON.stringify(name);
function renderType(t, inJson = false, dialect = "postgres") {
  switch (t.kind) {
    case "scalar": {
      if (!inJson) return kindType(scalarKind(t.name, dialect));
      const parts = t.name.split("|").map((name) => (dialect === "sqlite" ? sqliteJson : dialect === "mysql" ? mysqlJson : json)[name] ?? "unknown");
      return parts.includes("unknown") ? "unknown" : [...new Set(parts.flatMap((part) => part.split(" | ")))].join(" | ");
    }
    case "enum":
      return t.labels.length ? t.labels.map((l) => JSON.stringify(l)).join(" | ") : "string";
    case "array": {
      if ((t.of.kind === "scalar" && t.of.name === "record" || t.of.kind === "composite") && !inJson) return "string";
      const inner = renderType(t.of, inJson, dialect) + (t.nullable_items !== false ? " | null" : "");
      return /[|&]/.test(inner) ? `(${inner})[]` : `${inner}[]`;
    }
    // A JSON value whose shape the statement builds.
    case "object":
      return renderFields(t.fields, dialect);
    // A composite whose columns the catalog gave: on the wire it is a row value like `record`,
    // which no driver parses; inside a JSON document the database writes it as an object.
    case "composite":
      return inJson ? renderFields(t.fields, dialect) : "string";
    case "list": {
      const inner = renderType(t.of, true, dialect) + (t.nullable_items ? " | null" : "");
      return /[|&]/.test(inner) ? `(${inner})[]` : `${inner}[]`;
    }
    case "json":
      return t.schema === void 0 ? "unknown" : schemaType(t.schema);
    // Only a parameter is one; no column is.
    case "rows":
      return renderParamType(t, dialect);
    case "unknown":
      return "unknown";
  }
}
function schemaType(schema, input = false) {
  if (schema === false) return "never";
  if (schema === null || typeof schema !== "object" || Array.isArray(schema)) return "unknown";
  const m = schema;
  const sub = (s) => schemaType(s, input);
  if (Array.isArray(m.anyOf)) return union(m.anyOf.map(sub));
  if (Array.isArray(m.enum)) return union(m.enum.map(literalType));
  if (m.not !== void 0) return "never";
  const kinds = typeof m.type === "string" ? [m.type] : Array.isArray(m.type) ? m.type.filter((k) => typeof k === "string") : [];
  return kinds.length ? union(kinds.map((kind) => kindType2(kind, m, input))) : "unknown";
}
function kindType2(kind, m, input = false) {
  const schemaType_ = (s) => schemaType(s, input);
  switch (kind) {
    case "string":
      return "string";
    case "integer":
    case "number":
      return "number";
    case "boolean":
      return "boolean";
    case "null":
      return "null";
    case "array": {
      const prefix = Array.isArray(m.prefixItems) ? m.prefixItems.map(schemaType_) : [];
      const rest = m.items === void 0 ? "unknown" : schemaType_(m.items);
      if (!prefix.length) return rest === "never" ? "[]" : `${grouped(rest)}[]`;
      const min = typeof m.minItems === "number" ? m.minItems : 0;
      const items = prefix.map((item, i) => i < min ? item : `${grouped(item)}?`);
      if (rest !== "never") items.push(`...${grouped(rest)}[]`);
      return `[${items.join(", ")}]`;
    }
    case "object": {
      const properties = m.properties !== null && typeof m.properties === "object" && !Array.isArray(m.properties) ? m.properties : {};
      const required = Array.isArray(m.required) ? m.required : [];
      const fields = Object.entries(properties).map(([key, value]) => `${ident(key)}${required.includes(key) ? "" : "?"}: ${schemaType_(value)}`);
      const open = m.additionalProperties === void 0 || m.additionalProperties === true;
      const rest = m.additionalProperties === void 0 || m.additionalProperties === false || input && open && Object.keys(properties).length > 0 ? "never" : schemaType_(m.additionalProperties);
      if (rest !== "never") fields.push(`[key: string]: ${fields.length ? "unknown" : rest}`);
      if (fields.length) return `{ ${fields.join("; ")} }`;
      return m.additionalProperties === void 0 ? "Record<string, unknown>" : "Record<never, never>";
    }
    default:
      return "unknown";
  }
}
function literalType(v) {
  if (v === null) return "null";
  if (typeof v === "string") return JSON.stringify(v);
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (Array.isArray(v)) return `[${v.map(literalType).join(", ")}]`;
  if (typeof v === "object") {
    const entries = Object.entries(v);
    return entries.length ? `{ ${entries.map(([key, x]) => `${ident(key)}: ${literalType(x)}`).join("; ")} }` : "Record<never, never>";
  }
  return "unknown";
}
function union(parts) {
  const kept = [...new Set(parts)];
  if (kept.includes("unknown")) return "unknown";
  const real = kept.filter((p) => p !== "never");
  return real.length ? real.join(" | ") : "never";
}
function grouped(ts) {
  let depth = 0;
  let quoted = false;
  for (let i = 0; i < ts.length; i++) {
    const c = ts[i];
    if (quoted) {
      if (c === "\\") i++;
      else if (c === '"') quoted = false;
    } else if (c === '"') quoted = true;
    else if ("{([<".includes(c)) depth++;
    else if ("})]>".includes(c)) depth--;
    else if (c === "|" && depth === 0) return `(${ts})`;
  }
  return ts;
}
function lastOfEachName(items) {
  return items.filter((item, i) => !items.slice(i + 1).some((later) => later.name === item.name));
}
function renderFields(fields, dialect) {
  fields = lastOfEachName(fields);
  return fields.length ? `{ ${fields.map((f) => `${ident(f.name)}: ${renderType(f.type, true, dialect)}${f.nullable ? " | null" : ""}`).join("; ")} }` : "Record<never, never>";
}
function declaredType(t, declared) {
  return declared !== void 0 && t.kind === "json" && t.schema !== void 0 ? schemaType(t.schema, true) : void 0;
}
function renderParamType(t, dialect = "postgres", inRow = false) {
  if (t.kind === "scalar" && dialect !== "sqlite") {
    if (t.name === "int8") return "number | bigint | string";
    if (t.name.split("|").every((name) => name === "timestamp" || name === "timestamptz" || name === "date")) return "string";
  }
  if (t.kind === "scalar" && dialect === "sqlite" && t.name === "integer") return "number";
  if (t.kind === "scalar" && dialect === "sqlite" && t.name === "int8") return "number | bigint";
  if (t.kind === "scalar" && dialect === "sqlite" && t.name === "numeric") return "number | string | boolean";
  if (t.kind === "scalar" && dialect === "sqlite" && t.name === "bool") return "boolean | number";
  if (t.kind === "scalar" && (t.name === "bytea" || t.name === "blob")) return "Uint8Array";
  if (t.kind === "scalar" && t.name === "numeric" && dialect !== "sqlite") return "string";
  if (t.kind === "json") return t.schema === void 0 ? "unknown" : schemaType(t.schema);
  if (t.kind === "rows") {
    const fields = t.fields.map((f) => `${ident(f.name)}${f.optional ? "?" : ""}: ${declaredType(f.type, f.schema) ?? renderParamType(f.type, dialect, true)}${f.nullable ? " | null" : ""}`);
    const row = fields.length ? `{ ${fields.join("; ")} }` : "Record<never, never>";
    return t.one ? row : `readonly ${row}[]`;
  }
  if (t.kind === "array") {
    if (t.of.kind === "scalar" && t.of.name === "record" || t.of.kind === "composite") return "string | string[]";
    if (inRow) return `(${renderParamType(t.of, dialect, inRow)} | null)[]`;
    const inner = renderParamType(t.of, dialect);
    return /[|&]/.test(inner) ? `(${inner})[]` : `${inner}[]`;
  }
  return renderType(t, false, dialect);
}

// src/module-types.ts
function queryErrorType(dialect, errors) {
  if (!errors) return `import("reylo").QueryError<${JSON.stringify(dialect)}>`;
  const name = { postgres: "PostgresQueryError", mysql: "MysqlQueryError", sqlite: "SqliteQueryError" }[dialect];
  const names = (field, list) => list.map((n) => field === "columns" ? `readonly [${n.split(", ").map((c) => JSON.stringify(c)).join(", ")}]` : JSON.stringify(n)).join(" | ");
  const codes = Object.entries(errors).map(([code, fields]) => `  ${JSON.stringify(code)}: { ${Object.entries(fields).map(([field, list]) => `${field}: ${names(field, list)}`).join("; ")} };`);
  return codes.length ? `import("reylo").${name}<{
${codes.join("\n")}
}>` : `import("reylo").${name}<{}>`;
}
function paramType(q, rendered) {
  if (q.type.kind === "unknown") return "unknown";
  return q.nullable ? `${rendered} | null` : rendered;
}
function fieldComment(comment, indent = "") {
  const text = (comment ?? "").replace(/\r\n?/g, "\n").replace(/[ \t]+$/gm, "").trim();
  if (!text) return "";
  if (!text.includes("\n")) return `/** ${text.replaceAll("*/", "*\\/")} */`;
  return docComment(text, void 0, "", indent).trim();
}
function objectType(fields) {
  const docs = fields.map(([, comment]) => fieldComment(comment, "  "));
  if (!docs.some(Boolean)) return `{ ${fields.map(([text]) => text).join("; ")} }`;
  return `{
${fields.map(([text], i) => `${docs[i] ? `  ${docs[i]}
` : ""}  ${text};`).join("\n")}
}`;
}
var utf82 = new TextEncoder();
var fromUtf8 = new TextDecoder();
function withinFile(start, length, size) {
  const from = Math.max(0, Math.min(start, size));
  return { start: from, length: Math.max(0, Math.min(length, size - from)) };
}
function moduleTypes(sql, analysis, dialect, lexed, strictParams, projectFile = ".reylo.yaml") {
  let names = lexed?.params ?? [];
  let placeholders = lexed?.placeholders ?? [];
  if (dialect === "mysql") {
    names = analysis.params.map((q) => q.name);
    placeholders = analysis.rewritten.spans.map(([start, end], k) => ({ name: analysis.rewritten.order[k], start, end }));
  }
  const diagnostics = analysis.diagnostics.map((d) => ({ message: d.message, start: d.start, length: d.length, code: d.code }));
  if (strictParams && !analysis.diagnostics.length) {
    const bytes = utf82.encode(sql);
    for (const q of analysis.params) {
      if (q.type.kind !== "unknown") continue;
      const at = placeholders.find((h) => h.name === q.name);
      const span = at ? fromUtf8.decode(bytes.subarray(at.start, at.end)) : `:${q.name}`;
      const written = span.replace(/\s*::[\s\S]*$/, "");
      const length = at ? utf82.encode(written).length : 1;
      const message = `Nothing in the statement gives the parameter ${written} a type; cast it, as in ${written}::text, or set strict_params: false in ${projectFile}.`;
      diagnostics.push({ message, start: at?.start ?? 0, length, code: 12 });
    }
  }
  const cardinality = analysis.cardinality;
  if (analysis.diagnostics.some((d) => d.code === 6) || dialect === "postgres" && analysis.kind === "") return { diagnostics, params: "unknown", row: "unknown", cardinality, names, queryError: queryErrorType(dialect, void 0) };
  const columns = lastOfEachName(analysis.columns).map((c) => [`${ident(c.name)}: ${renderType(c.type, false, dialect)}${c.nullable ? " | null" : ""}`, c.comment]);
  const typed = analysis.params.map((q) => [q.name, paramType(q, declaredType(q.type, q.schema) ?? renderParamType(q.type, dialect)), q.comment]);
  const optional = new Set(analysis.params.filter((q) => q.nullable || q.schema !== null && typeof q.schema === "object" && "default" in q.schema).map((q) => q.name));
  const paramTypes = typed.map(([name, type, comment]) => [`${ident(name)}${optional.has(name) ? "?" : ""}: ${type}`, comment]);
  return {
    diagnostics,
    params: paramTypes.length ? objectType(paramTypes) : "Record<never, never>",
    row: columns.length ? objectType(columns) : "never",
    cardinality,
    names,
    queryError: queryErrorType(dialect, analysis.errors)
  };
}

// src/type-format.ts
function parseType(text) {
  const tokens = text.match(/"(?:[^"\\]|\\.)*"|[A-Za-z_$][\w$]*(?:<[^<>]*>)?|\[\]|[{}()[\]|;:?,]/g) ?? [];
  let at = 0;
  const peek = () => tokens[at];
  const take = (expected) => {
    const token = tokens[at++];
    if (token === void 0 || expected !== void 0 && token !== expected) throw new Error(`type-format: expected ${expected ?? "a token"} at ${at - 1} in ${text}`);
    return token;
  };
  const union2 = () => {
    const of = [postfix()];
    while (peek() === "|") {
      take("|");
      of.push(postfix());
    }
    return of.length === 1 ? of[0] : { kind: "union", of };
  };
  const postfix = () => {
    let node2 = primary();
    while (peek() === "[]") {
      take("[]");
      node2 = { kind: "array", of: node2 };
    }
    return node2;
  };
  const primary = () => {
    const token = peek();
    if (token === "(") {
      take("(");
      const inner = union2();
      take(")");
      return inner;
    }
    if (token === "{") return object2();
    return { kind: "name", text: take() };
  };
  const object2 = () => {
    take("{");
    const members = [];
    while (peek() !== "}") {
      let key;
      if (peek() === "[") {
        take("[");
        const name = take();
        take(":");
        const of = take();
        take("]");
        key = `[${name}: ${of}]`;
      } else key = take();
      if (peek() === "?") key += take("?");
      take(":");
      members.push({ key, type: union2() });
      if (peek() === ";") take(";");
    }
    take("}");
    return { kind: "object", members };
  };
  const node = union2();
  if (at !== tokens.length) throw new Error(`type-format: unread text after ${tokens.slice(0, at).join(" ")} in ${text}`);
  return node;
}
var flat = (node) => {
  switch (node.kind) {
    case "name":
      return node.text;
    case "object":
      return node.members.length ? `{ ${node.members.map((m) => `${m.key}: ${flat(m.type)}`).join("; ")} }` : "{}";
    case "union":
      return node.of.map(flat).join(" | ");
    case "array":
      return node.of.kind === "union" ? `(${flat(node.of)})[]` : `${flat(node.of)}[]`;
  }
};
function print(node, indent, lead, width, reserve = 0) {
  const one = flat(node);
  if (lead + one.length + reserve <= width) return one;
  switch (node.kind) {
    case "name":
      return one;
    case "object": {
      const inner = " ".repeat(indent + 2);
      return `{
${node.members.map((m) => `${inner}${m.key}: ${print(m.type, indent + 2, indent + 2 + m.key.length + 2, width, 1)};`).join("\n")}
${" ".repeat(indent)}}`;
    }
    case "union": {
      let line2 = lead;
      return node.of.map((n, i) => {
        const tail = i < node.of.length - 1 ? 3 + flat({ kind: "union", of: node.of.slice(i + 1) }).length + reserve : reserve;
        const text = print(n, indent, line2, width, tail);
        const last = text.split("\n").at(-1);
        line2 = (text.includes("\n") ? last.length : line2 + last.length) + 3;
        return text;
      }).join(" | ");
    }
    case "array":
      return node.of.kind === "union" ? `(${print(node.of, indent, lead + 1, width, reserve + 3)})[]` : `${print(node.of, indent, lead, width, reserve + 2)}[]`;
  }
}
function formatType(text, width) {
  return print(parseType(text), 0, 0, width);
}
function resultType(row, cardinality) {
  if (cardinality === "none" || row === "never") return "void";
  const wrapped = /\|/.test(row.replace(/\{[^{}]*\}/g, "")) ? `(${row})` : row;
  if (cardinality === "one") return row;
  if (cardinality === "maybeOne") return `${row} | null`;
  return `${wrapped}[]`;
}

// src/play-result.ts
function playResult(sql, dialect, outcome, options = {}) {
  const place3 = placer(sql);
  const width = options.width ?? Infinity;
  const ms = options.ms ?? 0;
  const placed = (d) => ({ message: d.message, code: d.code, ...place3(d.start, d.length) });
  if ("error" in outcome) return { sql, params: "unknown", returns: "unknown", diagnostics: [placed({ message: outcome.error.message, start: 0, length: 1, code: outcome.error.code ?? 5 })], ms };
  try {
    const types = moduleTypes(sql, outcome.analysis, dialect, outcome.lexed, options.strictParams ?? true);
    return {
      sql,
      ...types.params === "Record<never, never>" ? {} : { params: formatType(types.params, width) },
      returns: formatType(types.row === "unknown" ? "unknown" : resultType(types.row, types.cardinality), width),
      cardinality: types.cardinality,
      diagnostics: types.diagnostics.map(placed),
      ms
    };
  } catch (e) {
    return { sql, params: "unknown", returns: "unknown", diagnostics: [placed({ message: e.message, start: 0, length: 1, code: 5 })], ms };
  }
}
function placer(sql) {
  const bytes = new TextEncoder().encode(sql);
  const index = new Uint32Array(bytes.length + 1);
  let u = 0;
  for (let b = 0; b < bytes.length; ) {
    const lead = bytes[b];
    const n = lead < 128 ? 1 : lead < 224 ? 2 : lead < 240 ? 3 : 4;
    for (let k = 0; k < n && b + k < bytes.length; k++) index[b + k] = u;
    b += n;
    u += n === 4 ? 2 : 1;
  }
  index[bytes.length] = sql.length;
  const lineStarts = [0];
  for (let i = 0; i < sql.length; i++) if (sql.charCodeAt(i) === 10) lineStarts.push(i + 1);
  const at = (i) => {
    let lo = 0;
    let hi = lineStarts.length - 1;
    while (lo < hi) {
      const mid = lo + hi + 1 >> 1;
      if (lineStarts[mid] <= i) lo = mid;
      else hi = mid - 1;
    }
    return { line: lo + 1, column: i - lineStarts[lo] + 1 };
  };
  const clamp = (byte) => index[Math.max(0, Math.min(byte, bytes.length))];
  return (start, length) => {
    const a = at(clamp(start));
    const b = at(clamp(start + length));
    return { line: a.line, column: a.column, endLine: b.line, endColumn: b.column };
  };
}

// src/play.ts
var PLAY_USAGE = `Usage: reylo play [--port <n>] [--no-open]

Serves the playground on http://127.0.0.1: a query editor whose Params, Returns and errors are
Reylo's analysis of the query against the project's database, at every keystroke. Nothing is run.
The database is the project's own, the one the type check reads; with none, it says how to set it.
It opens the page in the browser; --no-open leaves it closed, for a script or an agent.

  http://127.0.0.1:<port>/?q=<sql>              the page, with a query in it
  GET  /api/analyze?q=<sql>                       a query's Params, Returns and diagnostics, as JSON
  POST /api/analyze  {"sql": "<sql>"}             the same
  GET  /api/schema                                the tables, their columns, functions and types`;
var DEFAULT_PORT = 4983;
async function play(args) {
  const options = parseArgs(args);
  if (typeof options === "string") {
    console.error(`reylo play: ${options}

${PLAY_USAGE}`);
    return 2;
  }
  if (options.help) {
    console.log(PLAY_USAGE);
    return 0;
  }
  let running;
  try {
    running = await startPlay({ port: options.port });
  } catch (e) {
    console.error(`reylo play: ${e.message}`);
    return 1;
  }
  const { url, label, notice } = running;
  if (notice) console.log(styleText("yellow", notice));
  console.log(`${styleText("bold", "Reylo playground")} at ${styleText("cyan", url)}
${styleText("dim", `${label}. The API: GET ${url}api/analyze?q=<sql>. Ctrl-C stops it.`)}`);
  if (options.open) openBrowser(url);
  await new Promise((done) => {
    process.once("SIGINT", done);
    process.once("SIGTERM", done);
  });
  await running.close();
  return 0;
}
async function startPlay(options = {}) {
  const cwd = options.cwd ?? process.cwd();
  const page = pageDir(cwd);
  if (!page) throw new Error("the playground's page is not in this install of reylo; reinstall reylo.");
  const backend = await openBackend(cwd, options.env ?? process.env);
  const server = createServer((req, res) => {
    handle(req, res, backend, page, () => server.address()).catch((e) => send(res, 500, { error: e.message }));
  });
  const port = await listen(server, options.port);
  if (port === void 0) {
    await backend.close();
    throw new Error(`port ${options.port ?? DEFAULT_PORT} is in use; name another with --port.`);
  }
  return {
    url: `http://127.0.0.1:${port}/`,
    label: backend.label,
    ...backend.notice ? { notice: backend.notice } : {},
    async close() {
      server.closeAllConnections();
      await new Promise((done) => server.close(() => done()));
      await backend.close();
    }
  };
}
function parseArgs(args) {
  const out2 = { open: true, help: false };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    const [flag, inline] = a.startsWith("--") && a.includes("=") ? [a.slice(0, a.indexOf("=")), a.slice(a.indexOf("=") + 1)] : [a, void 0];
    const value = () => inline ?? args[++i];
    if (flag === "--help" || flag === "-h") out2.help = true;
    else if (flag === "--no-open") out2.open = false;
    else if (flag === "--port") {
      const n = Number(value());
      if (!Number.isInteger(n) || n < 0 || n > 65535) return `--port takes a port number`;
      out2.port = n;
    } else return `unknown argument ${a}`;
  }
  return out2;
}
function pageDir(cwd) {
  const candidates = [process.env.REYLO_PLAY_PAGE];
  for (const from of [join5(cwd, "noop.js"), import.meta.filename]) {
    try {
      let dir = dirname4(createRequire4(from).resolve("reylo"));
      while (dir !== dirname4(dir) && !existsSync4(join5(dir, "package.json"))) dir = dirname4(dir);
      candidates.push(join5(dir, "play"));
    } catch {
    }
  }
  candidates.push(join5(import.meta.dirname, "..", "dist", "reylo", "play"));
  return candidates.find((dir) => !!dir && existsSync4(join5(dir, "index.html")));
}
async function openBackend(cwd, env) {
  const session = await Session.open(cwd, env);
  const { project } = session;
  if (project.error || !project.url) {
    await session.close();
    throw new Error(project.error ?? `${project.missingUrl} reylo play reads the project's own database; to try Reylo without one, open https://reylo.dev/play.`);
  }
  return databaseBackend(session);
}
async function databaseBackend(session) {
  const { project } = session;
  const dialect = project.dialect;
  const schema = await session.schema();
  if (schema.value === null || schema.fatal) throw new Error(schema.fatal ? schema.error : session.cannotConnect(schema.error));
  const queries = CATALOG_QUERIES[dialect];
  const rows = async (sql) => sql ? await session.query(sql).catch(() => []) : [];
  const cat2 = catalog(dialect, await rows(queries.tables), await rows(queries.functions), await rows(queries.types));
  return {
    dialect,
    ...project.notice ? { notice: project.notice } : {},
    label: `${dialect === "postgres" ? "Postgres" : dialect === "mysql" ? "MySQL" : "SQLite"} at ${session.where()} (${project.urlSource})`,
    schema: await schemaDdl2(dialect, (sql) => session.query(sql)) ?? schemaText(dialect, cat2),
    catalog: cat2,
    async analyze(sql, width) {
      const t = performance.now();
      const outcome = await session.analyze(sql, { store: false });
      const ms = performance.now() - t;
      if (!outcome.ok) return playResult(sql, dialect, { error: { message: outcome.message, code: outcome.code } }, { width, ms });
      let lexed;
      try {
        lexed = session.lex(sql);
      } catch {
      }
      return playResult(sql, dialect, { analysis: outcome.analysis, lexed }, { strictParams: project.strictParams, width, ms });
    },
    close: () => session.close()
  };
}
async function schemaDdl2(dialect, query) {
  try {
    if (dialect === "sqlite") {
      const rows2 = await query(`select sql as ddl from sqlite_schema where sql is not null and name not like 'sqlite_%' order by case type when 'table' then 0 when 'view' then 1 when 'index' then 2 else 3 end, name`);
      return rows2.map(([ddl]) => `${String(ddl).trim()};`).join("\n\n");
    }
    if (dialect === "mysql") {
      const tables = await query("select table_name, table_type from information_schema.tables where table_schema = database() order by table_type = 'VIEW', table_name");
      const out2 = [];
      for (const [name, type] of tables) {
        const [row] = await query(`show create ${type === "VIEW" ? "view" : "table"} \`${name.replace(/`/g, "``")}\``);
        out2.push(`${String(row?.[1] ?? "").replace(/ AUTO_INCREMENT=\d+/, "")};`);
      }
      return out2.join("\n\n");
    }
    const rows = await query(POSTGRES_SCHEMA);
    return rows.map(([ddl]) => String(ddl)).join("\n\n");
  } catch {
    return void 0;
  }
}
var POSTGRES_SCHEMA = `with q as (
  select n.oid, case when n.nspname = 'public' then '' else quote_ident(n.nspname) || '.' end as p
  from pg_namespace n where n.nspname = any(current_schemas(false)) and n.nspname <> 'pg_catalog'
)
select ddl from (
  select 0 as k, t.typname::text as name, format('create type %s%s as enum (%s);', q.p, quote_ident(t.typname),
    (select string_agg(quote_literal(e.enumlabel), ', ' order by e.enumsortorder) from pg_enum e where e.enumtypid = t.oid)) as ddl
  from pg_type t join q on q.oid = t.typnamespace where t.typtype = 'e'
  union all
  select 0, t.typname::text, format('create domain %s%s as %s%s%s;', q.p, quote_ident(t.typname), format_type(t.typbasetype, t.typtypmod),
    case when t.typnotnull then ' not null' else '' end,
    coalesce((select string_agg(' ' || pg_get_constraintdef(con.oid), '' order by con.conname) from pg_constraint con where con.contypid = t.oid and con.contype = 'c'), ''))
  from pg_type t join q on q.oid = t.typnamespace where t.typtype = 'd'
  union all
  select 1, c.relname::text, format(E'create table %s%s (
%s
);', q.p, quote_ident(c.relname), (
    select string_agg(line, E',
' order by ord) from (
      select a.attnum::int as ord, '  ' || quote_ident(a.attname) || ' ' || format_type(a.atttypid, a.atttypmod)
        || case when a.attidentity in ('a', 'd') then ' generated ' || case a.attidentity when 'a' then 'always' else 'by default' end || ' as identity' else '' end
        || case when a.attgenerated <> '' then ' generated always as (' || pg_get_expr(d.adbin, d.adrelid) || ')' || case a.attgenerated when 's' then ' stored' else ' virtual' end
                when d.adbin is not null and a.attidentity = '' then ' default ' || pg_get_expr(d.adbin, d.adrelid) else '' end
        || case when a.attnotnull then ' not null' else '' end as line
      from pg_attribute a left join pg_attrdef d on d.adrelid = a.attrelid and d.adnum = a.attnum
      where a.attrelid = c.oid and a.attnum > 0 and not a.attisdropped
      union all
      select 100000 + row_number() over (order by con.contype <> 'p', con.contype, con.conname)::int, '  constraint ' || quote_ident(con.conname) || ' ' || pg_get_constraintdef(con.oid)
      from pg_constraint con where con.conrelid = c.oid and con.contype in ('p', 'u', 'f', 'c', 'x')
    ) lines))
  from pg_class c join q on q.oid = c.relnamespace where c.relkind in ('r', 'p', 'f')
  union all
  select 2, c.relname::text, format(E'create %sview %s%s as
%s;', case c.relkind when 'm' then 'materialized ' else '' end, q.p, quote_ident(c.relname), rtrim(rtrim(pg_get_viewdef(c.oid, true)), ';'))
  from pg_class c join q on q.oid = c.relnamespace where c.relkind in ('v', 'm')
  union all
  select 3, i.relname::text, pg_get_indexdef(i.oid) || ';'
  from pg_index x join pg_class i on i.oid = x.indexrelid join pg_class c on c.oid = x.indrelid join q on q.oid = c.relnamespace
  where not exists (select 1 from pg_constraint con where con.conindid = x.indexrelid and con.contype in ('p', 'u', 'x'))
) s order by k, name`;
function schemaText(dialect, cat2) {
  const q = (name) => /^[a-z_][a-z0-9_]*$/.test(name) ? name : dialect === "mysql" ? `\`${name}\`` : `"${name.replace(/"/g, '""')}"`;
  return cat2.tables.map((t) => {
    const width = Math.max(...t.columns.map((c) => q(c.name).length));
    return `create table ${q(t.name)} (
${t.columns.map((c) => `  ${q(c.name).padEnd(width)} ${c.type}${c.nullable ? "" : " not null"}`).join(",\n")}
);`;
  }).join("\n\n");
}
function listen(server, port) {
  const tries = port === void 0 ? Array.from({ length: 20 }, (_, i) => DEFAULT_PORT + i) : [port];
  return new Promise((done) => {
    const attempt = (i) => {
      if (i >= tries.length) return done(void 0);
      server.once("error", (e) => e.code === "EADDRINUSE" ? attempt(i + 1) : done(void 0));
      server.listen(tries[i], "127.0.0.1", () => {
        server.removeAllListeners("error");
        const address = server.address();
        done(typeof address === "object" && address ? address.port : void 0);
      });
    };
    attempt(0);
  });
}
var TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".woff2": "font/woff2", ".svg": "image/svg+xml", ".wasm": "application/wasm", ".json": "application/json" };
async function handle(req, res, backend, page, address) {
  const a = address();
  const port = typeof a === "object" && a ? a.port : 0;
  const local = (host) => !!host && [`127.0.0.1:${port}`, `localhost:${port}`, `[::1]:${port}`].includes(host);
  const origin = req.headers.origin;
  if (!local(req.headers.host) || origin !== void 0 && !local(origin.replace(/^http:\/\//, ""))) return send(res, 403, { error: "the playground answers this machine's own pages and tools only" });
  const url = new URL(req.url ?? "/", `http://${req.headers.host}`);
  if (url.pathname === "/api/analyze") {
    let sql = url.searchParams.get("q") ?? url.searchParams.get("sql");
    let width = Number(url.searchParams.get("width") ?? Infinity);
    if (req.method === "POST") {
      let body;
      try {
        body = JSON.parse(await readBody(req) || "{}");
      } catch {
        return send(res, 400, { error: "the body is not JSON" });
      }
      sql = typeof body.sql === "string" ? body.sql : typeof body.q === "string" ? body.q : sql;
      if (typeof body.width === "number") width = body.width;
    } else if (req.method !== "GET") return send(res, 405, { error: "GET or POST" });
    if (sql === null) return send(res, 400, { error: 'name the query: ?q=<sql>, or a JSON body {"sql": "<sql>"}' });
    return send(res, 200, await backend.analyze(sql, Number.isFinite(width) && width > 0 ? width : Infinity));
  }
  if (url.pathname === "/api/schema") return send(res, 200, { dialect: backend.dialect, database: backend.label, ...backend.catalog });
  if (url.pathname === "/api/page") return send(res, 200, { dialect: backend.dialect, label: backend.label, schema: backend.schema, catalog: backend.catalog });
  const file = url.pathname === "/" ? join5(page, "index.html") : join5(page, decodeURIComponent(url.pathname));
  const inside = file.startsWith(page + sep2) && existsSync4(file) && statSync2(file).isFile();
  const path = inside ? file : join5(page, "index.html");
  res.writeHead(200, { "content-type": TYPES[extname(path)] ?? "application/octet-stream", "cache-control": "no-cache", "x-content-type-options": "nosniff" });
  res.end(readFileSync5(path));
}
function send(res, status, body) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((done, fail) => {
    let text = "";
    req.setEncoding("utf8");
    req.on("data", (chunk) => {
      text += chunk;
      if (text.length > 1e6) req.destroy(new Error("the body is over a megabyte"));
    });
    req.on("end", () => done(text));
    req.on("error", fail);
  });
}
function openBrowser(url) {
  const [command, args] = process.platform === "darwin" ? ["open", [url]] : process.platform === "win32" ? ["cmd", ["/c", "start", "", url]] : ["xdg-open", [url]];
  spawn(command, args, { stdio: "ignore", detached: true }).on("error", () => {
  }).unref();
}

// src/commands.ts
var USAGE = `Usage: reylo generate [paths...] [--force]

Analyzes every .sql file under the paths (by default the current directory) into .reylo/: the
cache that the type check and the build steps read. A file of several statements (a migration)
is skipped, and a run that finds no query fails. --force analyzes each file against the database
even when .reylo/ holds it.

Which files are queries can be set in .reylo.yaml; the globs are relative to it:

  cli:
    include: ["src/**/*.sql"]   # instead of every .sql file
    exclude: ["src/legacy/**"]  # in addition to dependencies, build output and what git ignores`;
var INCLUDE = ["**/*.sql", "**/.server/**/*.sql"];
var EXCLUDE = ["**/node_modules/**", "**/{dist,build,out,target,coverage}/**"];
var shown = (path) => relative2(process.cwd(), path) || ".";
var paint = (format, text) => styleText2(format, text);
async function sqlFiles(dir, include = INCLUDE, exclude = []) {
  const negated = (p) => p.startsWith("!") && !p.startsWith("!(");
  const patterns = include.filter((p) => !negated(p)).flatMap((p) => {
    const q = p.replace(/\/$/, "");
    return q.endsWith("*") ? [q] : [q, `${q}/**`];
  });
  const excluded = [...EXCLUDE, ...exclude, ...include.filter(negated).map((p) => p.slice(1))];
  const entries = await Array.fromAsync(glob(patterns, { cwd: dir, exclude: excluded, withFileTypes: true }));
  return entries.filter((e) => !e.isDirectory() && e.name.endsWith(".sql")).map((e) => resolve3(e.parentPath, e.name));
}
function gitIgnored(dir, files) {
  if (!files.length) return /* @__PURE__ */ new Set();
  const r = spawnSync2("git", ["check-ignore", "-z", "--stdin"], { cwd: dir, input: files.join("\0"), encoding: "utf8" });
  return r.status === 0 ? new Set(r.stdout.split("\0").filter(Boolean).map((f) => resolve3(dir, f))) : /* @__PURE__ */ new Set();
}
function located(text, start, length) {
  const bytes = Buffer.from(text, "utf8");
  const before = bytes.subarray(0, start).toString("utf8");
  const lineNumber = before.split("\n").length;
  const column = before.length - before.lastIndexOf("\n") - 1;
  const line2 = text.split("\n")[lineNumber - 1].replace(/\r$/, "");
  const span = Math.max(1, Math.min(bytes.subarray(start, start + length).toString("utf8").length, line2.length - column));
  const gutter = String(lineNumber);
  return {
    at: `${lineNumber}:${column + 1}`,
    frame: [`  ${paint("dim", `${gutter} |`)} ${line2}`, `  ${paint("dim", `${" ".repeat(gutter.length)} |`)} ${line2.slice(0, column).replace(/[^\t]/g, " ")}${paint("red", "^".repeat(span))}`]
  };
}
var NOT_A_QUERY = /^A typed \.sql file holds one statement and this one holds several, |^cannot insert multiple commands into a prepared statement/;
async function generate(args) {
  const force = args.includes("--force");
  const unknown = args.filter((a) => a.startsWith("-") && a !== "--force");
  if (unknown.length) {
    console.error(`reylo generate: unknown option ${unknown.join(", ")}

${USAGE}`);
    return 2;
  }
  const paths = args.filter((a) => !a.startsWith("-"));
  const started = performance.now();
  const named = /* @__PURE__ */ new Set();
  const found = /* @__PURE__ */ new Set();
  for (const arg of paths.length ? paths : ["."]) {
    const full = resolve3(arg);
    if (!existsSync5(full)) {
      console.error(`reylo generate: ${arg} does not exist.`);
      return 2;
    }
    if (statSync3(full).isDirectory()) {
      const files = await sqlFiles(full);
      const ignored = gitIgnored(full, files);
      for (const file of files) if (!ignored.has(file)) found.add(file);
    } else if (full.endsWith(".sql")) named.add(full);
    else {
      console.error(`reylo generate: ${arg} is not a .sql file or a directory.`);
      return 2;
    }
  }
  const projects2 = /* @__PURE__ */ new Map();
  for (const file of [...named, ...found].sort()) {
    const session = await Session.for(dirname5(file));
    projects2.set(session, [...projects2.get(session) ?? [], file]);
  }
  for (const [session, list] of projects2) {
    const { include, exclude } = session.project.cli;
    if (!include && !exclude) continue;
    const allowed = new Set(await sqlFiles(session.root, include, exclude));
    projects2.set(session, list.filter((f) => named.has(f) || allowed.has(f)));
  }
  let typed = 0;
  const failed = [];
  const skipped = [];
  const errors = [];
  for (const [session, list] of projects2) {
    if (!list.length) continue;
    const { project } = session;
    const here = session.root === process.cwd() ? "" : `${shown(session.root)}: `;
    console.log(paint("dim", `${here}${project.dialect} at ${session.where()} (${project.urlSource})`));
    let unusable = project.error ?? (project.url ? void 0 : project.missingUrl);
    if (project.notice && project.url) console.log(paint("yellow", project.notice));
    let offline = false;
    if (!unusable) {
      const schema = await session.schema();
      if (schema.fatal) unusable = schema.error;
      else if (schema.value === null) {
        offline = true;
        console.log(paint("dim", `${session.cannotConnect(schema.error)}; the files are read from .reylo/ as they are.`));
      }
    }
    if (unusable) errors.push([paint("red", unusable)]);
    const rows = [];
    for (const file of list) {
      const fail = (...lines) => {
        rows.push({ file, ok: false });
        errors.push(lines);
      };
      if (unusable) {
        rows.push({ file, ok: false });
        continue;
      }
      const sql = readFileSync6(file, "utf8");
      const outcome = await session.analyze(sql, { force });
      if (!outcome.ok) {
        fail(`${paint("bold", shown(file))}: ${offline ? force ? "--force needs the database, which cannot be reached" : "not in .reylo/, and the database cannot be reached" : outcome.message}`);
        continue;
      }
      const { diagnostics } = outcome.analysis;
      if (diagnostics.some((d) => NOT_A_QUERY.test(d.message))) {
        skipped.push(file);
        continue;
      }
      if (diagnostics.length) {
        fail(...diagnostics.flatMap((d) => {
          const { at, frame } = located(sql, d.start, d.length);
          const whole = d.start === 0 && d.length >= Buffer.byteLength(sql.trimEnd());
          return [`${paint("bold", `${shown(file)}:${at}`)}: ${d.message}`, ...whole ? [] : frame];
        }));
        continue;
      }
      rows.push({ file, ok: true });
    }
    const width = Math.max(...rows.map((r) => shown(r.file).length));
    for (const { file, ok } of rows) {
      if (ok) typed++;
      else failed.push(file);
      console.log(`  ${shown(file).padEnd(width)}  ${ok ? paint("green", "\u2713") : paint("red", "\u2717")}`);
    }
  }
  for (const session of Session.opened()) await session.close();
  for (const lines of errors) console.log(`
${lines.join("\n")}`);
  if (skipped.length) {
    const listed = skipped.slice(0, 3).map(shown).join(", ") + (skipped.length > 3 ? ` and ${skipped.length - 3} more` : "");
    console.log(paint("dim", `
Skipped ${skipped.length === 1 ? "1 file that is" : `${skipped.length} files that are`} not one query (a migration?): ${listed}`));
  }
  const seconds = ((performance.now() - started) / 1e3).toFixed(1);
  const total = typed + failed.length;
  if (failed.length) console.log(`
${paint("red", "\u2717")} ${failed.length} of ${total} ${total === 1 ? "query" : "queries"} failed (${seconds} s)`);
  else if (typed) console.log(`
${paint("green", "\u2713")} ${typed} ${typed === 1 ? "query" : "queries"} typed (${seconds} s)`);
  else {
    const sessions2 = [...projects2.keys()];
    const own = sessions2.length === 1 ? sessions2[0].project.file : !sessions2.length && paths.length <= 1 ? findProjectFile(resolve3(paths[0] ?? ".")) : void 0;
    console.log(`${skipped.length ? "\n" : ""}No query under ${(paths.length ? paths : ["."]).join(", ")}: name the directory that holds them, or set cli.include in ${own ? shown(own) : PROJECT_FILE}.`);
    return 1;
  }
  return failed.length ? 1 : 0;
}
async function runCli(args) {
  const [command, ...rest] = args;
  if (command === "generate") return generate(rest);
  if (command === "play") return play(rest);
  if (command === void 0 || command === "help" || command === "--help" || command === "-h") {
    console.log(`${USAGE}

${PLAY_USAGE}`);
    return 0;
  }
  console.error(`reylo: unknown command ${command}

${USAGE}

${PLAY_USAGE}`);
  return 2;
}

// src/loader.ts
import { existsSync as existsSync6 } from "node:fs";
import { dirname as dirname6 } from "node:path";

// src/sqlcommenter.ts
function withSqlcommenter(text, source) {
  const tag = `/*file='${encodeURIComponent(source).replace(/'/g, "\\'")}'*/`;
  const body = text.replace(/[\s;]+$/, "");
  const semicolon = text.slice(body.length).includes(";") ? ";" : "";
  const last = body.slice(body.lastIndexOf("\n") + 1);
  return `${body}${/--|#/.test(last) ? "\n" : " "}${tag}${semicolon}`;
}

// src/schema.ts
function nullable(schema) {
  if (schema === true || typeof schema === "object" && Object.keys(schema).length === 0) return schema;
  if (typeof schema === "object" && Object.keys(schema).length === 1 && typeof schema.type === "string") return { type: [schema.type, "null"] };
  return { anyOf: [schema, { type: "null" }] };
}
var GEOJSON = { type: "object", properties: { type: { type: "string" } }, required: ["type"], description: "a GeoJSON geometry" };
function scalar(name, dialect, inJson, input) {
  if (name.includes("|")) return { anyOf: name.split("|").map((part) => scalar(part, dialect, inJson, input)) };
  if (dialect === "sqlite") {
    if (inJson || input) {
      switch (name) {
        case "integer":
        case "int8":
          return { type: "integer", format: "int64" };
        case "real":
          return { type: "number", format: "double" };
        case "text":
          return { type: "string" };
        case "blob":
          return { type: "string", format: "byte", contentEncoding: "base64" };
        case "numeric":
          return { type: ["number", "string"] };
        case "bool":
          return { type: "boolean" };
        default:
          return {};
      }
    }
    const kinds = scalarKind(name, dialect).split("|");
    if (kinds.length > 1) {
      const types = [...new Set(kinds.map((k) => kindSchema(k, name, dialect).type))];
      return { type: types.includes("number") ? types.filter((t) => t !== "integer") : types };
    }
    return kindSchema(kinds[0], name, dialect);
  }
  if (inJson) {
    const nonFinite2 = { enum: ["NaN", "Infinity", "-Infinity"] };
    switch (name) {
      case "int8":
        return { type: "integer", format: "int64" };
      case "float4":
        return dialect === "postgres" ? { anyOf: [{ type: "number", format: "float" }, nonFinite2] } : { type: "number", format: "float" };
      case "float8":
        return dialect === "postgres" ? { anyOf: [{ type: "number", format: "double" }, nonFinite2] } : { type: "number", format: "double" };
      case "numeric":
        return dialect === "postgres" ? { anyOf: [{ type: "number", format: "decimal" }, nonFinite2] } : { type: "number", format: "decimal" };
      case "bytea":
        return { type: "string", format: "hex" };
      // Postgres's own interval text: the run time converts a column's interval, never one inside a document.
      case "interval":
        return { type: "string", description: "pg type interval" };
      // A row whose columns were not read (a subquery's): an object of them.
      case "record":
        return { type: "object" };
      // An hstore: an object of its keys, each value text or null.
      case "hstore":
        return { type: "object", additionalProperties: { type: ["string", "null"] } };
      // PostGIS's cast to JSON: a GeoJSON geometry.
      case "geometry":
        return GEOJSON;
      // An oid is not one of the numbers JSON has a number for: Postgres writes its text.
      case "oid":
        return { type: "string" };
      // pgvector has no cast to JSON, so a vector inside a document is its text.
      case "vector":
      case "halfvec":
        return { type: "string" };
    }
  } else if (input) {
    switch (name) {
      case "int8":
        return { type: ["integer", "string"], format: "int64" };
      case "numeric":
        return { type: "string", format: "decimal" };
      case "timestamp":
        return { type: "string", format: "date-time" };
    }
  }
  const kind = scalarKind(name, dialect);
  if (kind.includes("|")) return { anyOf: kind.split("|").map((k) => kindSchema(k, name, dialect)) };
  const schema = kindSchema(kind, name, dialect);
  if (kind !== "text") return schema;
  switch (name) {
    case "text":
    case "varchar":
    case "bpchar":
    case "name":
    case "char":
    case "citext":
      return { type: "string" };
    case "uuid":
      return { type: "string", format: "uuid" };
    case "time":
      return { type: "string", format: "time" };
    case "unknown":
      return {};
    default:
      return { type: "string", description: `${dialect === "mysql" ? "MySQL" : "pg"} type ${name}` };
  }
}
function kindSchema(kind, name, dialect) {
  switch (kind) {
    case "bool":
      return { type: "boolean" };
    // A SQLite INTEGER is 64 bits wide, and so is an oid's range past int4's.
    case "int":
      return name === "oid" || dialect === "sqlite" ? { type: "integer", format: "int64" } : { type: "integer", format: "int32" };
    case "float":
      return name === "float4" ? { type: "number", format: "float" } : { type: "number", format: "double" };
    // A BigInt, as the JSON integer it is.
    case "int8":
      return { type: "integer", format: "int64" };
    case "decimal":
      return { type: "string", format: "decimal" };
    case "timestamptz":
      return { type: "string", format: "date-time" };
    // RFC 3339's duration, which JSON Schema's `duration` format names, has no sign and no fraction.
    case "interval":
      return { type: "string", description: "an ISO 8601 duration with its sign in front (P1Y2M3DT4H5M6.789S, -P1D); one whose parts differ in sign signs each part (P1M-1D)" };
    case "date":
      return { type: "string", format: "date" };
    // A date and a time with no zone, which RFC 3339's date-time does not admit.
    case "timestamp":
      return { type: "string", description: "a date and time without a time zone, as the database wrote it (2026-10-20T10:00:00.123456)" };
    case "bytes":
      return { type: "string", format: "byte", contentEncoding: "base64" };
    case "vector":
      return { type: "array", items: { type: "number", format: "float" } };
    case "hstore":
      return { type: "object", additionalProperties: { type: ["string", "null"] } };
    case "text":
      return { type: "string" };
    case "json":
      return {};
    case "unknown":
      return {};
  }
}
function object(fields, field, optional = () => false, closed = false) {
  const properties = {};
  const required = [];
  fields.forEach((f, i) => {
    properties[f.name] = field(i);
    const at = required.indexOf(f.name);
    if (at >= 0) required.splice(at, 1);
    if (!optional(i)) required.push(f.name);
  });
  return { type: "object", properties, required, ...closed ? { additionalProperties: false } : {} };
}
function typeSchema(t, dialect, input = false, inJson = false, inRow = false) {
  switch (t.kind) {
    case "scalar":
      return scalar(t.name, dialect, inJson, input);
    case "enum":
      return { type: "string", enum: t.labels };
    case "array": {
      const items = typeSchema(t.of, dialect, input, inJson, inRow);
      return { type: "array", items: (input ? inRow || t.nullable_items : t.nullable_items !== false) ? nullable(items) : items };
    }
    case "composite":
      return inJson ? object(t.fields, (i) => (t.fields[i].nullable ? nullable : (s) => s)(typeSchema(t.fields[i].type, dialect, input, true))) : { type: "string", description: `the row value of ${t.name} as Postgres prints it` };
    case "object":
      return object(t.fields, (i) => (t.fields[i].nullable ? nullable : (s) => s)(typeSchema(t.fields[i].type, dialect, input, true)));
    case "list": {
      const items = typeSchema(t.of, dialect, input, true);
      return { type: "array", items: t.nullable_items ? nullable(items) : items };
    }
    case "json":
      return t.schema ?? {};
    // What the caller passes: each key as a parameter of its type takes it.
    case "rows": {
      const row = object(t.fields, (i) => (t.fields[i].nullable ? nullable : (s) => s)(t.fields[i].schema ?? typeSchema(t.fields[i].type, dialect, true, false, true)), (i) => t.fields[i].optional, true);
      return t.one ? row : { type: "array", items: row };
    }
    case "unknown":
      return {};
  }
}
function querySchemas(analysis, dialect) {
  const input = object(analysis.params, (i) => {
    const p = analysis.params[i];
    const s = p.schema ?? typeSchema(p.type, dialect, true);
    return p.nullable ? nullable(s) : s;
  }, (i) => {
    const p = analysis.params[i];
    const s = p.schema;
    return p.nullable || s !== null && typeof s === "object" && s !== void 0 && "default" in s;
  }, true);
  const row = object(analysis.columns, (i) => {
    const c = analysis.columns[i];
    const s = typeSchema(c.type, dialect);
    return c.nullable ? nullable(s) : s;
  });
  const output = analysis.cardinality === "many" ? { type: "array", items: row } : analysis.cardinality === "one" ? row : analysis.cardinality === "maybeOne" ? { anyOf: [row, { type: "null" }] } : { type: "null" };
  return { input: { $schema: "https://json-schema.org/draft/2020-12/schema", ...input }, output: { $schema: "https://json-schema.org/draft/2020-12/schema", ...output } };
}

// src/loader.ts
async function sqlModule(path, sql) {
  const session = await Session.for(dirname6(path));
  let outcome = await session.analyze(sql);
  if (outcome.ok && outcome.analysis.diagnostics.some((d) => d.code === 6) && await session.recheck()) outcome = await session.analyze(sql);
  if (!outcome.ok) throw new Error(`${path}: ${outcome.message}`);
  const { analysis } = outcome;
  const unread = analysis.diagnostics.find((d) => d.code === 1 || d.code === 2 || d.code === 3);
  if (unread) throw new Error(`${path}: ${unread.message}`);
  let params;
  if (session.project.dialect === "mysql") {
    params = analysis.params.map((p) => p.name);
  } else {
    try {
      params = session.lex(sql).params;
    } catch (e) {
      throw new Error(`${path}: ${e.message}`);
    }
  }
  const descriptor = analysis.diagnostics.find((d) => d.code === 20 || d.code === 21);
  if (descriptor) throw new Error(`${path}: ${descriptor.message}`);
  const refused = analysis.diagnostics.find((d) => d.code === 6);
  if (refused) throw new Error(`${path}:${place2(sql, refused.start)}: ${refused.message}`);
  const inputs = Object.fromEntries(analysis.params.map((p) => [p.name, { type: p.type, ...p.schema === void 0 ? {} : { schema: p.schema }, ...p.cast === void 0 ? {} : { cast: p.cast }, nullable: p.nullable }]));
  const columns = analysis.columns.map((c) => {
    const kind = columnKind(c.type, session.project.dialect);
    const delimiter = arrayDelimiter(c.type);
    return delimiter === void 0 ? [c.name, kind] : [c.name, kind, delimiter];
  });
  const source = sourceName(path);
  const text = session.project.sqlcommenter ? withSqlcommenter(analysis.rewritten.sql, source) : analysis.rewritten.sql;
  const structured = (analysis.structured ?? []).map((s) => ({ name: s.name, lists: s.lists.map((l) => ({ start: utf16(text, l.start), end: utf16(text, l.end), entries: l.entries })) }));
  const checked = analysis.params.some((p) => p.schema !== void 0 || p.cast !== void 0 || p.type.kind === "rows" || p.type.kind === "json" && p.type.schema !== void 0 && !p.nullable);
  const code = [
    `import { defineQuery${checked ? ", checks" : ""} } from "reylo";`,
    // `sql` is the statement as Reylo sends it to the database, `raw` the file as written; the
    // definition's own `sql` is the statement as written and its `text` the compiled one.
    `export const sql = ${JSON.stringify(text)};`,
    `export const raw = ${JSON.stringify(sql)};`,
    `export const params = ${JSON.stringify(params)};`,
    `export default defineQuery({ dialect: ${JSON.stringify(session.project.dialect)}, sql: raw, params, cardinality: ${JSON.stringify(analysis.cardinality)}, text: sql, order: ${JSON.stringify(analysis.rewritten.order)}, inputs: ${JSON.stringify(inputs)}, columns: ${JSON.stringify(columns)}${structured.length ? `, structured: ${JSON.stringify(structured)}` : ""}${analysis.fresh ? `, fresh: ${JSON.stringify(analysis.fresh)}` : ""}, source: ${JSON.stringify(source)}, jsonSchema: ${JSON.stringify(querySchemas(analysis, session.project.dialect))}${checked ? ", checks" : ""} });`,
    ``
  ].join("\n");
  return { code, entry: outcome.entry, watched: session.project.watched.filter((f) => existsSync6(f)) };
}
function place2(text, bytes) {
  const before = text.slice(0, utf16(text, bytes));
  return `${before.split("\n").length}:${before.length - before.lastIndexOf("\n")}`;
}
function utf16(text, bytes) {
  return Buffer.from(text, "utf8").subarray(0, bytes).toString("utf8").length;
}

// src/mapper-server.ts
import { createHash as createHash2 } from "node:crypto";
import { dirname as dirname7, relative as relative3 } from "node:path";
var projects = /* @__PURE__ */ new Map();
function diag(size, messageText, start, length, code = 1) {
  return { messageText, ...withinFile(start, length, size), code };
}
function mapToStatement(text, sql) {
  const bytes = Buffer.from(sql, "utf8");
  let start = 0;
  let end = bytes.length;
  while (start < end && /\s/.test(String.fromCharCode(bytes[start]))) start++;
  while (end > start && /\s/.test(String.fromCharCode(bytes[end - 1]))) end--;
  const ATOM = 1;
  const DEFINITION = 8, TYPE_DEFINITION = 16, IMPLEMENTATION = 32;
  return [[0, Buffer.byteLength(text), start, end - start, ATOM, DEFINITION | TYPE_DEFINITION | IMPLEMENTATION]];
}
function mapperHandlers() {
  return {
    initialize(params) {
      const { protocolVersion } = params ?? {};
      return { protocolVersion: protocolVersion ?? 1, positionEncoding: "utf-8", diagnosticSource: "reylo" };
    },
    async openProject(params) {
      const p = params;
      const projectDir = dirname7(p.configFileName);
      const resolved = resolveProject(await anyEngine(projectDir), projectDir);
      const projectFile = resolved.file ? relative3(projectDir, resolved.file) || resolved.file : PROJECT_FILE;
      const optionDiagnostics = Object.keys(p.options ?? {}).map((key) => ({ path: [key], messageText: `reylo reads its settings from ${projectFile}, not from the content mapper's options; move "${key}" there.`, code: 104 }));
      projects.set(p.projectHandle, { strictParams: resolved.strictParams, sqlcommenter: resolved.sqlcommenter, projectFile, session: Session.open(projectDir) });
      const configIdentity = createHash2("sha1").update(JSON.stringify([resolved.file ?? null, resolved.dialect, resolved.strictParams, resolved.sqlcommenter, resolved.url ?? null, resolved.error ?? null, p.options ?? null])).digest("hex");
      return { configIdentity, watchedFiles: resolved.watched, optionDiagnostics };
    },
    async transform(params) {
      const p = params;
      const sql = p.content;
      const size = Buffer.byteLength(sql);
      const diagnostics = [];
      if (PROJECT_FILES.some((name) => p.fileName.endsWith(name))) return { extension: ".ts", diagnostics, text: "export {};\n", mappings: [] };
      const project = projects.get(p.projectHandle);
      if (!project) {
        diagnostics.push(diag(size, `The content mapper has no project for this file; restart the TypeScript server.`, 0, 1, 9));
        const leading2 = leadingComment(sql);
        const doc = docComment(leading2.prose, statementAfter(sql, leading2));
        const text = `import type { Query } from "reylo";
export type Params = unknown;
export type Row = unknown;
export type QueryError = import("reylo").QueryError;
${doc}declare const query: Query<unknown, unknown, "many", "postgres">;
export default query;
`;
        return { extension: ".ts", diagnostics, text, mappings: mapToStatement(text, sql) };
      }
      const session = await project.session;
      const outcome = await session.analyze(sql);
      const { dialect } = session.project;
      let lexed;
      try {
        lexed = session.lex(sql);
      } catch {
      }
      const leading = leadingComment(sql, dialect);
      const emit = (compiled2, paramsType, rowType, cardinality, names, shown2 = compiled2, queryError = queryErrorType(dialect, void 0)) => {
        const written = statementAfter(sql, leading);
        const sent = shown2 === void 0 ? void 0 : statementAfter(shown2, leadingComment(shown2, dialect));
        const sqlDoc = (indent = "") => docComment(leading.prose, sent, sqlNote(project.sqlcommenter), indent);
        const rawDoc = (indent = "") => docComment(leading.prose, written, RAW_NOTE, indent);
        const text = [
          `import type { Query } from "reylo";`,
          `export type Params = ${paramsType};`,
          `export type Row = ${rowType};`,
          `export type QueryError = ${queryError};`,
          `${sqlDoc()}export declare const sql: ${compiled2 === void 0 ? "string" : JSON.stringify(compiled2)};`,
          `${rawDoc()}export declare const raw: ${JSON.stringify(sql)};`,
          `export declare const params: readonly [${names.map((n) => JSON.stringify(n)).join(", ")}];`,
          // The literal types go in the Query type directly rather than through the aliases, so a
          // hover shows the row's shape (`{ id: number; ... } | null`) and not `Row | null`. The two
          // texts go in by `typeof`, so a hover over the query names them and one over its `sql`
          // shows the statement, with the doc comment of the property here (Query's own `sql` and
          // `raw` carry none, since TypeScript would show it first and run the two together).
          `${docComment(leading.prose, written)}declare const query: Query<${paramsType}, ${rowType}, ${JSON.stringify(cardinality)}, ${JSON.stringify(dialect)}, QueryError> & {`,
          `${sqlDoc("  ")}  readonly sql: typeof sql;`,
          `${rawDoc("  ")}  readonly raw: typeof raw;`,
          // Every build step writes the file's path into the module, so an import's source is never
          // missing. Its text is not given: the build reads the root from the file's own project,
          // which may not be the project the type check opened.
          `  readonly source: string;`,
          `};`,
          `export default query;`,
          ``
        ].join("\n");
        return { extension: ".ts", diagnostics, text, mappings: mapToStatement(text, sql) };
      };
      if (!outcome.ok) {
        diagnostics.push(diag(size, outcome.message, 0, 1, outcome.code));
        return emit(void 0, "unknown", "unknown", "many", lexed?.params ?? []);
      }
      const { analysis } = outcome;
      const types = moduleTypes(sql, analysis, dialect, lexed, project.strictParams, project.projectFile);
      diagnostics.push(...types.diagnostics.map((d) => diag(size, d.message, d.start, d.length, d.code)));
      const compiled = project.sqlcommenter ? withSqlcommenter(analysis.rewritten.sql, sourceName(p.fileName)) : analysis.rewritten.sql;
      return emit(compiled, types.params, types.row, types.cardinality, types.names, analysis.rewritten.sql, types.queryError);
    },
    async closeProject(params) {
      const handle2 = params.projectHandle;
      const project = projects.get(handle2);
      projects.delete(handle2);
      if (project) await (await project.session).close();
      return {};
    }
  };
}

// src/tooling.ts
var tooling_default = { sqlModule, releaseConnections, mapperHandlers, runCli };
export {
  tooling_default as default
};
