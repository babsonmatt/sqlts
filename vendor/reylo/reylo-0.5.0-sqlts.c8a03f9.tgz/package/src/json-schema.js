export function cloneJson(value) {
  return value === void 0 ? value : JSON.parse(JSON.stringify(value));
}
export function withDefaults(schema, value) {
  if (schema === null || typeof schema !== "object" || Array.isArray(schema))
    return value;
  const s = schema;
  let out = value;
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const o = { ...value };
    const properties = s.properties ?? {};
    for (const [key, sub] of Object.entries(properties)) {
      if (!Object.prototype.hasOwnProperty.call(o, key) && sub !== null && typeof sub === "object" && "default" in sub)
        o[key] = cloneJson(sub.default);
    }
    const patterns = Object.entries(s.patternProperties ?? {}).map(([p, sub]) => [regex(p), sub]);
    for (const key of Object.keys(o)) {
      let named = false;
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        named = true;
        o[key] = withDefaults(properties[key], o[key]);
      }
      for (const [re, sub] of patterns) {
        if (re.test(key)) {
          named = true;
          o[key] = withDefaults(sub, o[key]);
        }
      }
      if (!named && s.additionalProperties !== void 0)
        o[key] = withDefaults(s.additionalProperties, o[key]);
    }
    if (s.dependentSchemas && typeof s.dependentSchemas === "object") {
      for (const [key, sub] of Object.entries(s.dependentSchemas))
        if (Object.prototype.hasOwnProperty.call(o, key))
          Object.assign(o, withDefaults(sub, o));
    }
    out = o;
  } else if (Array.isArray(value)) {
    const a = [...value];
    const prefix = Array.isArray(s.prefixItems) ? s.prefixItems : [];
    prefix.forEach((sub, i) => {
      if (i >= a.length && sub !== null && typeof sub === "object" && "default" in sub && a.length === i)
        a.push(cloneJson(sub.default));
    });
    for (let i = 0; i < a.length; i++)
      a[i] = withDefaults(i < prefix.length ? prefix[i] : s.items ?? true, a[i]);
    out = a;
  }
  if (Array.isArray(s.allOf))
    for (const sub of s.allOf)
      out = withDefaults(sub, out);
  if (s.if !== void 0) {
    const branch = validate(s.if, out) === void 0 ? s.then : s.else;
    if (branch !== void 0)
      out = withDefaults(branch, out);
  }
  return out;
}
export function validate(schema, value) {
  const failures = [];
  check(schema, value, "", failures);
  return failures[0];
}
function check(schema, value, path, out) {
  const evaluated = /* @__PURE__ */ new Set();
  if (schema === true)
    return evaluated;
  if (schema === false)
    return fail(out, path, "no value is allowed here");
  if (schema === null || typeof schema !== "object" || Array.isArray(schema))
    return evaluated;
  const s = schema;
  if (s.type !== void 0) {
    const types = Array.isArray(s.type) ? s.type : [s.type];
    if (!types.some((t) => is(t, value)))
      return fail(out, path, `must be ${types.join(" or ")}, got ${kind(value)}`);
  }
  if (Array.isArray(s.enum) && !s.enum.some((e) => equal(e, value)))
    return fail(out, path, `must be one of ${s.enum.map((e) => JSON.stringify(e)).join(", ")}`);
  if ("const" in s && !equal(s.const, value))
    return fail(out, path, `must be ${JSON.stringify(s.const)}`);
  if (typeof value === "number") {
    if (typeof s.multipleOf === "number" && !multiple(value, s.multipleOf))
      return fail(out, path, `must be a multiple of ${s.multipleOf}`);
    if (typeof s.maximum === "number" && value > s.maximum)
      return fail(out, path, `must be at most ${s.maximum}`);
    if (typeof s.exclusiveMaximum === "number" && value >= s.exclusiveMaximum)
      return fail(out, path, `must be less than ${s.exclusiveMaximum}`);
    if (typeof s.minimum === "number" && value < s.minimum)
      return fail(out, path, `must be at least ${s.minimum}`);
    if (typeof s.exclusiveMinimum === "number" && value <= s.exclusiveMinimum)
      return fail(out, path, `must be more than ${s.exclusiveMinimum}`);
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (typeof s.maxLength === "number" && length > s.maxLength)
      return fail(out, path, `must be at most ${s.maxLength} characters long`);
    if (typeof s.minLength === "number" && length < s.minLength)
      return fail(out, path, `must be at least ${s.minLength} characters long`);
    if (typeof s.pattern === "string" && !regex(s.pattern).test(value))
      return fail(out, path, `must match the pattern ${s.pattern}`);
    if (typeof s.format === "string" && !format(s.format, value))
      return fail(out, path, `must be a ${s.format}`);
  }
  if (Array.isArray(value)) {
    if (typeof s.maxItems === "number" && value.length > s.maxItems)
      return fail(out, path, `must have at most ${s.maxItems} items`);
    if (typeof s.minItems === "number" && value.length < s.minItems)
      return fail(out, path, `must have at least ${s.minItems} items`);
    if (s.uniqueItems === true) {
      for (let i = 0; i < value.length; i++)
        for (let j = i + 1; j < value.length; j++)
          if (equal(value[i], value[j]))
            return fail(out, path, `must have no two equal items (${i} and ${j})`);
    }
    const prefix = Array.isArray(s.prefixItems) ? s.prefixItems : [];
    for (let i = 0; i < Math.min(prefix.length, value.length); i++)
      if (!check(prefix[i], value[i], `${path}/${i}`, out))
        return void 0;
    if (s.items !== void 0) {
      for (let i = prefix.length; i < value.length; i++)
        if (!check(s.items, value[i], `${path}/${i}`, out))
          return void 0;
    }
    if (s.contains !== void 0) {
      let matched = 0;
      for (const item of value)
        if (check(s.contains, item, path, []))
          matched++;
      const min = typeof s.minContains === "number" ? s.minContains : 1;
      if (matched < min)
        return fail(out, path, min === 1 ? "must contain an item that matches its `contains` schema" : `must contain at least ${min} items that match its \`contains\` schema`);
      if (typeof s.maxContains === "number" && matched > s.maxContains)
        return fail(out, path, `must contain at most ${s.maxContains} items that match its \`contains\` schema`);
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const o = value;
    const keys = Object.keys(o);
    if (typeof s.maxProperties === "number" && keys.length > s.maxProperties)
      return fail(out, path, `must have at most ${s.maxProperties} keys`);
    if (typeof s.minProperties === "number" && keys.length < s.minProperties)
      return fail(out, path, `must have at least ${s.minProperties} keys`);
    const has = (key) => Object.prototype.hasOwnProperty.call(o, key);
    if (Array.isArray(s.required)) {
      for (const key of s.required)
        if (!has(key))
          return fail(out, path, `must have the key "${key}"`);
    }
    if (s.dependentRequired && typeof s.dependentRequired === "object") {
      for (const [key, needs] of Object.entries(s.dependentRequired)) {
        if (has(key)) {
          for (const need of needs)
            if (!has(need))
              return fail(out, path, `must have the key "${need}" beside "${key}"`);
        }
      }
    }
    const properties = s.properties ?? {};
    const patterns = Object.entries(s.patternProperties ?? {}).map(([p, sub]) => [regex(p), sub]);
    for (const key of keys) {
      const at = `${path}/${pointer(key)}`;
      let named = false;
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        named = true;
        if (!check(properties[key], o[key], at, out))
          return void 0;
      }
      for (const [re, sub] of patterns) {
        if (re.test(key)) {
          named = true;
          if (!check(sub, o[key], at, out))
            return void 0;
        }
      }
      if (named)
        evaluated.add(key);
      else if (s.additionalProperties !== void 0) {
        if (!check(s.additionalProperties, o[key], at, out))
          return s.additionalProperties === false ? fail(out, at, `is a key the schema does not allow`, true) : void 0;
        evaluated.add(key);
      }
      if (s.propertyNames !== void 0 && !check(s.propertyNames, key, at, []))
        return fail(out, at, `is a key whose name the schema does not allow`);
    }
    if (s.dependentSchemas && typeof s.dependentSchemas === "object") {
      for (const [key, sub] of Object.entries(s.dependentSchemas)) {
        if (!has(key))
          continue;
        const e = check(sub, value, path, out);
        if (!e)
          return void 0;
        e.forEach((k) => evaluated.add(k));
      }
    }
  }
  if (Array.isArray(s.allOf)) {
    for (const sub of s.allOf) {
      const e = check(sub, value, path, out);
      if (!e)
        return void 0;
      e.forEach((k) => evaluated.add(k));
    }
  }
  if (Array.isArray(s.anyOf)) {
    let any = false;
    for (const sub of s.anyOf) {
      const e = check(sub, value, path, []);
      if (e) {
        any = true;
        e.forEach((k) => evaluated.add(k));
      }
    }
    if (!any)
      return fail(out, path, "must match one of its `anyOf` schemas");
  }
  if (Array.isArray(s.oneOf)) {
    let matched = 0;
    for (const sub of s.oneOf) {
      const e = check(sub, value, path, []);
      if (e) {
        matched++;
        e.forEach((k) => evaluated.add(k));
      }
    }
    if (matched !== 1)
      return fail(out, path, matched === 0 ? "must match one of its `oneOf` schemas" : "must match only one of its `oneOf` schemas, and matches more");
  }
  if (s.not !== void 0 && check(s.not, value, path, []))
    return fail(out, path, "must not match its `not` schema");
  if (s.if !== void 0) {
    const e = check(s.if, value, path, []);
    const branch = e ? s.then : s.else;
    if (e)
      e.forEach((k) => evaluated.add(k));
    if (branch !== void 0) {
      const b = check(branch, value, path, out);
      if (!b)
        return void 0;
      b.forEach((k) => evaluated.add(k));
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    if (s.unevaluatedProperties === false) {
      for (const key of Object.keys(value))
        if (!evaluated.has(key))
          return fail(out, `${path}/${pointer(key)}`, "is a key the schema does not allow");
    }
    if (s.unevaluatedProperties === true)
      for (const key of Object.keys(value))
        evaluated.add(key);
  }
  return evaluated;
}
function fail(out, path, message, replace = false) {
  if (replace)
    out.length = 0;
  out.push({ path, message });
  return void 0;
}
function is(type, v) {
  switch (type) {
    case "null":
      return v === null;
    case "boolean":
      return typeof v === "boolean";
    case "number":
      return typeof v === "number" && Number.isFinite(v);
    case "integer":
      return typeof v === "number" && Number.isInteger(v);
    case "string":
      return typeof v === "string";
    case "array":
      return Array.isArray(v);
    case "object":
      return v !== null && typeof v === "object" && !Array.isArray(v);
    default:
      return false;
  }
}
function kind(v) {
  if (v === null)
    return "null";
  if (Array.isArray(v))
    return "an array";
  if (typeof v === "number")
    return Number.isInteger(v) ? "an integer" : "a number";
  if (typeof v === "object")
    return "an object";
  return `a ${typeof v}`;
}
function equal(a, b) {
  if (a === b)
    return true;
  if (typeof a !== typeof b || a === null || b === null || typeof a !== "object")
    return false;
  if (Array.isArray(a) !== Array.isArray(b))
    return false;
  if (Array.isArray(a))
    return a.length === b.length && a.every((x, i) => equal(x, b[i]));
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  return ka.length === kb.length && ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && equal(a[k], b[k]));
}
function multiple(value, of) {
  const q = value / of;
  if (Number.isFinite(q))
    return Math.abs(q - Math.round(q)) < 1e-9;
  return value % of === 0;
}
const regexes = /* @__PURE__ */ new Map();
function regex(pattern) {
  let re = regexes.get(pattern);
  if (!re)
    regexes.set(pattern, re = new RegExp(pattern, "u"));
  return re;
}
function pointer(key) {
  return key.replace(/~/g, "~0").replace(/\//g, "~1");
}
const DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const TIME = /^(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:z|([+-])(\d{2}):(\d{2}))$/i;
function date(v) {
  const m = DATE.exec(v);
  if (!m)
    return false;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const days = [31, y % 4 === 0 && (y % 100 !== 0 || y % 400 === 0) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return mo >= 1 && mo <= 12 && d >= 1 && d <= days[mo - 1];
}
function time(v) {
  const m = TIME.exec(v);
  if (!m)
    return false;
  const [h, mi, s] = [Number(m[1]), Number(m[2]), Number(m[3])];
  if (h > 23 || mi > 59 || s > 60)
    return false;
  if (m[4] && (Number(m[5]) > 23 || Number(m[6]) > 59))
    return false;
  if (s === 60) {
    const offset = m[4] ? (m[4] === "+" ? 1 : -1) * (Number(m[5]) * 60 + Number(m[6])) : 0;
    const utc = ((h * 60 + mi - offset) % 1440 + 1440) % 1440;
    return utc === 23 * 60 + 59;
  }
  return true;
}
function format(name, v) {
  switch (name) {
    case "date":
      return date(v);
    case "time":
      return time(v);
    case "date-time": {
      const t = v.search(/[tT ]/);
      return t === 10 && date(v.slice(0, 10)) && time(v.slice(11));
    }
    case "uuid":
      return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
    case "email":
      return email(v);
    case "ipv4":
      return /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/.test(v);
    case "ipv6":
      return ipv6(v);
    case "uri":
      return uri(v);
    case "hostname":
      return hostname(v);
    case "regex":
      try {
        new RegExp(v, "u");
        return true;
      } catch {
        return false;
      }
    default:
      return true;
  }
}
const ATOM = "[A-Za-z0-9!#$%&'*+\\-/=?^_`{|}~]+";
const DOT_STRING = new RegExp(`^${ATOM}(?:\\.${ATOM})*$`);
const QUOTED = /^"(?:[\x20\x21\x23-\x5b\x5d-\x7e]|\\[\x20-\x7e])*"$/;
const LABEL = /^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/;
function email(v) {
  const at = v.lastIndexOf("@");
  if (at < 1)
    return false;
  const local = v.slice(0, at);
  const domain = v.slice(at + 1);
  if (!(DOT_STRING.test(local) || QUOTED.test(local)))
    return false;
  if (domain.startsWith("[") && domain.endsWith("]")) {
    const literal = domain.slice(1, -1);
    return /^ipv6:/i.test(literal) ? ipv6(literal.slice(5)) : format("ipv4", literal);
  }
  return domain.length <= 255 && domain.split(".").every((label) => label.length <= 63 && LABEL.test(label));
}
const UNRESERVED = "A-Za-z0-9\\-._~";
const SUB_DELIMS = "!$&'()*+,;=";
const PCT = "%[0-9A-Fa-f]{2}";
const PCHAR = `(?:[${UNRESERVED}${SUB_DELIMS}:@]|${PCT})`;
const URI = new RegExp(`^([A-Za-z][A-Za-z0-9+.-]*):(?://([^/?#]*))?((?:/|${PCHAR})*)(?:\\?((?:${PCHAR}|[/?])*))?(?:#((?:${PCHAR}|[/?])*))?$`);
const USERINFO = new RegExp(`^(?:[${UNRESERVED}${SUB_DELIMS}:]|${PCT})*$`);
const REG_NAME = new RegExp(`^(?:[${UNRESERVED}${SUB_DELIMS}]|${PCT})*$`);
function uri(v) {
  const m = URI.exec(v);
  if (!m)
    return false;
  const authority = m[2];
  if (authority === void 0)
    return !(m[3] ?? "").startsWith("//");
  const at = authority.lastIndexOf("@");
  if (at >= 0 && !USERINFO.test(authority.slice(0, at)))
    return false;
  const hostport = authority.slice(at + 1);
  if (hostport.startsWith("[")) {
    const close = hostport.indexOf("]");
    if (close < 0)
      return false;
    const literal = hostport.slice(1, close);
    const ok = /^v[0-9a-f]+\.[A-Za-z0-9\-._~!$&'()*+,;=:]+$/i.test(literal) || ipv6(literal);
    return ok && /^(?::\d*)?$/.test(hostport.slice(close + 1));
  }
  const colon = hostport.lastIndexOf(":");
  const host = colon >= 0 ? hostport.slice(0, colon) : hostport;
  if (colon >= 0 && !/^\d*$/.test(hostport.slice(colon + 1)))
    return false;
  return REG_NAME.test(host);
}
function hostname(v) {
  if (v.length === 0 || v.length > 253)
    return false;
  return v.split(".").every((label) => {
    if (label.length === 0 || label.length > 63 || !/^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/.test(label))
      return false;
    if (label.slice(2, 4) !== "--")
      return true;
    if (label.slice(0, 2).toLowerCase() !== "xn")
      return false;
    const u = punycode(label.slice(4).toLowerCase());
    return u !== void 0 && uLabel(u);
  });
}
const VIRAMA = /* @__PURE__ */ new Set([2381, 2509, 2637, 2765, 2893, 3021, 3149, 3277, 3387, 3388, 3405, 3530, 3642, 3770, 3972, 4153, 4154, 5908, 5909, 5940, 6098, 6752, 6980, 7082, 7083, 7154, 7155, 11647, 43014, 43052, 43204, 43347, 43456, 43766, 44013, 68159, 69702, 69744, 69759, 69817, 69939, 69940, 70080, 70197, 70378, 70477, 70722, 70850, 71103, 71231, 71350, 71467, 71737, 71997, 71998, 72160, 72244, 72263, 72345, 72767, 73028, 73029, 73111, 73537, 73538]);
const DISALLOWED = /* @__PURE__ */ new Set([1600, 2042, 12334, 12335, 12337, 12338, 12339, 12340, 12341, 12347]);
const JOINING = /[\p{Script=Arabic}\p{Script=Syriac}\p{Script=Nko}\p{Script=Mongolian}\p{Script=Mandaic}\p{Script=Manichaean}\p{Script=Adlam}\p{Script=Hanifi_Rohingya}\p{Script=Sogdian}]/u;
function uLabel(label) {
  const cps = [...label];
  if (cps.length === 0 || /^\p{M}/u.test(label) || label.slice(2, 4) === "--")
    return false;
  const at = (i) => cps[i] ?? "";
  for (let i = 0; i < cps.length; i++) {
    const c = cps[i].codePointAt(0);
    if (DISALLOWED.has(c))
      return false;
    switch (c) {
      case 183:
        if (at(i - 1) !== "l" || at(i + 1) !== "l")
          return false;
        break;
      case 885:
        if (!/\p{Script=Greek}/u.test(at(i + 1)))
          return false;
        break;
      case 1523:
      case 1524:
        if (!/\p{Script=Hebrew}/u.test(at(i - 1)))
          return false;
        break;
      case 12539:
        if (!cps.some((x) => x !== "\u30FB" && /[\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Han}]/u.test(x)))
          return false;
        break;
      case 8205:
        if (!VIRAMA.has(at(i - 1).codePointAt(0) ?? -1))
          return false;
        break;
      case 8204: {
        if (VIRAMA.has(at(i - 1).codePointAt(0) ?? -1))
          break;
        let before = i - 1;
        while (before >= 0 && /\p{Mn}/u.test(at(before)))
          before--;
        let after = i + 1;
        while (after < cps.length && /\p{Mn}/u.test(at(after)))
          after++;
        if (!(JOINING.test(at(before)) && JOINING.test(at(after))))
          return false;
        break;
      }
    }
  }
  const arabic = cps.some((x) => /[٠-٩]/.test(x));
  const extended = cps.some((x) => /[۰-۹]/.test(x));
  return !(arabic && extended);
}
function punycode(input) {
  const base = 36, tMin = 1, tMax = 26, skew = 38, damp = 700;
  const delimiter = input.lastIndexOf("-");
  const output = delimiter > 0 ? [...input.slice(0, delimiter)].map((c) => c.codePointAt(0)) : [];
  if (output.some((c) => c >= 128))
    return void 0;
  let n = 128, i = 0, bias = 72;
  const adapt = (delta, points, first) => {
    delta = first ? Math.floor(delta / damp) : delta >> 1;
    delta += Math.floor(delta / points);
    let k = 0;
    while (delta > (base - tMin) * tMax >> 1) {
      delta = Math.floor(delta / (base - tMin));
      k += base;
    }
    return k + Math.floor((base - tMin + 1) * delta / (delta + skew));
  };
  const digit = (c) => /[a-z]/.test(c) ? c.charCodeAt(0) - 97 : /[0-9]/.test(c) ? c.charCodeAt(0) - 22 : -1;
  let pos = delimiter > 0 ? delimiter + 1 : 0;
  if (pos >= input.length && delimiter <= 0)
    return void 0;
  while (pos < input.length) {
    const old = i;
    let w = 1;
    for (let k = base; ; k += base) {
      if (pos >= input.length)
        return void 0;
      const d = digit(input[pos++]);
      if (d < 0)
        return void 0;
      i += d * w;
      const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
      if (d < t)
        break;
      w *= base - t;
      if (!Number.isSafeInteger(i) || !Number.isSafeInteger(w))
        return void 0;
    }
    bias = adapt(i - old, output.length + 1, old === 0);
    n += Math.floor(i / (output.length + 1));
    i %= output.length + 1;
    if (n > 1114111)
      return void 0;
    output.splice(i++, 0, n);
  }
  return String.fromCodePoint(...output);
}
function ipv6(v) {
  if (!/^[0-9a-f:.]+$/i.test(v) || v.includes(":::"))
    return false;
  const halves = v.split("::");
  if (halves.length > 2)
    return false;
  const groups = (h) => h === "" ? [] : h.split(":");
  const parts = halves.flatMap(groups);
  const last = parts[parts.length - 1] ?? "";
  const v4 = last.includes(".");
  if (v4 && !format("ipv4", last))
    return false;
  const words = parts.length + (v4 ? 1 : 0);
  if (parts.slice(0, v4 ? -1 : void 0).some((g) => !/^[0-9a-f]{1,4}$/i.test(g)))
    return false;
  return halves.length === 2 ? words < 8 : words === 8;
}
