import { compile, execute, executeSync } from "./execute.js";
import { DecodeError, ParameterError } from "./values.js";
import { readQueryError, readQueryErrorSync } from "./query-error.js";
import { listening } from "./trace.js";
export { checks } from "./checks.js";
export function defineQuery(def) {
  const cardinality = def.cardinality ?? "many";
  const missingSchema = () => {
    throw new Error(`No JSON Schema is available for this query: a module a build step writes carries it, and a query defined by hand has none.`);
  };
  const where = def.source ? `${def.source}: ` : "";
  const module = {
    dialect: def.dialect,
    sql: def.sql,
    params: def.params,
    text: def.text,
    order: def.order,
    inputs: def.inputs,
    columns: def.columns,
    structured: def.structured,
    fresh: def.fresh,
    source: def.source,
    checks: def.checks
  };
  let compiled;
  const query = {
    dialect: def.dialect,
    // A query defined by hand is compiled when its `sql` is first read, so a placeholder its
    // `params` misses fails there and in `run`, not where it is defined.
    get sql() {
      return compiled ??= compile(module).text;
    },
    raw: def.sql,
    params: def.params,
    source: def.source,
    cardinality,
    get inputSchema() {
      return def.jsonSchema?.input ?? missingSchema();
    },
    get outputSchema() {
      return def.jsonSchema?.output ?? missingSchema();
    },
    "~standard": {
      version: 1,
      vendor: "reylo",
      jsonSchema: {
        input: () => def.jsonSchema?.input ?? missingSchema(),
        output: () => def.jsonSchema?.output ?? missingSchema()
      }
    },
    "~reylo": void 0,
    run: ((client, params) => run(client, params ?? {})),
    runSync: ((client, params) => {
      const values = params ?? {};
      const runOnce2 = () => {
        try {
          return materialize(executeSync(client, module, values));
        } catch (error) {
          throw named(error);
        }
      };
      const tracing = listening();
      return tracing ? tracing.traceSync(runOnce2, trace(client, values, true)) : runOnce2();
    }),
    try: ((client, params) => run(client, params ?? {}).then((value) => ({ value }), async (error) => {
      const read = await readQueryError(def.dialect, error);
      if (read)
        return { error: read };
      throw error;
    })),
    trySync: ((client, params) => {
      try {
        return { value: query.runSync(client, ...[params]) };
      } catch (error) {
        const read = readQueryErrorSync(def.dialect, error);
        if (read)
          return { error: read };
        throw error;
      }
    }),
    with: ((client) => (params) => run(client, params ?? {}))
  };
  function run(client, params) {
    const tracing = listening();
    return tracing ? tracing.tracePromise(() => runOnce(client, params), trace(client, params, false)) : runOnce(client, params);
  }
  function trace(client, params, sync) {
    return { query, client, params, sync };
  }
  function runOnce(client, params) {
    try {
      const rows = execute(client, module, params);
      return Array.isArray(rows) ? Promise.resolve(materialize(rows)) : rows.then((rows2) => materialize(rows2), (error) => Promise.reject(named(error)));
    } catch (error) {
      return Promise.reject(named(error));
    }
  }
  function named(error) {
    if (where && (error instanceof ParameterError || error instanceof DecodeError) && !error.message.startsWith(where)) {
      const message = error.message;
      error.message = where + message;
      if (typeof error.stack === "string" && !error.stack.includes(error.message))
        error.stack = error.stack.replace(message, () => error.message);
    }
    return error;
  }
  function materialize(rows) {
    switch (cardinality) {
      case "none":
        return void 0;
      case "many":
        return rows;
      case "one":
        if (rows.length !== 1)
          throw new Error(`${where}Expected exactly one row, got ${rows.length}`);
        return rows[0];
      default:
        if (rows.length > 1)
          throw new Error(`${where}Expected at most one row, got ${rows.length}`);
        return rows[0] ?? null;
    }
  }
  return query;
}
