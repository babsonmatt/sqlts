export declare function sqlModuleSync(path: string): string;
