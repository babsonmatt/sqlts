import { createHash } from "node:crypto";
import { sqlModuleSync } from "./bridge.js";
const built = /* @__PURE__ */ new Map();
function getCacheKey(_source, path, options) {
  const code = sqlModuleSync(path);
  built.set(path, code);
  return createHash("sha256").update(code).update(String(options.supportsStaticESM)).update(options.configString).digest("hex");
}
function transform(_source, path, options) {
  const code = built.get(path) ?? sqlModuleSync(path);
  built.delete(path);
  return { code: options.supportsStaticESM ? code : commonJs(path, code) };
}
function commonJs(path, code) {
  const out = code.replace(/^import \{ (defineQuery(?:, checks)?) \} from "reylo";$/m, (_, names) => `const { ${names} } = require("reylo");`).replace(/^export const (\w+) = /gm, "const $1 = exports.$1 = ").replace(/^export default /m, "exports.default = ");
  if (/^(import|export) /m.test(out))
    throw new Error(`${path}: reylo's module has a shape reylo/jest cannot make CommonJS.`);
  return `Object.defineProperty(exports, "__esModule", { value: true });
${out}`;
}
export default { getCacheKey, process: transform };
