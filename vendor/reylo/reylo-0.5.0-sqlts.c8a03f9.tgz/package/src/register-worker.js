import { parentPort } from "node:worker_threads";
import { dirname } from "node:path";
import { tooling } from "./engine-package.js";
parentPort.on("message", async ({ path, source, port, done }) => {
  let reply;
  try {
    reply = { code: (await (await tooling(dirname(path))).sqlModule(path, source)).code };
  } catch (e) {
    reply = { error: e.message };
  }
  port.postMessage(reply);
  port.close();
  Atomics.store(done, 0, 1);
  Atomics.notify(done, 0);
});
