import { bigInteger, coerce, DecodeError, exactInteger, refuseTruth, truth } from "./values.js";
const statements = /* @__PURE__ */ new WeakMap();
const KEPT = 500;
function statementFor(db, text, typed) {
  const keep = typeof db.maxWriteReplicationIndex !== "function";
  let kept = statements.get(db);
  if (!kept && keep)
    statements.set(db, kept = /* @__PURE__ */ new Map());
  const key = `${typed ? "n" : "b"}${text}`;
  const found = kept?.get(key);
  if (found)
    return found;
  const st = db.prepare(text);
  let exact = false;
  if (typeof st.setReadBigInts === "function") {
    st.setReadBigInts(true);
    if (typeof st.setReturnArrays === "function")
      st.setReturnArrays(false);
    exact = true;
  } else if (typeof st.safeIntegers === "function") {
    st.safeIntegers(!typed);
    exact = !typed;
  }
  const entry = { st, exact, kept: keep };
  if (!kept)
    return entry;
  if (kept.size >= KEPT)
    kept.delete(kept.keys().next().value);
  kept.set(key, entry);
  return entry;
}
export function runSyncSqlite(db, text, values, columns) {
  const entry = statementFor(db, text, everyColumnTyped(columns));
  if (entry.kept)
    return runStatement(entry, values, columns);
  try {
    return runStatement(entry, values, columns);
  } finally {
    entry.st.close?.();
  }
}
function runStatement({ st, exact }, values, columns) {
  if (reader(st) === false) {
    st.run(...values);
    return [];
  }
  const all = st.all(...values);
  if (!Array.isArray(all))
    return Promise.resolve(all).then((rows2) => normalize(rows2, columns));
  let rows = all;
  if (rows.length && Array.isArray(rows[0]) && typeof st.columns === "function") {
    const names = st.columns().map((c) => c.name);
    rows = rows.map((r) => Object.fromEntries(names.map((n, i) => [n, r[i]])));
  }
  return normalize(rows, columns, { exact });
}
function reader(st) {
  try {
    return st.reader;
  } catch {
    return void 0;
  }
}
function everyColumnTyped(columns) {
  return columns !== void 0 && columns.length > 0 && !columns.some(([, kind]) => kind === "unknown" || kind.split("|").includes("int8"));
}
export async function runTurso(db, text, values, columns) {
  const typed = everyColumnTyped(columns);
  const st = await db.prepare(text);
  try {
    if (typeof st.safeIntegers === "function")
      st.safeIntegers(!typed);
    return normalize(await st.all(...values), columns, { exact: !typed });
  } finally {
    if (typeof st.close === "function")
      st.close();
  }
}
export function runDurableObject(sql, text, values, columns) {
  return normalize(sql.exec(text, ...values).toArray(), columns);
}
const DIGITS = /^[+-]?\d+$/;
function plan(name, kind, exact) {
  if (kind === "bool")
    return { name, big: (v) => truth(v, name), num: (v) => truth(v, name), str: (v) => truth(v, name), blob: () => refuseTruth(name, "a BLOB") };
  if (kind === "json")
    return { name, big: (v) => exactInteger(v, name), num: void 0, str: (v) => JSON.parse(v) };
  const kinds = kind.split("|");
  const refuse = (v) => refuseClass(name, kinds, v);
  const any = kinds.includes("unknown");
  const texts = any || kinds.includes("text");
  const numbers = any || kinds.some((k) => k === "int" || k === "float" || k === "int8");
  const blob = any || kinds.includes("bytes") ? void 0 : refuse;
  if (kind === "int8")
    return { name, big: (v) => v, num: exact ? refuse : (v) => Number.isInteger(v) ? bigInteger(v, name) : refuse(v), str: (v) => DIGITS.test(v) ? BigInt(v) : refuse(v), blob };
  if (kind === "text")
    return { name, big: String, num: void 0, str: void 0, blob };
  if (kind === "int")
    return { name, big: (v) => exactInteger(v, name), num: exact ? void 0 : (v) => exactInteger(v, name), str: (v) => DIGITS.test(v) ? exactInteger(BigInt(v), name) : refuse(v), blob };
  const digits = (v) => DIGITS.test(v) ? exactInteger(BigInt(v), name) : texts ? v : refuse(v);
  const str = numericOnly(kinds) || numbers && !texts ? digits : texts ? void 0 : refuse;
  if (!exact && kinds.includes("int"))
    return { name, big: (v) => exactInteger(v, name), num: (v) => Number.isInteger(v) ? exactInteger(v, name) : v, str, blob };
  if (!numbers && !texts)
    return { name, big: refuse, num: refuse, str, blob };
  return { name, big: (v) => exactInteger(v, name), num: void 0, str, blob };
}
const TYPE_NAMES = { int: "number", float: "number", int8: "bigint", text: "string", bytes: "Uint8Array" };
function refuseClass(column, kinds, v) {
  const type = [...new Set(kinds.map((k) => TYPE_NAMES[k] ?? k))].join(" | ");
  const held = typeof v === "string" ? `the text ${JSON.stringify(v.length > 40 ? `${v.slice(0, 40)}\u2026` : v)}` : typeof v === "number" || typeof v === "bigint" ? `the number ${v}` : `a BLOB of ${byteLength(v)} byte${byteLength(v) === 1 ? "" : "s"}`;
  throw new DecodeError(`Column "${column}" is typed ${type} and holds ${held}: outside a STRICT table SQLite stores a value of any type in any column, and Reylo refuses one its type does not allow rather than return it. Replace the value, or read what the column holds with cast(${column} as text).`);
}
function byteLength(v) {
  if (v instanceof ArrayBuffer || ArrayBuffer.isView(v))
    return v.byteLength;
  return Array.isArray(v) ? v.length : 0;
}
function numericOnly(kinds) {
  return kinds.every((k) => k === "int" || k === "float") || kinds.length === 3 && kinds.includes("int") && kinds.includes("float") && kinds.includes("text");
}
export function normalize(rows, columns, { exact = false, d1 = false } = {}) {
  if (!Array.isArray(rows) || !rows.length)
    return Array.isArray(rows) ? rows : [];
  const plans = (columns ? [...columns] : Object.keys(rows[0]).map((name) => [name, "unknown"])).map(([name, kind]) => plan(name, kind, exact));
  const n = plans.length;
  for (const row of rows) {
    if (Object.getPrototypeOf(row) === null)
      Object.setPrototypeOf(row, Object.prototype);
    for (let i = 0; i < n; i++) {
      const p = plans[i];
      const v = row[p.name];
      if (v === null || v === void 0)
        continue;
      switch (typeof v) {
        case "bigint":
          row[p.name] = p.big(v);
          break;
        case "number":
          if (p.num)
            row[p.name] = p.num(v);
          break;
        case "string":
          if (p.str)
            row[p.name] = p.str(v);
          break;
        case "object":
          if (p.blob)
            p.blob(v);
          if (!(v instanceof Uint8Array) && (v instanceof ArrayBuffer || d1 && Array.isArray(v)))
            row[p.name] = coerce("bytes", v, p.name);
          break;
      }
    }
  }
  return rows;
}
