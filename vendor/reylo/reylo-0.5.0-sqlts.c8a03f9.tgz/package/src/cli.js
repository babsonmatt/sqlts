#!/usr/bin/env node
import { tooling } from "./engine-package.js";
try {
  process.exitCode = await (await tooling()).runCli(process.argv.slice(2));
} catch (e) {
  console.error(`reylo: ${e.message}`);
  process.exitCode = 1;
}
