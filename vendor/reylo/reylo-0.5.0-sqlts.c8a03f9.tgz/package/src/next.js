import { spawn } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join, resolve } from "node:path";
export function withReylo(config = {}) {
  const { typescript, turbopack, webpack, compiler } = config;
  const check = !typescript?.ignoreBuildErrors;
  return {
    ...config,
    turbopack: {
      ...turbopack,
      // Each .sql file becomes a module that runs its statement, on the server only: a client
      // component that imports one fails the build. A rule of the project's own for *.sql wins.
      rules: { "*.sql": { condition: { not: "browser" }, loaders: ["reylo/turbopack"], as: "*.js" }, ...turbopack?.rules }
    },
    webpack(webpackConfig, context) {
      const out = webpack ? webpack(webpackConfig, context) : webpackConfig;
      if (context.isServer)
        out.module.rules.push({ test: /\.sql$/, use: "reylo/webpack" });
      return out;
    },
    ...check && {
      typescript: { ...typescript, ignoreBuildErrors: true },
      compiler: {
        ...compiler,
        async runAfterProductionCompile(metadata) {
          await compiler?.runAfterProductionCompile?.(metadata);
          await typeCheck(metadata.projectDir, resolve(metadata.projectDir, typescript?.tsconfigPath ?? "tsconfig.json"));
        }
      }
    }
  };
}
async function typeCheck(dir, tsconfig) {
  const require = createRequire(join(dir, "package.json"));
  let manifest;
  try {
    manifest = require.resolve("typescript/package.json");
  } catch {
    throw stackless("Reylo's type check needs TypeScript 7.1 or later, whose content mappers type .sql imports, and the project has no TypeScript.");
  }
  const { version } = JSON.parse(readFileSync(manifest, "utf8"));
  const [major = 0, minor = 0] = version.split(".").map(Number);
  if (major < 7 || major === 7 && minor < 1) {
    throw stackless(`Reylo's type check needs TypeScript 7.1 or later, whose content mappers type .sql imports; the project has TypeScript ${version}.`);
  }
  if (!existsSync(join(dir, "next-env.d.ts"))) {
    const next = require.resolve("next/package.json");
    const bin = JSON.parse(readFileSync(next, "utf8")).bin.next;
    const typegen = await run([join(dirname(next), bin), "typegen", dir], dir);
    if (typegen.code !== 0)
      throw stackless(`next typegen failed:
${typegen.output}`);
  }
  const tsc = join(dirname(manifest), "lib", "tsc.js");
  const args = ["--project", tsconfig, "--noEmit", "--declarationMap", "false", "--emitDeclarationOnly", "false", "--runExternalCode"];
  const { code, output } = await run([tsc, ...args], dir);
  if (output.trim())
    console.log(output.trimEnd());
  if (code !== 0)
    throw stackless("Failed to type check (tsc --runExternalCode).");
}
function run(args, cwd) {
  return new Promise((done, fail) => {
    const child = spawn(process.execPath, args, {
      cwd,
      stdio: ["ignore", "pipe", "pipe"],
      env: { ...process.env, ...process.stdout.isTTY && { FORCE_COLOR: "1" } }
    });
    let output = "";
    child.stdout.setEncoding("utf8").on("data", (chunk) => output += chunk);
    child.stderr.setEncoding("utf8").on("data", (chunk) => output += chunk);
    child.on("error", fail);
    child.on("close", (code) => done({ code: code ?? 1, output }));
  });
}
function stackless(message) {
  const error = new Error(message);
  error.stack = message;
  return error;
}
