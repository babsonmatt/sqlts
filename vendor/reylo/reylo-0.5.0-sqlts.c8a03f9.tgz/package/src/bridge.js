import { readFileSync } from "node:fs";
import { MessageChannel, receiveMessageOnPort, Worker } from "node:worker_threads";
let worker;
export function sqlModuleSync(path) {
  const extension = import.meta.url.slice(import.meta.url.lastIndexOf("."));
  worker ??= new Worker(new URL(`./register-worker${extension}`, import.meta.url), { workerData: { reyloWorker: true } });
  worker.unref();
  const done = new Int32Array(new SharedArrayBuffer(4));
  const { port1, port2 } = new MessageChannel();
  worker.postMessage({ path, source: readFileSync(path, "utf8"), port: port2, done }, [port2]);
  const waited = Atomics.wait(done, 0, 0, 12e4);
  const reply = receiveMessageOnPort(port1)?.message;
  port1.close();
  if (!reply)
    throw new Error(`${path}: reylo's worker ${waited === "timed-out" ? "did not answer in 120 s" : "ended without an answer"}.`);
  if ("error" in reply)
    throw new Error(reply.error);
  return reply.code;
}
