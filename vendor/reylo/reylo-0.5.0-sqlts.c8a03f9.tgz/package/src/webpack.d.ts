type LoaderContext = {
    resourcePath: string;
    addDependency(file: string): void;
    async(): (error: Error | null, code?: string) => void;
};
export default function reyloSqlLoader(this: LoaderContext, source: string): void;
export {};
