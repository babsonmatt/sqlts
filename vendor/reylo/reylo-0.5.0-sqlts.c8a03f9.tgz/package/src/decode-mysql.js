import { bigInteger, coerce, truth, utf8 } from "./values.js";
const MYSQL2_OPTIONS = { supportBigNumbers: true, bigNumberStrings: true, dateStrings: true, rowsAsArray: false, nestTables: false };
function mysql2Cast(f, next) {
  switch (f.type) {
    case "NEWDECIMAL":
    case "DECIMAL":
      return f.string("ascii");
    case "JSON": {
      const bytes = f.buffer();
      return bytes === null ? null : JSON.parse(utf8(bytes));
    }
    case "GEOMETRY":
      return f.buffer();
    default:
      return next();
  }
}
const DATETIME = 12, TIMESTAMP = 7, TIME = 11;
function wallClock(s, decimals, type) {
  let text = s;
  if (decimals > 0) {
    const dot = text.indexOf(".");
    text = dot < 0 ? `${text}.${"0".repeat(decimals)}` : text.padEnd(dot + 1 + decimals, "0");
  }
  return type === TIME ? text : text.replace(" ", "T");
}
const configOf = (m) => m.pool?.config?.connectionConfig ?? m.connection?.config;
function needsCast(m, columns) {
  if (!columns || columns.some(([, kind]) => kind === "unknown" || kind.split("|").some((k) => k === "json" || k.startsWith("json"))))
    return true;
  const config = configOf(m);
  return config === void 0 || typeof config.typeCast === "function" || config.decimalNumbers === true || config.jsonStrings === true;
}
const LONGLONG = 8;
const toBool = truth;
const toBigInt = (v, name) => typeof v === "string" ? BigInt(v) : typeof v === "number" || typeof v === "bigint" ? bigInteger(v, name) : v;
const toFloats = (v, name) => coerce("float[]", v, name);
function byKind(kind) {
  if (kind === "bool")
    return toBool;
  if (kind === "int8")
    return toBigInt;
  if (kind === "float[]")
    return toFloats;
  return void 0;
}
function fixRows(rows, fixes) {
  if (!fixes.length)
    return;
  for (const row of rows) {
    for (const [name, fix] of fixes) {
      const v = row[name];
      if (v !== null && v !== void 0)
        row[name] = fix(v, name);
    }
  }
}
export async function mysql2(m, text, values, columns) {
  const [rows, fields] = await m.execute({ sql: text, ...MYSQL2_OPTIONS, typeCast: needsCast(m, columns) ? mysql2Cast : true }, values);
  if (!Array.isArray(rows))
    return [];
  const described = fields ?? [];
  const kinds = columns && columns.length === described.length ? columns : void 0;
  const fixes = [];
  described.forEach((f, i) => {
    const fix = byKind(kinds?.[i][1]) ?? (f.columnType === LONGLONG ? toBigInt : void 0);
    if (fix)
      fixes.push([f.name, fix]);
  });
  for (const f of described) {
    if (f.columnType === DATETIME || f.columnType === TIMESTAMP || f.columnType === TIME && f.decimals > 0) {
      const decimals = f.decimals > 6 ? 0 : f.decimals, type = f.columnType;
      fixes.push([f.name, (v) => typeof v === "string" ? wallClock(v, decimals, type) : v]);
    }
  }
  fixRows(rows, fixes);
  return rows;
}
const MARIADB_OPTIONS = {
  bigIntAsNumber: false,
  decimalAsNumber: false,
  supportBigNumbers: false,
  bigNumberStrings: true,
  supportBigInt: true,
  checkNumberRange: false,
  dateStrings: true,
  jsonStrings: false,
  autoJsonMap: true,
  bitOneIsBoolean: false,
  rowsAsArray: false,
  nestTables: false,
  metaAsArray: false,
  typeCast: void 0
};
const mariadbGeometry = (column, next) => column.type === "GEOMETRY" ? column.buffer() : next();
export async function mariadb(c, text, values, columns) {
  const options = { sql: text, ...MARIADB_OPTIONS, ...columns?.some(([, kind]) => kind === "unknown") ? { typeCast: mariadbGeometry } : {} };
  let callbackMeta;
  const result = await new Promise((resolve, reject) => {
    const returned = c.query(options, values, (error, rows, meta) => error ? reject(error) : (callbackMeta = meta, resolve(rows)));
    if (typeof returned?.then === "function")
      returned.then(resolve, reject);
  });
  if (!Array.isArray(result))
    return [];
  const work = columns ? columns.filter(([, kind]) => kind === "text" || kind.split("|").includes("timestamp")).map(([name, kind]) => ({ name, date: kind !== "text" })) : (result.meta ?? callbackMeta ?? []).map((m) => ({ name: typeof m.name === "function" ? m.name() : m.name, type: m.type, set: typeof m.isSet === "function" && m.isSet() || m.type === "SET" })).filter((m) => m.name !== void 0 && (m.set || m.type === "DATETIME" || m.type === "TIMESTAMP")).map((m) => ({ name: m.name, date: !m.set }));
  fixRows(result, columnFixes(columns));
  if (!work.length)
    return result;
  for (const row of result) {
    for (const { name, date } of work) {
      const v = row[name];
      if (v === null || v === void 0)
        continue;
      if (Array.isArray(v))
        row[name] = coerce("text", v, name);
      else if (date && typeof v === "string")
        row[name] = v.replace(" ", "T");
    }
  }
  return result;
}
function columnFixes(columns) {
  const fixes = [];
  for (const [name, kind] of columns ?? []) {
    const fix = byKind(kind);
    if (fix)
      fixes.push([name, fix]);
  }
  return fixes;
}
const bytesOf = (s) => {
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++)
    out[i] = s.charCodeAt(i);
  return out;
};
function planetscaleCast(field, value) {
  if (value === null || value === void 0)
    return value;
  switch (field.type) {
    case "INT64":
    case "UINT64":
      return BigInt(value);
    case "DATE":
    case "TIME":
    case "DECIMAL":
      return value;
    case "DATETIME":
    case "TIMESTAMP":
      return value.replace(" ", "T");
    case "JSON":
      return JSON.parse(utf8(bytesOf(value)));
    case "INT8":
    case "INT16":
    case "INT24":
    case "INT32":
    case "UINT8":
    case "UINT16":
    case "UINT24":
    case "UINT32":
    case "YEAR":
      return parseInt(value, 10);
    case "FLOAT32":
    case "FLOAT64":
      return parseFloat(value);
  }
  if (field.charset === 63)
    return bytesOf(value);
  return value ? utf8(bytesOf(value)) : "";
}
export async function planetscale(m, text, values, columns) {
  const options = { as: "object", cast: planetscaleCast };
  let result;
  try {
    result = await m.execute(text, values.length ? values : null, options);
  } catch (error) {
    if (!/^Query parameters are not supported/.test(error?.message))
      throw error;
    if (values.length)
      throw new TypeError(`@planetscale/database 2.0 binds no parameters, so reylo cannot pass this statement's values to it; use its 1.x line, or mysql2 on PlanetScale's MySQL endpoint.`, { cause: error });
    result = await m.execute(text, options);
  }
  if (!Array.isArray(result?.rows))
    throw new TypeError(`reylo ran this statement through execute(), as on PlanetScale's @planetscale/database, and the client answered with ${Array.isArray(result) ? "an array" : result === null || typeof result !== "object" ? String(result) : "an object"} rather than a result with rows. It takes execute(text, values) as on mysql2 and PlanetScale, or a Drizzle database over one of them.`);
  fixRows(result.rows, columnFixes(columns));
  return result.rows;
}
