const tracing = (() => {
  try {
    const host = globalThis.process;
    const dc = host?.getBuiltinModule?.("node:diagnostics_channel");
    return dc?.tracingChannel?.("reylo:query");
  } catch {
    return void 0;
  }
})();
export function listening() {
  const t = tracing;
  return t && (t.start.hasSubscribers || t.end.hasSubscribers || t.asyncStart.hasSubscribers || t.asyncEnd.hasSubscribers || t.error.hasSubscribers) ? t : void 0;
}
