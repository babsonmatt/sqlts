import { readFileSync } from "node:fs";
import { dirname } from "node:path";
import { releaseConnections, tooling } from "./engine-package.js";
export default function reylo() {
  return {
    name: "reylo",
    setup(build) {
      build.onLoad({ filter: /\.sql$/ }, async (args) => {
        const { code, entry, watched } = await (await tooling(dirname(args.path))).sqlModule(args.path, readFileSync(args.path, "utf8"));
        return { contents: code, loader: "js", watchFiles: [entry, ...watched] };
      });
      build.onEnd?.(releaseConnections);
    }
  };
}
