type Build = {
    onLoad(options: {
        filter: RegExp;
    }, callback: (args: {
        path: string;
    }) => Promise<{
        contents: string;
        loader: "js";
        watchFiles?: string[];
    }>): void;
    /** esbuild's and Bun.build's; Bun's runtime plugin has none. */
    onEnd?(callback: () => Promise<void>): void;
};
export default function reylo(): {
    name: string;
    setup(build: Build): void;
};
export {};
