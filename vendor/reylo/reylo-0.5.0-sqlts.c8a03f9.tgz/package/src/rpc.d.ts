type Handler = (params: unknown) => unknown | Promise<unknown>;
export declare function serve(handlers: Record<string, Handler>): void;
export {};
