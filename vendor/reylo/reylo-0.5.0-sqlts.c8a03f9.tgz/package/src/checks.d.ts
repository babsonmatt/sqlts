import { cloneJson, validate, withDefaults } from "./json-schema.ts";
import { checkCast, prepareRows, variant } from "./rows.ts";
export declare const checks: {
    cloneJson: typeof cloneJson;
    validate: typeof validate;
    withDefaults: typeof withDefaults;
    checkCast: typeof checkCast;
    prepareRows: typeof prepareRows;
    variant: typeof variant;
};
export type Checks = typeof checks;
