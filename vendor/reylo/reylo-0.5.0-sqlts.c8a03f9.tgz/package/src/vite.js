import { existsSync, readFileSync } from "node:fs";
import { dirname, isAbsolute, resolve } from "node:path";
import { releaseConnections, tooling } from "./engine-package.js";
export default function reylo() {
  return {
    name: "reylo",
    enforce: "pre",
    resolveId: {
      order: "pre",
      handler(source, importer) {
        if (!source.endsWith(".sql") || importer === void 0)
          return null;
        if (!source.startsWith("./") && !source.startsWith("../"))
          return null;
        const from = importer.replace(/[?#].*$/, "");
        if (!isAbsolute(from))
          return null;
        const path = resolve(dirname(from), source);
        return existsSync(path) ? path : null;
      }
    },
    async load(id) {
      if (!id.endsWith(".sql"))
        return null;
      const { code, entry, watched } = await (await tooling(dirname(id))).sqlModule(id, readFileSync(id, "utf8"));
      for (const file of [entry, ...watched])
        this.addWatchFile(file);
      return { code, map: null };
    },
    async buildEnd() {
      await releaseConnections();
    }
  };
}
