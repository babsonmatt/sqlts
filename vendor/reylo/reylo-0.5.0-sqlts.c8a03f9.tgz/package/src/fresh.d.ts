/**
 * What a module carries: the catalog query, which takes no parameter, and the facts as text, five
 * per column, or six on Postgres and SQLite, whose sixth is a default's text; `defaults` names the
 * `[table, column]` whose sixth is compared, each a default the statement copied.
 */
export type Fresh = {
    readonly query: string;
    readonly rows: readonly (readonly string[])[];
    readonly inserts: readonly string[];
    readonly defaults?: readonly (readonly string[])[];
};
/** How long a check holds, in milliseconds. */
export declare const FRESH_FOR = 60000;
/** Whether `query` is due for a check now. */
export declare function due(query: object, now?: number): boolean;
/** Records a check of `query` that passed, or that could not run. */
export declare function passed(query: object, now?: number): void;
/**
 * The differences between the facts the build saw and the rows the catalog query returns now, one
 * line each; none when the schema still holds what the query relied on, and `undefined` when the
 * rows are not the catalog query's: each is an object with its five or six columns, as many as
 * the module's facts have, or an array of as many values where a driver hands rows back as arrays.
 * A default the statement copied is compared by its text.
 *
 * A SQLite type is compared without its case, as SQLite reads a declared type: SQLite's
 * `pragma_table_xinfo` upper-cases the type names it knows (`integer` is `INTEGER`) and Turso's
 * engine gives them as declared, so a build on one and a run on the other saw the same schema. A
 * Postgres or MySQL type is compared exactly: a quoted Postgres type name keeps its case.
 */
export declare function differences(fresh: Fresh, rows: readonly unknown[], dialect?: "postgres" | "mysql" | "sqlite"): string[] | undefined;
/**
 * A SQLite default's text in one spelling, since engines that read the same schema write it
 * differently: `pragma_table_xinfo` gives the text as written on SQLite (`member`,
 * `lower(hex(randomblob(4)))`, `-7`, `current_timestamp`), and Turso's engine writes it again
 * (`'member'`, `(lower (hex (randomblob (4))))`, `- 7`, `CURRENT_TIMESTAMP`), which evaluates the
 * same (wiki/structured-params/default-extraction.md). Outside its strings the text loses its
 * spaces and its ASCII case and the parentheses around it all, and a lone identifier is the string
 * SQLite stores for it, as the build copies it (engine/core/src/structured.rs).
 */
export declare function sqliteDefault(text: string): string;
/** The error a call fails with when the schema changed under its query. */
export declare function staleError(source: string | undefined, lines: readonly string[]): Error;
