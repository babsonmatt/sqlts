import { dirname } from "node:path";
import { tooling } from "./engine-package.js";
export default function reyloSqlLoader(source) {
  const done = this.async();
  tooling(dirname(this.resourcePath)).then((t) => t.sqlModule(this.resourcePath, source)).then(({ code, entry, watched }) => {
    for (const file of [entry, ...watched])
      this.addDependency(file);
    done(null, code);
  }, (error) => done(error));
}
