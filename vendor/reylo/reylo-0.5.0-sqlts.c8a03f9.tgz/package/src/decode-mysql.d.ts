import { type Columns } from "./values.ts";
type AnyClient = Record<string, any>;
/** mysql2's execute(), resolving to [rows, fields]. */
export declare function mysql2(m: AnyClient, text: string, values: unknown[], columns: Columns | undefined): Promise<unknown[]>;
/** mariadb's query(), on its promise or its callback API, with Reylo's options. */
export declare function mariadb(c: AnyClient, text: string, values: unknown[], columns: Columns | undefined): Promise<unknown[]>;
/** PlanetScale's execute(): 1.x binds parameters; 2.0 takes none, and its options come second. */
export declare function planetscale(m: AnyClient, text: string, values: unknown[], columns: Columns | undefined): Promise<unknown[]>;
export {};
