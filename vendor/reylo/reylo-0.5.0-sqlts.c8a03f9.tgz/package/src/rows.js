import { validate, withDefaults } from "./json-schema.js";
import { describe, hstoreText, ParameterError, postgresInterval, postgresYear, zoned } from "./values.js";
export { describe, zoned } from "./values.js";
const TWO_63 = BigInt(2) ** BigInt(63);
const INTEGERS = {
  int2: [BigInt(-32768), BigInt(32767)],
  int4: [BigInt(-2147483648), BigInt(2147483647)],
  int8: [-TWO_63, TWO_63 - BigInt(1)],
  // SQLite's INTEGER is a 64-bit integer.
  integer: [-TWO_63, TWO_63 - BigInt(1)]
};
const WIDE = /* @__PURE__ */ new Set(["int8", "integer"]);
class Raw {
  text;
  constructor(text) {
    this.text = text;
  }
}
export function prepareRows(name, type, value, dialect, inserted) {
  const fail = (message) => {
    throw new ParameterError(`Parameter "${name}": ${message}`);
  };
  if (value === void 0 || value === null)
    fail(type.one ? "pass one object, whose keys the column list names." : "pass an array of objects, whose keys the column list names; an empty array inserts nothing.");
  const rows = type.one ? [value] : Array.isArray(value) ? value : fail(`pass an array of objects, one per row; got ${describe(value)}.`);
  const known = new Map(type.fields.map((f) => [f.name, f]));
  let present;
  let first = -1;
  const out = [];
  rows.forEach((row, i) => {
    const where = type.one ? "" : `row ${i + 1}: `;
    if (row === null || typeof row !== "object" || Array.isArray(row) || row instanceof Date)
      fail(`${where}each row is an object whose keys the column list names; got ${describe(row)}.`);
    const r = row;
    for (const key of Object.keys(r)) {
      if (!known.has(key) && r[key] !== void 0)
        fail(`${where}the column list names no key "${key}" (it names ${type.fields.map((f) => `"${f.name}"`).join(", ")}).`);
    }
    const keys2 = /* @__PURE__ */ new Set();
    const written = {};
    for (const f of type.fields) {
      const v = r[f.name];
      if (v === void 0) {
        if (!f.optional)
          fail(`${where}"${f.name}" is ${f.written} not null, and the row leaves it out.`);
        continue;
      }
      keys2.add(f.name);
      if (v === null) {
        if (!f.nullable)
          fail(`${where}"${f.name}" is ${f.written} not null, and the row gives null${f.optional ? `; leave the key out for the column's default` : ""}.`);
        written[f.name] = null;
        continue;
      }
      const checked = check(f.type, f.written, v, dialect, (message) => fail(`${where}"${f.name}" ${message}`));
      if (f.schema !== void 0) {
        const filled = withDefaults(f.schema, checked);
        const failure = validate(f.schema, filled);
        if (failure)
          fail(`${where}"${f.name}"${failure.path ? ` at ${failure.path}` : ""} ${failure.message}.`);
        written[f.name] = filled;
      } else
        written[f.name] = checked;
    }
    if (inserted) {
      if (present === void 0) {
        present = keys2;
        first = i;
      } else {
        const differ = type.fields.find((f) => present.has(f.name) !== keys2.has(f.name));
        if (differ)
          fail(`row ${i + 1} ${keys2.has(differ.name) ? "gives" : "leaves out"} "${differ.name}", which row ${first + 1} ${keys2.has(differ.name) ? "leaves out" : "gives"}. Every row of one call gives the same keys, since one insert writes them all and a key left out takes its column's default: give "${differ.name}" in every row, or in none.`);
      }
    }
    out.push(written);
  });
  const keys = present ?? new Set(type.fields.map((f) => f.name));
  if (inserted && !type.fields.some((f) => keys.has(f.name)))
    fail("every key is left out, so the insert would name no column; give one at least.");
  const shaped = type.one ? out[0] : out;
  return { value: dialect === "postgres" ? shaped : write(shaped), present: keys };
}
function check(type, written, v, dialect, fail) {
  switch (type.kind) {
    case "json":
      try {
        if (JSON.stringify(v) === void 0)
          fail(`is ${written}, which holds a JSON value; got ${describe(v)}.`);
      } catch (e) {
        fail(`is ${written}, which holds a JSON value: ${e.message}.`);
      }
      return v;
    case "enum":
      if (typeof v === "string" && (type.labels.length === 0 || type.labels.includes(v)))
        return v;
      return fail(`is the enum ${type.name}, one of ${type.labels.map((l) => JSON.stringify(l)).join(", ")}; got ${describe(v)}.`);
    case "array": {
      if (!Array.isArray(v))
        return fail(`is ${written}, an array; got ${describe(v)}.`);
      const element = written.replace(/\s*\[\s*\]\s*$/, "");
      return v.map((e, i) => e === null ? null : check(type.of, element, e, dialect, (message) => fail(`element ${i + 1} ${message}`)));
    }
    case "scalar":
      return scalar(type.name, written, v, dialect, fail);
    default:
      return v;
  }
}
function scalar(name, written, v, dialect, fail) {
  if (name.includes("|")) {
    for (const part of name.split("|")) {
      try {
        return scalar(part, written, v, dialect, (message) => {
          throw new TypeError(message);
        });
      } catch {
      }
    }
    return fail(`is ${written}; got ${describe(v)}.`);
  }
  const range = INTEGERS[name];
  if (range) {
    const n = integer(range, name === "int8", written, v, fail, dialect !== "postgres");
    if (!WIDE.has(name))
      return Number(n);
    return dialect === "postgres" ? n.toString() : new Raw(n.toString());
  }
  switch (name) {
    case "float4":
    case "float8":
    case "real":
      if (typeof v === "number" && Number.isFinite(v))
        return v;
      return fail(`is ${written}, a finite number; got ${describe(v)}.`);
    case "numeric":
      return decimal(written, v, fail);
    case "bool":
      if (typeof v === "boolean")
        return v;
      return fail(`is ${written}, true or false; got ${describe(v)}.`);
    case "text":
    case "varchar":
    case "bpchar":
    case "char":
    case "name":
    case "citext": {
      if (typeof v !== "string")
        return fail(`is ${written}, a string; got ${describe(v)}.`);
      const n = /\(\s*(\d+)\s*\)/.exec(written)?.[1];
      if (n !== void 0 && [...v].length > Number(n))
        fail(`is ${written}, at most ${n} characters; got ${[...v].length}, which the database would refuse or cut.`);
      return v;
    }
    case "vector":
    case "halfvec":
      if (Array.isArray(v) && v.length > 0 && v.every((e) => typeof e === "number" && Number.isFinite(e)))
        return JSON.stringify(v);
      if (typeof v === "string")
        return v;
      return fail(`is ${written}, an array of finite numbers with one at least; got ${describe(v)}.`);
    case "hstore":
      if (v !== null && typeof v === "object")
        return hstoreText(v, (message) => fail(message.replace(/^is an hstore/, `is ${written}`)));
      if (typeof v === "string")
        return v;
      return fail(`is ${written}, an object of its keys whose values are strings or null; got ${describe(v)}.`);
    case "uuid":
      if (typeof v === "string" && /^\{?[0-9a-f]{8}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{12}\}?$/i.test(v))
        return v;
      return fail(`is ${written}, a UUID in hexadecimal; got ${describe(v)}.`);
    case "timestamptz":
      if (v instanceof Date)
        return fail(`is ${written}, which takes the instant as a string that names its zone, not a Date: pass date.toISOString() ("2026-10-12T19:06:48.282Z").`);
      if (typeof v === "string" && zoned.test(v.trim()))
        return dialect === "postgres" ? postgresYear(v) : v;
      return fail(`is ${written}, an instant: a string that names its zone ("2026-10-12T19:06:48.282Z", "2026-10-12 19:06:48+09"); got ${describe(v)}, which the server would read in the session's time zone.`);
    case "timestamp":
    case "date":
      if (typeof v === "string")
        return dialect === "postgres" ? postgresYear(v) : v;
      return fail(`is ${written}, a wall-clock reading with no zone, which takes its text ("2026-10-12 19:06:48.282", "2026-10-12"), not a Date: drivers write a Date's time in different zones.${v instanceof Date ? "" : ` Got ${describe(v)}.`}`);
    case "bytea":
    case "blob": {
      if (!(v instanceof Uint8Array))
        return fail(`is ${written}, binary data, a Uint8Array; got ${describe(v)}.`);
      const n = /\(\s*(\d+)\s*\)/.exec(written)?.[1];
      if (n !== void 0 && v.length > Number(n))
        fail(`is ${written}, at most ${n} bytes; got ${v.length}, which the database would refuse or cut.`);
      let hex = dialect === "postgres" ? "\\x" : "";
      for (const byte of v)
        hex += (byte < 16 ? "0" : "") + byte.toString(16);
      return hex;
    }
    case "interval":
      if (typeof v === "string")
        return postgresInterval(v);
      if (typeof v === "number")
        return v;
      return fail(`is ${written}; got ${describe(v)}.`);
    default:
      if (typeof v === "string" || typeof v === "number" || typeof v === "boolean")
        return v;
      return fail(`is ${written}; got ${describe(v)}.`);
  }
}
function integer(range, digits, written, v, fail, truth = false) {
  let n;
  if (typeof v === "bigint")
    n = v;
  else if (typeof v === "boolean" && truth)
    n = BigInt(v ? 1 : 0);
  else if (typeof v === "number" && Number.isInteger(v)) {
    if (!Number.isSafeInteger(v))
      fail(`is ${written}; ${v} is past 2^53 - 1, where a number stops being exact, so pass it as a BigInt${digits ? " or a string of digits" : ""}.`);
    n = BigInt(v);
  } else if (typeof v === "string" && /^[+-]?\d+$/.test(v.trim()) && digits)
    n = BigInt(v.trim());
  else
    return fail(`is ${written}, an integer; got ${describe(v)}.`);
  if (n < range[0] || n > range[1])
    fail(`is ${written}, from ${range[0]} to ${range[1]}; got ${n}.`);
  return n;
}
const MYSQL_INTEGERS = {
  tinyint: [BigInt(-128), BigInt(127)],
  smallint: INTEGERS.int2,
  int2: INTEGERS.int2,
  mediumint: [BigInt(-8388608), BigInt(8388607)],
  int: INTEGERS.int4,
  integer: INTEGERS.int4,
  int4: INTEGERS.int4,
  bigint: INTEGERS.int8,
  int8: INTEGERS.int8,
  signed: INTEGERS.int8
};
export function checkCast(name, written, type, v, dialect) {
  if (v === null || v === void 0)
    return;
  const fail = (message) => {
    throw new ParameterError(`Parameter "${name}" ${message}`);
  };
  const base = written.replace(/\s*\(.*$/, "");
  const signed = dialect === "sqlite" ? /int/i.test(base) ? INTEGERS.integer : void 0 : MYSQL_INTEGERS[base.replace(/\s*unsigned$/, "") || "bigint"];
  if (signed) {
    const range = dialect === "mysql" && base.endsWith("unsigned") ? [BigInt(0), signed[1] * BigInt(2) + BigInt(1)] : signed;
    integer(range, dialect === "mysql" && range[1] >= INTEGERS.int8[1], written, v, fail, true);
    return;
  }
  if (base === "uuid") {
    scalar("uuid", written, v, dialect, fail);
    return;
  }
  if (dialect === "mysql" && (base === "date" || base === "time" || base === "datetime" || base === "timestamp")) {
    wallClock(base, written, v, fail);
    return;
  }
  check(type, written, v, dialect, fail);
}
function wallClock(base, written, v, fail) {
  const example = base === "date" ? `"2026-10-12"` : base === "time" ? `"19:06:48"` : `"2026-10-12 19:06:48.282"`;
  if (typeof v !== "string")
    return void fail(`is ${written}, which takes its text (${example}), not ${describe(v)}${v instanceof Date ? ": drivers write a Date's time in different zones" : ""}.`);
  const s = v.trim();
  const keeps = Number(/\(\s*(\d+)\s*\)/.exec(written)?.[1] ?? (base === "time" ? 0 : 6));
  const m = base === "time" ? /^(-?)(\d{1,3}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?$/.exec(s) : /^(\d{4})-(\d{2})-(\d{2})(?:(?:[T ])(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?)?$/.exec(s);
  const ok = (() => {
    if (!m)
      return false;
    if (base === "time")
      return Number(m[2]) <= 838 && Number(m[3]) < 60 && Number(m[4] ?? 0) < 60 && (m[5] ?? "").length <= keeps;
    const [year, month, day] = [Number(m[1]), Number(m[2]), Number(m[3])];
    const days = new Date(Date.UTC(year, month, 0)).getUTCDate();
    if (month < 1 || month > 12 || day < 1 || day > days)
      return false;
    if (base === "date")
      return m[4] === void 0;
    return Number(m[4] ?? 0) < 24 && Number(m[5] ?? 0) < 60 && Number(m[6] ?? 0) < 60 && (m[7] ?? "").length <= keeps;
  })();
  if (!ok)
    fail(`is ${written}, as text like ${example}${keeps > 0 && base !== "date" ? ` with at most ${keeps} digits after the second's point` : base === "time" ? " with no fraction of a second" : ""}; got ${describe(v)}, which MySQL's CAST would make NULL or change.`);
}
function decimal(written, v, fail) {
  let text;
  if (typeof v === "number") {
    if (!Number.isFinite(v))
      return fail(`is ${written}, a finite decimal; got ${v}.`);
    text = String(v);
  } else if (typeof v === "string")
    text = v.trim();
  else if (typeof v === "bigint")
    text = v.toString();
  else
    return fail(`is ${written}, a decimal: a number or a string of its digits; got ${describe(v)}.`);
  const m = /^([+-]?)(\d*)(?:\.(\d*))?(?:e([+-]?\d+))?$/i.exec(text);
  if (!m || m[2] === "" && (m[3] ?? "") === "")
    return fail(`is ${written}, a decimal: a number or a string of its digits; got ${describe(v)}.`);
  const mod = /\(\s*(\d+)\s*(?:,\s*(-?\d+)\s*)?\)/.exec(written);
  if (mod) {
    const precision = Number(mod[1]);
    const scale = Number(mod[2] ?? 0);
    const exponent = Number(m[4] ?? 0);
    let whole = (m[2] ?? "").replace(/^0+/, "");
    let fraction = (m[3] ?? "").replace(/0+$/, "");
    if (exponent > 0) {
      const moved = fraction.slice(0, exponent).padEnd(exponent, "0");
      whole = (whole + moved).replace(/^0+/, "");
      fraction = fraction.slice(exponent);
    } else if (exponent < 0) {
      const digits = whole.padStart(-exponent, "0");
      fraction = (digits.slice(digits.length + exponent) + fraction).replace(/0+$/, "");
      whole = digits.slice(0, digits.length + exponent).replace(/^0+/, "");
    }
    if (fraction.length > scale)
      fail(`is ${written}, which keeps ${scale} digit${scale === 1 ? "" : "s"} after the point, so ${text} would be rounded.`);
    if (whole.length > precision - scale)
      fail(`is ${written}, which holds at most ${precision - scale} digit${precision - scale === 1 ? "" : "s"} before the point; got ${text}.`);
  }
  return typeof v === "bigint" ? v.toString() : v;
}
function write(v) {
  if (v instanceof Raw)
    return v.text;
  if (Array.isArray(v))
    return `[${v.map(write).join(",")}]`;
  if (v !== null && typeof v === "object") {
    return `{${Object.entries(v).map(([k, x]) => `${JSON.stringify(k)}:${write(x)}`).join(",")}}`;
  }
  return JSON.stringify(v);
}
export function variant(text, structured, fields, present) {
  const lists = [...structured.lists].sort((a, b) => b.start - a.start);
  let out = text;
  for (const list of lists) {
    const kept = list.entries.filter((_, k) => {
      const f = fields[k];
      return f === void 0 || !f.optional || present.has(f.name);
    });
    out = out.slice(0, list.start) + kept.join(", ") + out.slice(list.end);
  }
  return out;
}
