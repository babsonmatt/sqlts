type AfterCompile = (metadata: {
    projectDir: string;
    distDir: string;
}) => Promise<void>;
type NextConfig = object & {
    typescript?: object & {
        ignoreBuildErrors?: boolean;
        tsconfigPath?: string;
    };
    turbopack?: object & {
        rules?: Record<string, unknown>;
    };
    webpack?: ((config: any, context: any) => any) | null;
    compiler?: object & {
        runAfterProductionCompile?: AfterCompile;
    };
};
export declare function withReylo<Config extends NextConfig>(config?: Config): Config;
export {};
