import { workerData } from "node:worker_threads";
import { sqlModuleSync } from "./bridge.js";
if (!workerData?.reyloWorker) {
  if (typeof Bun !== "undefined") {
    Bun.plugin({
      name: "reylo-sql",
      setup(build) {
        build.onLoad({ filter: /\.sql$/ }, (args) => ({ loader: "js", contents: sqlModuleSync(args.path) }));
      }
    });
  } else {
    const { registerHooks } = await import("node:module");
    const { fileURLToPath } = await import("node:url");
    registerHooks({
      load(url, context, nextLoad) {
        if (!url.endsWith(".sql"))
          return nextLoad(url, context);
        return { format: "module", source: sqlModuleSync(fileURLToPath(url)), shortCircuit: true };
      }
    });
  }
}
