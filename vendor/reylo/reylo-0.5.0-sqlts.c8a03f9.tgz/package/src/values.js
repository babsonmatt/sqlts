export const TS_TYPE = {
  bool: "boolean",
  int: "number",
  float: "number",
  int8: "bigint",
  decimal: "string",
  text: "string",
  date: "string",
  timestamp: "string",
  timestamptz: "string",
  interval: "string",
  json: "unknown",
  bytes: "Uint8Array",
  vector: "number[]",
  hstore: "Record<string, string | null>",
  unknown: "unknown"
};
const SQL_KINDS = {
  bool: "bool",
  int2: "int",
  int4: "int",
  oid: "int",
  float4: "float",
  float8: "float",
  int8: "int8",
  numeric: "decimal",
  date: "date",
  timestamp: "timestamp",
  timestamptz: "timestamptz",
  interval: "interval",
  json: "json",
  jsonb: "json",
  bytea: "bytes",
  vector: "vector",
  halfvec: "vector",
  hstore: "hstore"
};
const SQLITE_KINDS = {
  integer: "int",
  int8: "int8",
  real: "float",
  text: "text",
  blob: "bytes",
  numeric: "int|float|text",
  bool: "bool"
};
export function scalarKind(name, dialect) {
  const kinds = [...new Set(name.split("|").flatMap((part) => (dialect === "sqlite" ? SQLITE_KINDS[part] ?? "unknown" : SQL_KINDS[part] ?? "text").split("|")))];
  const wide = kinds.includes("int8") && !kinds.includes("float") ? kinds.filter((k) => k !== "int") : kinds;
  return wide.join("|");
}
export function arrayDelimiter(t) {
  return t.kind === "array" ? t.delimiter : void 0;
}
export function columnKind(t, dialect) {
  switch (t.kind) {
    case "scalar":
      return scalarKind(t.name, dialect);
    case "enum":
      return "text";
    case "array":
      if (t.of.kind === "scalar" && t.of.name === "record" || t.of.kind === "composite")
        return "text";
      return `${columnKind(t.of, dialect)}[]`;
    case "object":
    case "list":
    case "json":
    case "rows":
      return "json";
    case "composite":
      return "text";
    case "unknown":
      return "unknown";
  }
}
export function kindType(kind) {
  const parts = kind.split("|").map((k) => TS_TYPE[k] ?? "unknown");
  return parts.includes("unknown") ? "unknown" : [...new Set(parts)].join(" | ");
}
const identity = (x) => x;
const number = (x) => +x;
const timestamp = (x) => x.replace(" ", "T");
const TSTZ = /^(\d{4,})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)(\.\d{1,6})?([+-])(\d\d)(?::(\d\d))?(?::(\d\d))?( BC)?$/;
function daysFromCivil(y, m, d) {
  y -= m <= 2 ? 1 : 0;
  const era = Math.floor(y / 400);
  const yoe = y - era * 400;
  const doy = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
  const doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
  return era * 146097 + doe - 719468;
}
function civilFromDays(days) {
  const z = days + 719468;
  const era = Math.floor(z / 146097);
  const doe = z - era * 146097;
  const yoe = Math.floor((doe - Math.floor(doe / 1460) + Math.floor(doe / 36524) - Math.floor(doe / 146096)) / 365);
  const doy = doe - (365 * yoe + Math.floor(yoe / 4) - Math.floor(yoe / 100));
  const mp = Math.floor((5 * doy + 2) / 153);
  const d = doy - Math.floor((153 * mp + 2) / 5) + 1;
  const m = mp + (mp < 10 ? 3 : -9);
  return [era * 400 + yoe + (m <= 2 ? 1 : 0), m, d];
}
const pad = (n, width = 2) => String(n).padStart(width, "0");
const isoYear = (y) => y >= 0 && y <= 9999 ? pad(y, 4) : `${y < 0 ? "-" : "+"}${pad(Math.abs(y), 6)}`;
export function postgresYear(text) {
  const m = /^([+-]\d{6}|0000)(-.*)$/.exec(text);
  if (m === null || /\sbc$/i.test(text))
    return text;
  const year = +m[1];
  return year > 0 ? `${pad(year, 4)}${m[2]}` : `${pad(1 - year, 4)}${m[2]} BC`;
}
export function instant(x) {
  const m = TSTZ.exec(x);
  if (m === null)
    return x;
  const year = m[12] === void 0 ? +m[1] : 1 - +m[1];
  const offset = (m[8] === "-" ? -1 : 1) * (+m[9] * 3600 + (m[10] === void 0 ? 0 : +m[10] * 60) + (m[11] === void 0 ? 0 : +m[11]));
  const seconds = daysFromCivil(year, +m[2], +m[3]) * 86400 + +m[4] * 3600 + +m[5] * 60 + +m[6] - offset;
  const days = Math.floor(seconds / 86400);
  const s = seconds - days * 86400;
  const [y, mo, d] = civilFromDays(days);
  return `${isoYear(y)}-${pad(mo)}-${pad(d)}T${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}${m[7] ?? ""}Z`;
}
export function instantOfDate(d, column) {
  validDate(d, column);
  return d.toISOString().replace(/\.?0+Z$/, "Z");
}
const INTERVAL = /^(?:([+-]?\d+) years? ?)?(?:([+-]?\d+) mons? ?)?(?:([+-]?\d+) days? ?)?(?:([+-]?)(\d+):(\d\d):(\d\d)(?:\.(\d+))?)?$/;
export function duration(x) {
  const m = INTERVAL.exec(x);
  if (m === null || x === "")
    return x;
  const time = m[4] === "-" ? -1 : 1;
  const parts = [];
  for (const [designator, digits] of [["Y", m[1]], ["M", m[2]], ["D", m[3]]]) {
    if (digits !== void 0 && +digits !== 0)
      parts.push([designator, String(Math.abs(+digits)), digits.startsWith("-") ? -1 : 1]);
  }
  const date = parts.length;
  if (+(m[5] ?? 0) !== 0)
    parts.push(["H", String(+m[5]), time]);
  if (+(m[6] ?? 0) !== 0)
    parts.push(["M", String(+m[6]), time]);
  const fraction = (m[8] ?? "").replace(/0+$/, "");
  if (+(m[7] ?? 0) !== 0 || fraction !== "")
    parts.push(["S", `${+(m[7] ?? 0)}${fraction && `.${fraction}`}`, time]);
  if (parts.length === 0)
    return "PT0S";
  const negative = parts.every(([, , sign]) => sign < 0);
  const write = ([designator, magnitude, sign]) => `${sign < 0 && !negative ? "-" : ""}${magnitude}${designator}`;
  const clock = parts.slice(date).map(write).join("");
  return `${negative ? "-" : ""}P${parts.slice(0, date).map(write).join("")}${clock && `T${clock}`}`;
}
export function postgresInterval(text) {
  const m = /^\s*([+-])(P[^+-]*)$/i.exec(text);
  if (m === null)
    return text;
  return m[1] === "+" ? m[2] : m[2].replace(/(\d+(?:[.,]\d+)?)([YMWDHS])/gi, "-$1$2");
}
const NodeBuffer = globalThis.Buffer;
const Utf8 = globalThis.TextDecoder;
const utf8Decoder = new Utf8("utf-8");
export function utf8(bytes) {
  return NodeBuffer?.isBuffer(bytes) ? bytes.toString("utf8") : utf8Decoder.decode(bytes);
}
const fromHex = Uint8Array.fromHex;
export function bytea(x) {
  if (x.charCodeAt(0) === 92 && x.charCodeAt(1) === 120) {
    const hex = x.slice(2);
    if (NodeBuffer)
      return NodeBuffer.from(hex, "hex");
    if (fromHex)
      return fromHex(hex);
    const out2 = new Uint8Array(hex.length / 2);
    for (let i = 0; i < out2.length; i++)
      out2[i] = parseInt(hex.slice(2 * i, 2 * i + 2), 16);
    return out2;
  }
  const out = [];
  for (let i = 0; i < x.length; i++) {
    if (x[i] !== "\\")
      out.push(x.charCodeAt(i));
    else if (x[i + 1] === "\\")
      out.push(92), i++;
    else
      out.push(parseInt(x.slice(i + 1, i + 4), 8)), i += 3;
  }
  return Uint8Array.from(out);
}
export function hstore(x) {
  const pairs = [];
  const n = x.length;
  let i = 0;
  const quoted = () => {
    let s = "";
    let from = ++i;
    while (i < n && x[i] !== '"') {
      if (x[i] === "\\")
        s += x.slice(from, i), from = ++i;
      i++;
    }
    s += x.slice(from, i++);
    return s;
  };
  while (i < n) {
    while (x[i] === " " || x[i] === ",")
      i++;
    if (i >= n || x[i] !== '"')
      break;
    const key = quoted();
    i += 2;
    if (x[i] === '"')
      pairs.push([key, quoted()]);
    else
      pairs.push([key, null]), i += 4;
  }
  return Object.fromEntries(pairs);
}
export function hstoreText(v, fail) {
  const proto = Object.getPrototypeOf(v);
  if (proto !== Object.prototype && proto !== null) {
    const name = Array.isArray(v) || v instanceof Date || ArrayBuffer.isView(v) ? void 0 : v.constructor?.name;
    return fail(`is an hstore, an object of its keys whose values are strings or null; got ${typeof name === "string" && name ? `a ${name}` : describe(v)}.`);
  }
  const quote = (s) => `"${s.replace(/[\\"]/g, "\\$&")}"`;
  const pairs = [];
  for (const [key, value] of Object.entries(v)) {
    if (value === void 0)
      continue;
    if (value !== null && typeof value !== "string")
      fail(`is an hstore, whose values are strings or null, and its key ${JSON.stringify(key)} holds ${describe(value)}.`);
    pairs.push(`${quote(key)}=>${value === null ? "NULL" : quote(value)}`);
  }
  return pairs.join(", ");
}
const TEXT_DECODERS = {
  bool: (x) => x === "t",
  int: number,
  float: number,
  int8: (x) => BigInt(x),
  decimal: identity,
  text: identity,
  date: identity,
  timestamp,
  timestamptz: instant,
  interval: duration,
  json: (x) => JSON.parse(x),
  bytes: bytea,
  // pgvector prints the shortest text of each float, `[1,2.5,1e-07]`, which JSON reads exactly.
  vector: (x) => JSON.parse(x),
  hstore,
  unknown: identity
};
export function parseArray(text, element, delim = ",") {
  const n = text.length;
  let i = text[0] === "[" ? text.indexOf("=") + 1 : 0;
  const level = () => {
    const out = [];
    i++;
    if (text[i] === "}")
      return i++, out;
    while (i < n) {
      if (text[i] === "{")
        out.push(level());
      else if (text[i] === '"') {
        let s = "";
        let from = ++i;
        while (i < n && text[i] !== '"') {
          if (text[i] === "\\")
            s += text.slice(from, i), from = ++i;
          i++;
        }
        out.push(element(s + text.slice(from, i++)));
      } else {
        const from = i;
        while (i < n && text[i] !== delim && text[i] !== "}")
          i++;
        const s = text.slice(from, i);
        out.push(s === "NULL" ? null : element(s));
      }
      if (text[i++] === "}")
        return out;
    }
    return out;
  };
  return level();
}
export function textDecoder(kind, delim = ",") {
  if (kind.endsWith("[]")) {
    const element = textDecoder(kind.slice(0, -2), delim);
    return (x) => parseArray(x, element, delim);
  }
  return TEXT_DECODERS[kind] ?? identity;
}
export class DecodeError extends TypeError {
}
export class ParameterError extends TypeError {
}
export const zoned = /(?:\d:\d\d(?::\d\d(?:\.\d+)?)?(?:\s*(?:z|[+-]\d\d?(?::?\d\d){0,2})|\s+[a-z][\w/+-]*)|^-?infinity|^epoch|^now)(?:\s+bc)?$/i;
export function describe(v) {
  if (v === null)
    return "null";
  if (v instanceof Date)
    return "a Date";
  if (Array.isArray(v))
    return "an array";
  if (v instanceof Uint8Array)
    return "binary data";
  if (typeof v === "bigint")
    return `${v}n`;
  if (typeof v === "string")
    return JSON.stringify(v.length > 60 ? `${v.slice(0, 57)}...` : v);
  if (typeof v === "object")
    return "an object";
  return String(v);
}
const MAX_SAFE = Number.MAX_SAFE_INTEGER;
export function exactInteger(v, column) {
  if (typeof v === "bigint") {
    const n = Number(v);
    if (n > MAX_SAFE || n < -MAX_SAFE)
      throw outOfRange(String(v), column);
    return n;
  }
  if (v > MAX_SAFE || v < -MAX_SAFE)
    throw outOfRange(String(v), column, true);
  return v;
}
function outOfRange(value, column, rounded = false) {
  return new DecodeError(rounded ? `Column "${column}" holds an integer past \xB1(2^53 - 1), which the driver already rounded to ${value}: a number cannot hold it exactly, so Reylo refuses it rather than return a rounded value. Cast it to text in the statement (cast(${column} as text)) to read it exactly.` : `Column "${column}" holds ${value}, an integer past \xB1(2^53 - 1), which a number cannot hold exactly, so Reylo refuses it rather than return a rounded value. Cast it to text in the statement (cast(${column} as text)) to read it exactly.`);
}
const INTEGER = /^[+-]?\d+$/;
export function bigInteger(v, column) {
  if (typeof v === "bigint")
    return v;
  if (typeof v === "string")
    return INTEGER.test(v) ? BigInt(v) : v;
  if (Number.isSafeInteger(v))
    return BigInt(v);
  if (Number.isInteger(v))
    throw new DecodeError(`Column "${column}" is a 64-bit integer, and the driver already rounded its value to ${v}, past \xB1(2^53 - 1): Reylo refuses it rather than return a BigInt of a rounded value.`);
  return v;
}
export function truth(v, column) {
  switch (typeof v) {
    case "boolean":
      return v;
    case "number":
      if (v === 0 || v === 1)
        return v === 1;
      break;
    case "bigint":
      if (v === BigInt(0) || v === BigInt(1))
        return v === BigInt(1);
      break;
    case "string":
      if (v === "t" || v === "true" || v === "1")
        return true;
      if (v === "f" || v === "false" || v === "0")
        return false;
      break;
    case "object":
      if (v instanceof Uint8Array && v.length === 1 && v[0] <= 1)
        return v[0] === 1;
      break;
  }
  const shown = v instanceof Uint8Array ? `the bytes 0x${Array.from(v, (b) => b.toString(16).padStart(2, "0")).join("")}` : typeof v === "string" ? JSON.stringify(v) : String(v);
  return refuseTruth(column, shown);
}
export function refuseTruth(column, shown) {
  throw new DecodeError(`Column "${column}" is a boolean, stored as 0 or 1, and holds ${shown}, which is neither: the database does not hold the column to 0 and 1, so Reylo refuses the value rather than guess its truth. Store 0 or 1 in it, or read the stored number with ${column} + 0 in the statement.`);
}
function validDate(d, column) {
  if (Number.isNaN(d.getTime()))
    throw new DecodeError(`Column "${column}": the driver returned an Invalid Date, which is how Bun.sql decodes a date or timestamp before 1 AD. Reylo refuses it rather than return a wrong value.`);
}
function utcText(d, kind, column) {
  validDate(d, column);
  const year = d.getUTCFullYear();
  const date = `${pad(year > 0 ? year : 1 - year, 4)}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  const bc = year > 0 ? "" : " BC";
  if (kind === "date")
    return date + bc;
  const ms = d.getUTCMilliseconds();
  return `${date}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}${ms ? `.${pad(ms, 3).replace(/0+$/, "")}` : ""}${bc}`;
}
const isBytes = (v) => v instanceof Uint8Array;
export function float32s(bytes, column) {
  if (bytes.byteLength % 4 !== 0)
    throw new DecodeError(`Column "${column}" is a VECTOR, whose value is 4 bytes per 32-bit float, and holds ${bytes.byteLength} bytes.`);
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  return Array.from({ length: bytes.byteLength / 4 }, (_, i) => view.getFloat32(i * 4, true));
}
export function coerce(kind, v, column, delim = ",") {
  if (v === null || v === void 0)
    return null;
  if (kind.endsWith("[]")) {
    const element = kind.slice(0, -2);
    if (typeof v === "string")
      return parseArray(v, (s) => coerce(element, s, column), delim);
    if (Array.isArray(v))
      return v.map((e) => Array.isArray(e) ? coerce(kind, e, column, delim) : coerce(element, e, column));
    if (element === "float" && isBytes(v))
      return float32s(v, column);
    if (ArrayBuffer.isView(v) && !(v instanceof DataView))
      return Array.from(v, (e) => coerce(element, e, column));
    return v;
  }
  if (kind.includes("|"))
    return coerceEither(kind, v, column);
  switch (kind) {
    case "bool":
      return truth(v, column);
    case "int":
    case "float":
      if (typeof v === "number")
        return kind === "int" ? exactInteger(v, column) : v;
      if (typeof v === "bigint")
        return exactInteger(v, column);
      if (typeof v === "string" && v !== "" && !Number.isNaN(+v))
        return kind === "int" && /^[+-]?\d+$/.test(v) ? exactInteger(BigInt(v), column) : +v;
      return v;
    case "int8":
      if (typeof v === "bigint" || typeof v === "number" || typeof v === "string")
        return bigInteger(v, column);
      return v;
    case "decimal":
      if (typeof v === "bigint" || typeof v === "number")
        return String(v);
      return v;
    case "date":
    case "timestamp":
      if (v instanceof Date)
        return utcText(v, kind, column);
      if (v === Infinity || v === -Infinity)
        return v > 0 ? "infinity" : "-infinity";
      return v;
    case "timestamptz":
      if (typeof v === "string")
        return instant(v);
      if (v instanceof Date)
        return instantOfDate(v, column);
      if (v === Infinity || v === -Infinity)
        return v > 0 ? "infinity" : "-infinity";
      return v;
    case "interval":
      return typeof v === "string" ? duration(v) : v;
    case "json":
    case "vector":
      return typeof v === "string" ? JSON.parse(v) : v;
    case "hstore":
      return typeof v === "string" ? hstore(v) : v;
    case "bytes":
      if (isBytes(v))
        return v;
      if (v instanceof ArrayBuffer)
        return new Uint8Array(v);
      if (Array.isArray(v))
        return Uint8Array.from(v);
      if (typeof v === "boolean")
        return Uint8Array.of(v ? 1 : 0);
      if (typeof v === "string")
        return bytea(v);
      return v;
    case "text":
      if (typeof v === "string")
        return v;
      if (Array.isArray(v))
        return v.join(",");
      if (typeof v === "number" || typeof v === "bigint")
        return String(v);
      return v;
    default:
      return v;
  }
}
function coerceEither(kind, v, column) {
  const kinds = kind.split("|");
  if (typeof v === "bigint")
    return kinds.includes("int8") ? v : exactInteger(v, column);
  if (typeof v === "number") {
    if (kinds.includes("float") || !Number.isInteger(v))
      return v;
    if (kinds.includes("int"))
      return exactInteger(v, column);
    return kinds.includes("int8") ? bigInteger(v, column) : v;
  }
  if (v instanceof Date)
    return kinds.includes("timestamp") ? utcText(v, "timestamp", column) : kinds.includes("date") ? utcText(v, "date", column) : kinds.includes("timestamptz") ? instantOfDate(v, column) : v;
  if (v instanceof ArrayBuffer || Array.isArray(v) && kinds.includes("bytes"))
    return coerce("bytes", v, column);
  return v;
}
