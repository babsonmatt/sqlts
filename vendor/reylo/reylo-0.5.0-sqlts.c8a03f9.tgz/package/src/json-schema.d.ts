type Schema = boolean | {
    readonly [key: string]: unknown;
};
/** Why a value fails a schema: the place in the value, as a JSON Pointer, and what it breaks. */
export type Failure = {
    path: string;
    message: string;
};
/**
 * A fresh copy of a JSON value, such as a schema's `default`, so that filling one in never shares
 * it between calls. A JSON round trip rather than `structuredClone`, which the run time cannot name
 * where a project's tsconfig loads no Node or DOM types (the labs set `"types": []`), and which
 * gives the same copy for a JSON value.
 */
export declare function cloneJson<T>(value: T): T;
/**
 * The value with the schema's defaults filled in, as ajv's `useDefaults` fills them (a
 * JSON parameter's default is its schema's `default`): a key `properties`
 * names and the value lacks takes its `default`, and so does an item `prefixItems` names past the
 * array's end. A key that is null keeps its null. Defaults are filled wherever the schema applies
 * to the value but inside `anyOf`, `oneOf`, `not`, `if`, `contains` and `propertyNames`, whose
 * matches are unknown until the checks run. The value given is not changed: a copy comes back.
 */
export declare function withDefaults(schema: Schema, value: unknown): unknown;
/** The first failure of `value` against `schema`, or `undefined` when it passes. */
export declare function validate(schema: Schema, value: unknown): Failure | undefined;
export {};
