export const FRESH_FOR = 6e4;
const checked = /* @__PURE__ */ new WeakMap();
const clock = globalThis.performance;
export function due(query, now = clock.now()) {
  const at = checked.get(query);
  return at === void 0 || now - at >= FRESH_FOR;
}
export function passed(query, now = clock.now()) {
  checked.set(query, now);
}
const yes = (v) => v === "true" || v === "1";
const describe = (r) => `${r[2]}${yes(r[3]) ? " not null" : ""}${yes(r[4]) ? " with a default" : ""}`;
const table = (name) => name.replace(/^"|"$/g, "").replace(/"\."/g, ".");
const COLUMNS = ["fresh_table", "fresh_column", "fresh_type", "fresh_not_null", "fresh_default", "fresh_expr"];
export function differences(fresh, rows, dialect) {
  const now = /* @__PURE__ */ new Map();
  const width = fresh.rows[0]?.length === 6 ? 6 : 5;
  const columns = COLUMNS.slice(0, width);
  for (const row of rows) {
    if (row === null || typeof row !== "object")
      return void 0;
    const raw = Array.isArray(row) ? row.length === width ? row : void 0 : Object.keys(row).length === width && columns.every((k) => k in row) ? columns.map((k) => row[k]) : void 0;
    if (raw === void 0)
      return void 0;
    const values = raw.map((v) => v === null || v === void 0 ? "" : String(v));
    now.set(`${values[0]}\0${values[1]}`, values);
  }
  const sameType = dialect === "sqlite" ? (a, b) => a === b || asciiLower(a) === asciiLower(b) : (a, b) => a === b;
  const sameDefault = dialect === "sqlite" ? (a, b) => a === b || sqliteDefault(a) === sqliteDefault(b) : (a, b) => a === b;
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const copied = new Set((fresh.defaults ?? []).map((d) => `${d[0]}\0${d[1]}`));
  for (const was of fresh.rows) {
    const key = `${was[0]}\0${was[1]}`;
    seen.add(key);
    const is = now.get(key);
    if (!is)
      out.push(`${table(was[0])}.${was[1]} was ${describe(was)} and no longer exists`);
    else if (!sameType(is[2], was[2]) || yes(is[3]) !== yes(was[3]) || yes(is[4]) !== yes(was[4]))
      out.push(`${table(was[0])}.${was[1]} was ${describe(was)} and is now ${describe(is)}`);
    else if (copied.has(key) && !sameDefault(is[5], was[5]))
      out.push(`${table(was[0])}.${was[1]} had ${was[5] ? `the default ${was[5]}` : "no default"}, which the insert writes for a row that leaves its key out, and now has ${is[5] ? `the default ${is[5]}` : "none"}`);
  }
  for (const [key, is] of now) {
    if (!seen.has(key) && fresh.inserts.includes(is[0]) && yes(is[3]) && !yes(is[4]))
      out.push(`${table(is[0])}.${is[1]} is now ${describe(is)}, which the insert does not write`);
  }
  return out;
}
export function sqliteDefault(text) {
  const t = text.trim();
  const lone = /^(?:"((?:[^"]|"")*)"|`((?:[^`]|``)*)`|\[([^\]]*)\]|([A-Za-z_\u0080-\uffff][\w$\u0080-\uffff]*))$/.exec(t);
  if (lone && !(lone[4] !== void 0 && /^(?:true|false|null|current_time|current_date|current_timestamp)$/i.test(lone[4]))) {
    const name = lone[1] !== void 0 ? lone[1].replace(/""/g, '"') : lone[2] !== void 0 ? lone[2].replace(/``/g, "`") : lone[3] ?? lone[4];
    return `'${name.replace(/'/g, "''")}'`;
  }
  let out = "";
  for (let i = 0; i < t.length; ) {
    if (t[i] === "'") {
      let j = i + 1;
      while (j < t.length && !(t[j] === "'" && t[j + 1] !== "'"))
        j += t[j] === "'" ? 2 : 1;
      out += t.slice(i, j + 1);
      i = j + 1;
    } else {
      if (!/\s/.test(t[i]))
        out += asciiUpper(t[i]);
      i++;
    }
  }
  while (out.startsWith("(") && out.endsWith(")") && closes(out) === out.length - 1)
    out = out.slice(1, -1);
  return out;
}
function closes(s) {
  let depth = 0;
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "'") {
      i++;
      while (i < s.length && !(s[i] === "'" && s[i + 1] !== "'"))
        i += s[i] === "'" ? 2 : 1;
    } else if (s[i] === "(")
      depth++;
    else if (s[i] === ")" && --depth === 0)
      return i;
  }
  return -1;
}
const asciiUpper = (s) => s.replace(/[a-z]+/g, (m) => m.toUpperCase());
const asciiLower = (s) => s.replace(/[A-Z]+/g, (m) => m.toLowerCase());
export function staleError(source, lines) {
  return new Error(`The database changed after ${source ? `${source} was built` : "this query was built"}: ${lines.join("; ")}. Build it again (the type check, or reylo generate) and deploy the new build.`);
}
