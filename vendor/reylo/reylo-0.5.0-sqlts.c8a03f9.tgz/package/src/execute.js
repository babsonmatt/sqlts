import { bunRows, neonCallable, postgresJs, queryPostgres, slonik } from "./decode.js";
import { mariadb, mysql2, planetscale } from "./decode-mysql.js";
import { normalize, runDurableObject, runSyncSqlite, runTurso } from "./decode-sqlite.js";
import { describe, hstoreText, ParameterError, postgresInterval, postgresYear, zoned } from "./values.js";
import { lexPlaceholders } from "./lex.js";
import { differences, due, passed, staleError } from "./fresh.js";
export function execute(client, query, params = {}) {
  const c = underneath(client);
  if (query.dialect === "sqlite" && (isSyncSqlite(c) || isDurableObjectSql(c)))
    return executeSyncSqlite(c, query, params);
  return executeAsync(c, query, params);
}
function underneath(c) {
  const o = c;
  const session = o != null && typeof o === "object" && typeof o.select === "function" ? o.session : void 0;
  if (session == null || typeof session !== "object" || session.dialect == null)
    return c;
  const client = session.tx ?? session.client ?? c;
  const sql = client.sql;
  return isDurableObjectSql(sql) ? sql : client;
}
export function executeSync(client, query, params = {}) {
  const c = underneath(client);
  const refuse = (why) => new TypeError(`runSync takes a synchronous SQLite client (better-sqlite3, node:sqlite, bun:sqlite, the Database of @tursodatabase/database/compat or a Durable Object's ctx.storage.sql); ${why}. run takes every client.`);
  if (query.dialect !== "sqlite")
    throw refuse(`a ${query.dialect} statement has none`);
  if (!isSyncSqlite(c) && !isDurableObjectSql(c))
    throw refuse("this client answers through a promise");
  const rows = executeSyncSqlite(c, query, params);
  if (Array.isArray(rows))
    return rows;
  rows.catch(() => {
  });
  throw refuse("this client's statement answered with a promise");
}
function executeSyncSqlite(c, query, params) {
  checkParams(query, params);
  if (query.fresh && due(query)) {
    let rows;
    try {
      rows = isDurableObjectSql(c) ? c.exec(query.fresh.query).toArray() : c.prepare(query.fresh.query).all();
    } catch {
    }
    const lines = (rows && differences(query.fresh, rows, query.dialect)) ?? [];
    if (lines.length)
      throw staleError(query.source, lines);
    passed(query);
  }
  const { text, values, names } = statement(query, params);
  if (isDurableObjectSql(c))
    return runDurableObject(c, text, durableObjectValues(query, names, values), query.columns);
  return runSyncSqlite(c, text, values, query.columns);
}
function isDurableObjectSql(c) {
  return c != null && typeof c.exec === "function" && typeof c.prepare !== "function" && typeof c.all !== "function" && "databaseSize" in c;
}
function durableObjectValues(query, names, values) {
  return values.map((v, i) => numberOrDigits(v, query.inputs?.[names[i]]?.type, "durable-object"));
}
function isSyncSqlite(c) {
  return c != null && typeof c.prepare === "function" && (typeof c.batch !== "function" || typeof c.maxWriteReplicationIndex === "function") && typeof c.all !== "function" && typeof c.execute !== "function" && typeof c.unsafe !== "function" && !isTurso(c);
}
function isTurso(c) {
  return typeof c.prepare === "function" && (typeof c.connect === "function" && typeof c.maxWriteReplicationIndex === "function" || typeof c.all === "function" && typeof c.batch === "function");
}
function isSlonik(c) {
  return typeof c.maybeOneFirst === "function" && typeof c.anyFirst === "function";
}
function slonikParam(v) {
  if (v === void 0 || v === null)
    return null;
  if (v instanceof Uint8Array)
    return asByteaHex(v);
  if (Array.isArray(v))
    return arrayLiteral(v);
  if (v instanceof Date)
    return v.toISOString();
  return typeof v === "object" ? JSON.stringify(v) : v;
}
async function executeAsync(c, query, params) {
  if (c == null || typeof c !== "object" && typeof c !== "function")
    throw unsupported(c, query.dialect);
  checkParams(query, params);
  if (query.fresh && due(query)) {
    const fresh = query.fresh;
    let rows;
    try {
      rows = await executeAsync(c, { dialect: query.dialect, sql: fresh.query, params: [], text: fresh.query, order: [] }, {});
    } catch {
    }
    const lines = (rows && differences(fresh, rows, query.dialect)) ?? [];
    if (lines.length)
      throw staleError(query.source, lines);
    passed(query);
  }
  const { text, values, names } = statement(query, params);
  const type = (i) => query.inputs?.[names[i]]?.type;
  const isJsonParam = (v, i) => isJsonValue(query, names[i], v);
  switch (query.dialect) {
    case "postgres": {
      const bound = values.map((v, i) => {
        const t = type(i);
        return Array.isArray(v) && t?.kind === "array" ? arrayLiteral(isJson(t.of.kind) ? v.map((e) => e == null ? e : JSON.stringify(e)) : v, t.delimiter) : v;
      });
      const json = () => bound.map((v, i) => isJsonParam(v, i) ? JSON.stringify(v) : v);
      if (isSlonik(c))
        return await slonik(c, text, json().map(slonikParam), query.columns);
      if (typeof c.query === "function")
        return await queryPostgres(c, text, json(), query.columns);
      if (typeof c.unsafe === "function") {
        const bun = typeof c.commitDistributed === "function";
        const asText = typeof c.typed === "function" && !bun;
        const mapped = bound.map((v, i) => isJsonParam(v, i) ? asText ? c.typed(JSON.stringify(v), 705) : { toJSON: () => v } : asText && typeof v === "string" && isTime(type(i)) ? c.typed(v, 705) : v);
        return bun ? bunRows(await c.unsafe(text, mapped), query.columns) : await postgresJs(c, text, mapped, query.columns);
      }
      if (typeof c === "function")
        return await neonCallable(c, text, json().map(asByteaHex), query.columns);
      break;
    }
    case "mysql": {
      if (typeof c.unsafe === "function")
        return bunRows(await c.unsafe(text, values), query.columns);
      if (typeof c.batch === "function" && typeof c.query === "function")
        return await mariadb(c, text, values.map(asBuffer), query.columns);
      const m = typeof c.promise === "function" ? c.promise() : c;
      if (typeof m.execute === "function") {
        return typeof m.query === "function" ? await mysql2(m, text, values, query.columns) : await planetscale(m, text, values, query.columns);
      }
      break;
    }
    case "sqlite": {
      const columns = query.columns;
      if (typeof c.unsafe === "function")
        return normalize(await c.unsafe(text, values), columns);
      if (typeof c.execute === "function")
        return normalize((await c.execute({ sql: text, args: values })).rows, columns);
      if (isTurso(c))
        return await runTurso(c, text, values, columns);
      if (typeof c.getDatabaseInstance === "function")
        return normalize(await c.all(text, values.map((v, i) => numberOrDigits(v, type(i), "sqlite3"))), columns);
      if (typeof c.all === "function" && typeof c.exec === "function") {
        const bound = values.map((v, i) => numberOrDigits(v, type(i), "sqlite3"));
        return normalize(await new Promise((resolve, reject) => c.all(text, bound, (error, rows) => error ? reject(error) : resolve(rows))), columns);
      }
      if (typeof c.prepare === "function") {
        const prepared = c.prepare(text);
        if (typeof prepared.first === "function")
          return normalize((await prepared.bind(...values).all()).results, columns, { d1: true });
        return normalize(await prepared.all(...values), columns);
      }
      break;
    }
  }
  throw unsupported(c, query.dialect);
}
function checkParams(query, input) {
  if (input !== null && typeof input === "object" && !Array.isArray(input))
    return;
  const keys = query.params.map((name) => `${/^(?:[A-Za-z_$][\w$]*|\d+)$/.test(name) ? name : JSON.stringify(name)}: ...`);
  const takes = keys.length ? `This statement takes { ${keys.join(", ")} }.` : "This statement takes none: leave them out.";
  throw new ParameterError(`The parameters must be an object keyed by parameter name, or by number for positional placeholders ({ 1: ..., 2: ... }); got ${Array.isArray(input) ? "an array" : String(input)}. ${takes}`);
}
function statement(query, params) {
  const compiled = compile(query);
  const bound = { text: compiled.text, values: compiled.order.map((name) => value(params, name)), names: compiled.order };
  bound.names.forEach((name, i) => {
    const input = query.inputs?.[name];
    const type = input?.type;
    const schema = input?.schema;
    if (schema !== void 0) {
      let v = params[name];
      const { cloneJson, validate, withDefaults } = checksFor(query, name);
      if (v === void 0 && schema !== null && typeof schema === "object" && "default" in schema)
        v = cloneJson(schema.default);
      if (v !== void 0 && v !== null) {
        v = withDefaults(schema, v);
        const failure = validate(schema, v);
        if (failure)
          throw new ParameterError(`Parameter "${name}"${failure.path ? ` at ${failure.path}` : ""} ${failure.message}.`);
      } else if (input?.nullable === false && validate(schema, null)) {
        refuseNull(name, v);
      }
      bound.values[i] = v === void 0 ? null : v;
      return;
    }
    if (type?.kind === "rows") {
      const structured = query.structured?.find((s) => s.name === name);
      const { prepareRows, variant } = checksFor(query, name);
      const prepared = prepareRows(name, type, bound.values[i], query.dialect, structured !== void 0);
      bound.values[i] = prepared.value;
      if (structured)
        bound.text = variant(bound.text, structured, type.fields, prepared.present);
      return;
    }
    if (input?.nullable === false && bound.values[i] === null && refusesNull(query, type))
      refuseNull(name, params[name]);
    if (type?.kind === "array" && Array.isArray(bound.values[i])) {
      const at = nullElement(bound.values[i]);
      if (at !== void 0)
        throw new ParameterError(`Parameter "${name}" is an array whose elements may not be null, and the element at ${at} is. Leave it out of the array.`);
    }
    const cast = query.inputs?.[name]?.cast;
    if (cast !== void 0 && type !== void 0)
      checksFor(query, name).checkCast(name, cast, type, bound.values[i], query.dialect);
    checkTime(type, name, bound.values[i]);
    checkBinary(type, name, bound.values[i]);
    bound.values[i] = encode(type, bound.values[i], query.dialect, name);
  });
  if (query.dialect !== "postgres")
    bound.values = bound.values.map((v, i) => isJsonValue(query, bound.names[i], v) && query.inputs?.[bound.names[i]]?.type.kind !== "rows" ? JSON.stringify(v) : v);
  return bound;
}
function checksFor(query, name) {
  if (query.checks)
    return query.checks;
  throw new ParameterError(`Parameter "${name}" is a typed JSON, structured or cast parameter, which the run time checks with Reylo's checks; a query defined by hand passes them: defineQuery({ \u2026, checks }) with checks from "reylo".`);
}
function nullElement(array, path = "") {
  for (let i = 0; i < array.length; i++) {
    const e = array[i];
    if (e == null)
      return `${path}[${i}]`;
    if (Array.isArray(e)) {
      const inner = nullElement(e, `${path}[${i}]`);
      if (inner !== void 0)
        return inner;
    }
  }
  return void 0;
}
function refusesNull(query, type) {
  if (type === void 0 || type.kind === "unknown")
    return false;
  if (type.kind !== "json")
    return true;
  return type.schema !== void 0 && query.checks !== void 0 && query.checks.validate(type.schema, null) !== void 0;
}
function refuseNull(name, v) {
  throw new ParameterError(`Parameter "${name}" ${v === void 0 ? "is missing" : "is null"}, and the statement takes no null for it: pass a value.`);
}
function value(params, name) {
  const v = params[name];
  return v === void 0 ? null : v;
}
function asBuffer(v) {
  const NodeBuffer = globalThis.Buffer;
  return v instanceof Uint8Array && NodeBuffer !== void 0 && !NodeBuffer.isBuffer(v) ? NodeBuffer.from(v.buffer, v.byteOffset, v.byteLength) : v;
}
const isJson = (kind) => kind === "json" || kind === "object" || kind === "list" || kind === "rows";
function isJsonValue(query, name, v) {
  return v != null && isJson(query.inputs?.[name]?.type.kind);
}
const isTime = (type) => type?.kind === "scalar" && type.name.split("|").every((part) => part === "timestamp" || part === "timestamptz" || part === "date");
function checkTime(type, name, v) {
  if (type === void 0 || v == null)
    return;
  if (type.kind === "array") {
    if (Array.isArray(v))
      for (const e of v)
        checkTime(Array.isArray(e) ? type : type.of, name, e);
    return;
  }
  if (type.kind !== "scalar")
    return;
  if (type.name === "timestamptz") {
    if (v instanceof Date) {
      throw new ParameterError(`Parameter "${name}" is a timestamptz, which takes the instant as a string that names its zone, as \`.run()\` returns one, not a Date: pass date.toISOString() ("2026-10-12T19:06:48.282Z").`);
    }
    if (typeof v === "string" && !zoned.test(v.trim())) {
      throw new ParameterError(`Parameter "${name}" is a timestamptz, an instant, so a string for it names its zone ("2026-10-12T19:06:48.282Z", "2026-10-12 19:06:48+09", "2026-10-12 19:06:48 America/Los_Angeles"); got ${JSON.stringify(v)}, which the server would read in the session's time zone.`);
    }
  } else if (v instanceof Date && type.name.split("|").every((part) => part === "timestamp" || part === "date")) {
    throw new ParameterError(`Parameter "${name}" is a ${type.name === "date" ? "date" : "timestamp"} without a time zone, so it takes the wall-clock text ("2026-10-12 19:06:48.282", "2026-10-12"), not a Date: drivers write a Date's time in different zones (the app's, the server's or UTC).`);
  }
}
function checkBinary(type, name, v) {
  if (type === void 0 || v == null)
    return;
  if (type.kind === "array") {
    if (Array.isArray(v))
      for (const e of v)
        checkBinary(Array.isArray(e) ? type : type.of, name, e);
    return;
  }
  if (type.kind !== "scalar" || type.name !== "bytea" && type.name !== "blob" || v instanceof Uint8Array)
    return;
  throw new ParameterError(`Parameter "${name}" is binary data, so it takes a Uint8Array (a Buffer is one), as \`.run()\` returns one; got ${describe(v)}. ${v instanceof ArrayBuffer ? "Wrap an ArrayBuffer in one: new Uint8Array(buffer)." : "Decode base64 or hex text into one first."}`);
}
function encode(type, v, dialect, name) {
  if (type === void 0 || v == null)
    return v;
  if (dialect === "sqlite")
    return typeof v === "boolean" ? v ? 1 : 0 : v;
  if (dialect === "mysql")
    return type.kind === "array" && Array.isArray(v) ? vectorText(v, name, "a VECTOR") : v;
  if (type.kind === "array")
    return Array.isArray(v) ? v.map((e) => encode(Array.isArray(e) && !isVector(type.of) ? type : type.of, e, dialect, name)) : v;
  if (isVector(type) && Array.isArray(v)) {
    if (!v.length)
      throw new ParameterError(`Parameter "${name}" is a pgvector ${type.name}, which has one dimension at least; got an empty array.`);
    return vectorText(v, name, `a pgvector ${type.name}`);
  }
  if (type.kind === "scalar" && type.name === "hstore" && typeof v === "object")
    return hstoreText(v, (message) => {
      throw new ParameterError(`Parameter "${name}" ${message}`);
    });
  if (typeof v !== "string")
    return v;
  if (isTime(type))
    return postgresYear(v);
  return type.kind === "scalar" && type.name === "interval" ? postgresInterval(v) : v;
}
const isVector = (type) => type.kind === "scalar" && (type.name === "vector" || type.name === "halfvec");
function vectorText(v, name, what) {
  v.forEach((e, i) => {
    if (typeof e !== "number" || !Number.isFinite(e)) {
      throw new ParameterError(`Parameter "${name}" is ${what}, an array of finite numbers, and the element at [${i}] is ${typeof e === "string" ? JSON.stringify(e) : typeof e === "number" ? e : typeof e}.`);
    }
  });
  return JSON.stringify(v);
}
function numberOrDigits(v, type, driver) {
  if (typeof v !== "bigint")
    return v;
  if (v >= BigInt(Number.MIN_SAFE_INTEGER) && v <= BigInt(Number.MAX_SAFE_INTEGER))
    return Number(v);
  if (type?.kind === "scalar" && type.name === "int8")
    return String(v);
  const digits = "pass it as a string of digits, which SQLite stores as that integer in an INTEGER column";
  if (driver === "durable-object")
    throw new ParameterError(`A Durable Object's SQL storage binds no BigInt, and ${v} is past 2^53 - 1, where a number stops being exact: ${digits}.`);
  throw new ParameterError(`sqlite3 binds a BigInt as NULL, and ${v} is past 2^53 - 1, where a number stops being exact: ${digits}, or run the statement on better-sqlite3, node:sqlite or libSQL, which bind a BigInt.`);
}
function asByteaHex(v) {
  if (!(v instanceof Uint8Array))
    return v;
  let hex = "\\x";
  for (const byte of v)
    hex += (byte < 16 ? "0" : "") + byte.toString(16);
  return hex;
}
export function arrayLiteral(array, delim = ",") {
  let out = "{";
  for (let i = 0; i < array.length; i++) {
    const v = array[i];
    if (i)
      out += delim;
    if (v == null)
      out += "NULL";
    else if (Array.isArray(v))
      out += arrayLiteral(v, delim);
    else if (ArrayBuffer.isView(v))
      out += "\\" + asByteaHex(new Uint8Array(v.buffer, v.byteOffset, v.byteLength));
    else
      out += `"${(v instanceof Date ? dateText(v) : typeof v === "object" ? JSON.stringify(v) : String(v)).replace(/[\\"]/g, "\\$&")}"`;
  }
  return out + "}";
}
function dateText(d) {
  const pad = (n, width = 2) => String(n).padStart(width, "0");
  const year = d.getFullYear();
  const offset = -d.getTimezoneOffset();
  const abs = Math.abs(offset);
  return `${pad(year < 1 ? 1 - year : year, 4)}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}${offset < 0 ? "-" : "+"}${pad(Math.floor(abs / 60))}:${pad(abs % 60)}${year < 1 ? " BC" : ""}`;
}
export function compile(query) {
  if (query.text && query.order)
    return { text: query.text, order: query.order };
  const { placeholders } = lexPlaceholders(query.sql, query.dialect);
  const postgres = query.dialect === "postgres";
  let text = "";
  let last = 0;
  const order = [];
  for (const p of placeholders) {
    const index = indexOf(query, p);
    text += query.sql.slice(last, p.start) + (postgres ? `$${index + 1}` : "?");
    order.push(p.name);
    last = p.end;
  }
  return { text: text + query.sql.slice(last), order: postgres ? query.params : order };
}
function indexOf(query, p) {
  const index = query.params.indexOf(p.name);
  if (index === -1)
    throw new Error(`The statement's placeholder ${query.sql.slice(p.start, p.end)} is parameter "${p.name}", which the query's params (${JSON.stringify(query.params)}) do not list.`);
  return index;
}
const accepted = {
  postgres: "query(text, values) as on pg, PGlite, Neon and pg-promise; unsafe(text, values) as on postgres.js and Bun.sql; Neon's neon() function; a Slonik pool, connection or transaction; or a Drizzle database over one of them",
  mysql: "execute(text, values) as on mysql2 and PlanetScale; query(text, values) as on mariadb's pool or connection, from its promise or callback API; unsafe(text, values) as on Bun.sql; a mysql2 callback pool or connection; or a Drizzle database over one of them",
  sqlite: "prepare(sql) as on better-sqlite3, node:sqlite, bun:sqlite, Turso's @tursodatabase/database and Cloudflare D1; exec(sql, ...values) as on a Durable Object's ctx.storage.sql; execute({ sql, args }) as on @libsql/client; all(sql, params) as on sqlite3 and sqlite; unsafe(text, values) as on Bun.sql; or a Drizzle database over one of them"
};
function unsupported(c, dialect) {
  let seen;
  if (c === null || typeof c !== "object" && typeof c !== "function")
    seen = String(c);
  else {
    const names = /* @__PURE__ */ new Set();
    for (let o2 = c; o2 && o2 !== Object.prototype && o2 !== Function.prototype; o2 = Object.getPrototypeOf(o2)) {
      for (const key of Object.getOwnPropertyNames(o2)) {
        const d = Object.getOwnPropertyDescriptor(o2, key);
        if (key !== "constructor" && typeof d?.value === "function")
          names.add(key);
      }
    }
    seen = names.size ? `an object with ${[...names].slice(0, 12).join(", ")}${names.size > 12 ? ", ..." : ""}` : "an object with no methods";
  }
  const o = c;
  const inTx = " and does not hand out its transaction's connection: take the transaction from the driver's client instead.";
  const hint = typeof o?.db?.prepare === "function" ? " A tag store is not a client: pass its database, store.db." : typeof o?.selectFrom === "function" && typeof o.executeQuery === "function" ? ` Kysely decodes the values of its queries itself${o.isTransaction === true ? inTx : ": pass the pool or database its dialect was made with."}` : typeof o?.$queryRawUnsafe === "function" ? ` Prisma decodes the values of its queries itself${typeof o.$transaction !== "function" ? inTx : ": pass a client of your database's driver, such as the pool its driver adapter was made with."}` : "";
  return new TypeError(`reylo cannot run a ${dialect} statement on ${seen}. It takes a client with ${accepted[dialect]}.${hint}`);
}
