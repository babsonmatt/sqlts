import type { Dialect } from "./execute.ts";
import type { POSTGRES_CODES } from "./error-codes-postgres.ts";
import type { MYSQL_CODES } from "./error-codes-mysql.ts";
import { SQLITE_CODES } from "./error-codes-sqlite.ts";
/** A SQLSTATE Postgres defines, as `"23505"`. */
export type PostgresCode = keyof typeof POSTGRES_CODES;
/** The condition name of a SQLSTATE Postgres defines, as `"unique_violation"`. */
export type PostgresCondition = (typeof POSTGRES_CODES)[PostgresCode];
/** The name of an error MySQL sends a client, as `"ER_DUP_ENTRY"`. */
export type MysqlCode = (typeof MYSQL_CODES)[number][1][number];
/** The name of a SQLite result code of an error, primary or extended, as `"SQLITE_CONSTRAINT_UNIQUE"`. */
export type SqliteCode = keyof typeof SQLITE_CODES;
/** What an error Postgres raised holds beside its code. */
interface PostgresErrorFields extends Error {
    readonly name: "QueryError";
    /** `ERROR`, `FATAL` (the session ended) or `PANIC` (the server stopped), in the server's language with pg. */
    readonly severity: string;
    /** The server's message, as `duplicate key value violates unique constraint "users_email_key"`. */
    readonly message: string;
    readonly detail: string | undefined;
    readonly hint: string | undefined;
    /** Where in the statement the error is: a character's place, from 1. */
    readonly position: number | undefined;
    /** The functions the error was raised in, innermost first. */
    readonly where: string | undefined;
    readonly schema: string | undefined;
    readonly table: string | undefined;
    readonly column: string | undefined;
    readonly dataType: string | undefined;
    readonly constraint: string | undefined;
    /** The driver's own error. */
    readonly cause: unknown;
}
/**
 * The names each field of an error may hold, by the error's code: what a statement that runs only
 * the server's own code writes through (its constraints, tables, columns and domains).
 */
export type PostgresNarrowing = {
    readonly [C in PostgresCode]?: {
        readonly constraint?: string;
        readonly table?: string;
        readonly column?: string;
        readonly dataType?: string;
    };
};
/** An error of one of the codes `C`, with the names `F` narrows its fields to. */
type PostgresMember<C extends PostgresCode, F> = Omit<PostgresErrorFields, keyof F> & {
    /** The SQLSTATE, as `"23505"`. */
    readonly code: C;
    /** The code's condition name, as `"unique_violation"`. */
    readonly condition: (typeof POSTGRES_CODES)[C];
} & {
    readonly [K in keyof F]: F[K] | undefined;
};
/**
 * An error Postgres raised. A statement that may run a user's code (a trigger, a function) may raise
 * any code: `code` is any string, and `condition` the strict union, undefined for a code Postgres
 * does not define. Where a statement runs only the server's own code, its module narrows the type
 * with `N`: a code Postgres defines, and for each code `N` lists, the names its fields may hold.
 */
export type PostgresQueryError<N extends PostgresNarrowing | undefined = undefined> = [N] extends [PostgresNarrowing] ? {
    [C in keyof N & PostgresCode]: PostgresMember<C, N[C]>;
}[keyof N & PostgresCode] | PostgresMember<Exclude<PostgresCode, keyof N>, {}> : PostgresErrorFields & {
    /**
     * The SQLSTATE, as `"23505"`: one Postgres defines, or one a function raised itself
     * (`raise ... using errcode`), which no list holds.
     */
    readonly code: PostgresCode | (string & {});
    /** The code's condition name, as `"unique_violation"`; undefined for a code Postgres does not define. */
    readonly condition: PostgresCondition | undefined;
};
/** What an error MySQL raised holds beside its code. */
interface MysqlErrorFields extends Error {
    readonly name: "QueryError";
    /** The error's number, as `1062`. */
    readonly errno: number;
    /** The SQLSTATE, as `"23000"`. */
    readonly sqlState: string;
    /** The server's message, as `Duplicate entry 'ada@example.com' for key 'users.email'`. */
    readonly message: string;
    /** The key a duplicate entry is for, as the message names it: `users.email`, its table and its name. */
    readonly key: string | undefined;
    /** The foreign key or check constraint the row fails. */
    readonly constraint: string | undefined;
    /** The table of the foreign key a row fails. */
    readonly table: string | undefined;
    /** The column a value does not fit, or a null or a missing value is refused for. */
    readonly column: string | undefined;
    /** The driver's own error. */
    readonly cause: unknown;
}
/** The names each field of an error may hold, by the error's name: what a statement that runs no trigger and no stored function writes through. */
export type MysqlNarrowing = {
    readonly [C in MysqlCode]?: {
        readonly key?: string;
        readonly constraint?: string;
        readonly table?: string;
        readonly column?: string;
    };
};
/** An error of one of the names `C`, with the names `F` narrows its fields to. */
type MysqlMember<C extends MysqlCode | undefined, F> = Omit<MysqlErrorFields, keyof F> & {
    /** The error's name, as `"ER_DUP_ENTRY"`; undefined for a number MySQL does not define. */
    readonly code: C;
} & {
    readonly [K in keyof F]: F[K] | undefined;
};
/**
 * An error MySQL raised: its name from MySQL's own list, undefined for a number the list lacks, as
 * one a `signal` statement sets. Where a statement runs no trigger and no stored function, its
 * module narrows the type with `N`: for each name `N` lists, the names its fields may hold.
 */
export type MysqlQueryError<N extends MysqlNarrowing | undefined = undefined> = [N] extends [MysqlNarrowing] ? {
    [C in keyof N & MysqlCode]: MysqlMember<C, N[C]>;
}[keyof N & MysqlCode] | MysqlMember<Exclude<MysqlCode, keyof N> | undefined, {}> : MysqlMember<MysqlCode | undefined, {}>;
/** What an error SQLite raised holds beside its code. */
interface SqliteErrorFields extends Error {
    readonly name: "QueryError";
    /** The result code's number, as `2067`. */
    readonly errcode: number | undefined;
    /** SQLite's message, as `UNIQUE constraint failed: users.email`. */
    readonly message: string;
    /** The table of the columns a unique, not-null or type constraint fails on. */
    readonly table: string | undefined;
    /** The columns a unique, not-null or type constraint fails on. */
    readonly columns: readonly string[] | undefined;
    /** The check constraint the row fails (its expression, where it has no name), or the index of an expression a unique row fails. */
    readonly constraint: string | undefined;
    /** The driver's own error. */
    readonly cause: unknown;
}
/** The names each field of an error may hold, by the result code's name: what a statement that fires no trigger writes through. */
export type SqliteNarrowing = {
    readonly [C in SqliteCode]?: {
        readonly table?: string;
        readonly columns?: readonly string[];
        readonly constraint?: string;
    };
};
/** An error of one of the codes `C`, with the names `F` narrows its fields to. */
type SqliteMember<C extends SqliteCode | undefined, F> = Omit<SqliteErrorFields, keyof F> & {
    /**
     * The result code's name: the extended code, as `"SQLITE_CONSTRAINT_UNIQUE"`, where the driver
     * gives it; the primary code, as `"SQLITE_CONSTRAINT"`, from sqlite3 and the sqlite package,
     * which give only that; undefined where the driver gives none, as Turso's engine.
     */
    readonly code: C;
} & {
    readonly [K in keyof F]: F[K] | undefined;
};
/**
 * An error SQLite raised. Where a statement fires no trigger, its module narrows the type with
 * `N`: for each code `N` lists, the names its fields may hold.
 */
export type SqliteQueryError<N extends SqliteNarrowing | undefined = undefined> = [N] extends [SqliteNarrowing] ? {
    [C in keyof N & SqliteCode]: SqliteMember<C, N[C]>;
}[keyof N & SqliteCode] | SqliteMember<Exclude<SqliteCode, keyof N> | undefined, {}> : SqliteMember<SqliteCode | undefined, {}>;
/** The error a database of the dialect raised. */
export type QueryError<D extends Dialect = Dialect> = D extends "postgres" ? PostgresQueryError : D extends "mysql" ? MysqlQueryError : SqliteQueryError;
/** The database's error `error` is, or undefined where it is another. */
export declare function readQueryError(dialect: Dialect, error: unknown): Promise<QueryError | undefined>;
/** `readQueryError` for the synchronous SQLite clients, whose list is no import away. */
export declare function readQueryErrorSync(dialect: Dialect, error: unknown): QueryError | undefined;
export {};
