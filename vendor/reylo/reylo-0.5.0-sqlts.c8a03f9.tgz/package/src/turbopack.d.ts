export { default } from "./webpack.ts";
