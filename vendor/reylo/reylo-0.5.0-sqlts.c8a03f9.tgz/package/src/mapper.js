import { tooling } from "./engine-package.js";
import { serve } from "./rpc.js";
const NO_ENGINE_TEXT = `import type { Query } from "reylo";
export type Params = unknown;
export type Row = unknown;
export type QueryError = import("reylo").QueryError;
declare const query: Query<unknown, unknown, "many", "postgres">;
export default query;
`;
let real;
let message = "";
const opened = /* @__PURE__ */ new Map();
async function engine() {
  if (real)
    return real;
  try {
    const handlers = (await tooling()).mapperHandlers();
    for (const params of opened.values())
      await handlers.openProject(params);
    return real = handlers;
  } catch (e) {
    message = e.message;
    return void 0;
  }
}
const handle = (method, fallback) => async (params) => {
  const handlers = await engine();
  return handlers ? handlers[method](params) : fallback(params);
};
serve({
  initialize: handle("initialize", (params) => ({ protocolVersion: params?.protocolVersion ?? 1, positionEncoding: "utf-8", diagnosticSource: "reylo" })),
  openProject: handle("openProject", (params) => {
    const p = params;
    opened.set(p.projectHandle, params);
    return { configIdentity: message, watchedFiles: [], optionDiagnostics: [] };
  }),
  transform: handle("transform", (params) => {
    const p = params;
    if (p.fileName.endsWith(".reylo.yaml") || p.fileName.endsWith(".reylo.yml"))
      return { extension: ".ts", diagnostics: [], text: "export {};\n", mappings: [] };
    return { extension: ".ts", diagnostics: [{ messageText: message, start: 0, length: Math.min(1, Buffer.byteLength(p.content)), code: 11 }], text: NO_ENGINE_TEXT, mappings: [] };
  }),
  closeProject: handle("closeProject", (params) => {
    opened.delete(params.projectHandle);
    return {};
  })
});
