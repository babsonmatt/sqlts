export type Placeholder = {
    name: string;
    start: number;
    end: number;
};
export declare function lexPlaceholders(sql: string, dialect: "postgres" | "mysql" | "sqlite"): {
    params: string[];
    placeholders: Placeholder[];
};
/** Whether a parameter name is a position: a number, where a name starts with a letter or `_`. */
export declare function isPositional(name: string): boolean;
