export function lexPlaceholders(sql, dialect) {
  const placeholders = [];
  const params = [];
  let largest = 0;
  let i = 0;
  const push = (name, start, end) => {
    placeholders.push({ name, start, end });
    if (!params.includes(name))
      params.push(name);
  };
  const position = (digits) => {
    const n = digits.replace(/^0+(?=\d)/, "");
    largest = Math.max(largest, Number(n));
    return n;
  };
  const mysql = dialect === "mysql";
  while (i < sql.length) {
    const ch = sql[i];
    const next = sql[i + 1];
    if (ch === "'" || ch === '"') {
      i = skipQuoted(sql, i, ch, mysql);
      continue;
    }
    if (ch === "`") {
      i = skipQuoted(sql, i, ch, false);
      continue;
    }
    const comment = ch === "#" ? mysql : ch === "-" && next === "-" && !(mysql && i + 2 < sql.length && sql.charCodeAt(i + 2) > 32 && sql.charCodeAt(i + 2) !== 127);
    if (comment) {
      i = sql.indexOf("\n", i);
      if (i === -1)
        break;
      continue;
    }
    if (ch === "/" && next === "*") {
      const end = sql.indexOf("*/", i + 2);
      i = end === -1 ? sql.length : end + 2;
      continue;
    }
    if (ch === ":" && next === ":") {
      i += 2;
      continue;
    }
    if ((ch === ":" || dialect === "sqlite" && (ch === "@" || ch === "$")) && next !== void 0 && /[A-Za-z_]/.test(next) && !(i > 0 && /[A-Za-z0-9_]/.test(sql[i - 1]))) {
      const m = /^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*/.exec(sql.slice(i + 1));
      push(m[0], i, i + 1 + m[0].length);
      i += 1 + m[0].length;
      continue;
    }
    if (ch === "$" && dialect === "postgres" && next !== void 0 && /[0-9]/.test(next)) {
      const m = /^[0-9]+/.exec(sql.slice(i + 1));
      push(position(m[0]), i, i + 1 + m[0].length);
      i += 1 + m[0].length;
      continue;
    }
    if (ch === "?" && dialect === "sqlite" && next !== void 0 && /[0-9]/.test(next)) {
      const m = /^[0-9]+/.exec(sql.slice(i + 1));
      push(position(m[0]), i, i + 1 + m[0].length);
      i += 1 + m[0].length;
      continue;
    }
    if (ch === "?" && dialect !== "postgres") {
      largest += 1;
      push(String(largest), i, i + 1);
      i += 1;
      continue;
    }
    i += 1;
  }
  if (params.length && params.every(isPositional))
    params.sort((a, b) => Number(a) - Number(b));
  return { params, placeholders };
}
export function isPositional(name) {
  return /^\d+$/.test(name);
}
function skipQuoted(sql, start, quote, escapes) {
  let i = start + 1;
  while (i < sql.length) {
    if (escapes && sql[i] === "\\") {
      i += 2;
      continue;
    }
    if (sql[i] === quote) {
      if (sql[i + 1] === quote) {
        i += 2;
        continue;
      }
      return i + 1;
    }
    i += 1;
  }
  return i;
}
