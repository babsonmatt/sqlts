import type { EngineType } from "./engine-type.ts";
export type Dialect = "postgres" | "mysql" | "sqlite";
/** A scalar value's representation. */
export type ScalarKind = "bool" | "int" | "float" | "int8" | "decimal" | "text" | "date" | "timestamp" | "timestamptz" | "interval" | "json" | "bytes" | "vector" | "hstore" | "unknown";
/** A column's kind as a module carries it: a scalar kind, `k[]` for an array of `k`, `a|b` for either. */
export type Kind = string;
/** The output columns a module carries, in the statement's order; an array's `delimiter` where it is not a comma. */
export type Columns = readonly (readonly [name: string, kind: Kind, delimiter?: string])[];
/** The TypeScript type of each scalar kind: what a value of that kind is at run time. */
export declare const TS_TYPE: Readonly<Record<ScalarKind, string>>;
/**
 * The kind of a base type by its engine name, `a|b` naming either. An integer that may be a BIGINT
 * or a narrower integer (a MySQL expression a temporary table may widen, `int8|int4`) is a BIGINT's,
 * a BigInt either way, where no float shares the column: there a number may be either.
 */
export declare function scalarKind(name: string, dialect: Dialect): Kind;
/** The delimiter of an array's text, where the element type's is not a comma: a column carries it beside its kind. */
export declare function arrayDelimiter(t: EngineType): string | undefined;
/** The kind of a value of the engine's type `t`, standing in a result row (not inside a JSON document). */
export declare function columnKind(t: EngineType, dialect: Dialect): Kind;
/** The TypeScript type of a scalar kind, `a|b` as the union of both; `unknown` where any part is. */
export declare function kindType(kind: Kind): string;
export type Decoder = (text: string) => unknown;
/**
 * A date or time parameter's text as Postgres reads it, the inverse of `isoYear` for what `run`
 * returns (the round-trip rule): Postgres 18 refuses an ISO 8601 extended year (`+010000-01-01`,
 * "time zone displacement out of range") and the year 0000 ("date/time field value out of range"),
 * and reads `10000-01-01` and a year before 1 as its own ` BC` form, year 1 − n, so `-000001` is
 * `0002 … BC` and `0000` or `+000000` is `0001 … BC`. Any other text is left as it is.
 */
export declare function postgresYear(text: string): string;
/**
 * A timestamptz's text as the instant's ISO 8601 text in UTC: `2026-10-20 10:00:00.123456+02` is
 * `2026-10-20T08:00:00.123456Z`, the fraction as the server wrote it (trailing zeros dropped, none
 * for a whole second), which `Temporal.Instant.from` reads. `infinity` and `-infinity` stay those
 * words.
 */
export declare function instant(x: string): string;
/**
 * The instant a driver already decoded to a Date (Bun.sql's timestamptz), as the same text: to the
 * millisecond, which is all a Date holds, with its fraction's trailing zeros dropped as the server
 * drops them, so that a value the driver did not cut reads alike on every driver.
 */
export declare function instantOfDate(d: Date, column: string): string;
/**
 * An interval's text as an ISO 8601 duration, which `Temporal.Duration.from` reads: `1 year 2 mons
 * 3 days 04:05:06.789` is `P1Y2M3DT4H5M6.789S` and zero is `PT0S`, as Postgres writes them in
 * IntervalStyle iso_8601, and a negative interval has one sign in front, `-1 days` being `-P1D`
 * (Postgres writes `P-1D`, which ISO 8601 and Temporal refuse). An interval whose parts differ in
 * sign has no ISO 8601 form, so it keeps Postgres's, each part signed on its own: `1 mon -1 days`
 * is `P1M-1D`, which Postgres reads back and Temporal refuses. `infinity` and `-infinity` stay
 * those words.
 */
export declare function duration(x: string): string;
/**
 * An interval parameter's text as Postgres reads it, the inverse of `duration` for a negative
 * interval (the round-trip rule): Postgres refuses a sign before the `P` (`-P1DT2H`, as `.run()`
 * returns it and Temporal writes it), and reads each part signed instead (`P-1DT-2H`). Any other
 * text is left as it is.
 */
export declare function postgresInterval(text: string): string;
/** UTF-8 bytes as text: a Buffer's own toString where the bytes are one. */
export declare function utf8(bytes: Uint8Array): string;
/** bytea's text: hex (`\x0102ff`, the server's default) or the escape format (`bytea_output = escape`). */
export declare function bytea(x: string): Uint8Array;
/**
 * An hstore's text as an object of its keys: `"a"=>"1", "b c"=>NULL` is `{ a: "1", "b c": null }`.
 * The server quotes every key and value, escapes `"` and `\` with a backslash, writes a null value
 * as a bare NULL and separates the pairs with `, `. A key such as `__proto__` is a key like any other.
 */
export declare function hstore(x: string): Record<string, string | null>;
/**
 * An hstore, as `.run()` returns it, in the text its input reads: each key and value quoted, `"`
 * and `\` escaped, a null value a bare NULL. A key whose value is undefined is left out, as JSON
 * leaves it out.
 */
export declare function hstoreText(v: object, fail: (message: string) => never): string;
/**
 * Postgres's array output: `{a,"b,c",NULL,{d}}`, optionally after its bounds (`[0:1]={...}`).
 * An element is quoted when it holds the delimiter, a brace, a quote, a backslash or white space,
 * or is empty or the word NULL; inside quotes a backslash escapes the next character.
 */
export declare function parseArray(text: string, element: (text: string) => unknown, delim?: string): unknown[];
/** The decoder of a Postgres value of `kind` from its text; `delim` is an array's (`;` for `box[]`). */
export declare function textDecoder(kind: Kind, delim?: string): Decoder;
/** Why a value cannot be given its kind: Reylo's error, naming the column. */
export declare class DecodeError extends TypeError {
}
/** Why a parameter's value cannot be bound: Reylo's error, naming the parameter. */
export declare class ParameterError extends TypeError {
}
/**
 * A string for a `timestamptz` names its zone: without one the server reads it in the session's
 * TimeZone, which the driver or the server sets.
 */
export declare const zoned: RegExp;
/** A value as a message about a parameter names it: its kind, or a short form of itself. */
export declare function describe(v: unknown): string;
/** An integer as a number, refused where a number cannot hold it exactly. */
export declare function exactInteger(v: number | bigint, column: string): number;
/**
 * A 64-bit integer as a BigInt, from the driver's BigInt, its digits, or a number: a number past
 * ±(2^53 - 1) is one the driver already rounded, which no BigInt makes exact again, so it is
 * refused. Anything else (a SQLite REAL a column of INTEGER affinity kept) is left as it is.
 */
export declare function bigInteger(v: number | bigint | string, column: string): unknown;
/**
 * A truth value as a boolean: true, false, 1, 0, `1n`, `0n`, `t`, `f`, `true`, `false`, `1`, `0`,
 * and a BIT(1)'s one byte. MySQL and SQLite have no boolean type and store one as an integer (a
 * TINYINT(1), a BIT(1), a column SQLite declares BOOLEAN), which neither database holds to 0 and 1:
 * any other value is refused, naming the column, rather than read as true.
 */
export declare function truth(v: unknown, column: string): boolean;
/** The error for a value of a boolean column that is not 0 or 1, `shown` as the message names it. */
export declare function refuseTruth(column: string, shown: string): never;
/**
 * A MySQL VECTOR's floats from its bytes, 32-bit and little-endian, which mariadb and PlanetScale
 * hand over as they are (mysql2 decodes them itself).
 */
export declare function float32s(bytes: Uint8Array, column: string): number[];
/**
 * `v` as a value of `kind`, from the form a driver decoded it to; `column` names it in an error. A
 * number past ±(2^53 - 1) in an integer column is one the driver already rounded, and is refused.
 * `delim` is an array's, where its text is what the driver gave.
 */
export declare function coerce(kind: Kind, v: unknown, column: string, delim?: string): unknown;
