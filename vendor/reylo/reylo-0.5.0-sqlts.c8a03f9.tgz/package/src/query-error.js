import { SQLITE_CODES } from "./error-codes-sqlite.js";
class DatabaseError extends Error {
  constructor(message, cause, fields) {
    super(message, { cause });
    Object.assign(this, fields);
  }
}
Object.defineProperty(DatabaseError.prototype, "name", { value: "QueryError", writable: true, configurable: true });
const SQLSTATE = /^[0-9A-Z]{5}$/;
const text = (v) => typeof v === "string" && v !== "" ? v : void 0;
const record = (e) => typeof e === "object" && e !== null ? e : void 0;
export async function readQueryError(dialect, error) {
  if (dialect === "sqlite")
    return readQueryErrorSync(dialect, error);
  if (dialect === "postgres") {
    const read2 = postgresError(error) ?? postgresError(record(error)?.cause);
    if (!read2)
      return void 0;
    const { POSTGRES_CODES } = await import("./error-codes-postgres.js");
    return new DatabaseError(read2.message, error, { code: read2.code, condition: POSTGRES_CODES[read2.code], ...read2.fields });
  }
  const read = mysqlError(error);
  if (!read)
    return void 0;
  const { MYSQL_CODES } = await import("./error-codes-mysql.js");
  let code;
  for (const [first, names] of MYSQL_CODES)
    if (read.errno >= first && read.errno < first + names.length)
      code = names[read.errno - first];
  return new DatabaseError(read.message, error, { code, errno: read.errno, sqlState: read.sqlState, ...mysqlNames(read.errno, read.message) });
}
export function readQueryErrorSync(dialect, error) {
  if (dialect !== "sqlite")
    return void 0;
  const read = sqliteError(error);
  if (!read)
    return void 0;
  return new DatabaseError(read.message, error, { code: read.code, errcode: read.errcode, ...sqliteNames(read.errcode, read.message) });
}
function postgresError(error) {
  const e = record(error);
  if (!e || typeof e.severity !== "string" || typeof e.message !== "string")
    return void 0;
  const code = typeof e.code === "string" && SQLSTATE.test(e.code) ? e.code : typeof e.errno === "string" && SQLSTATE.test(e.errno) ? e.errno : void 0;
  if (code === void 0)
    return void 0;
  const position = text(e.position);
  return {
    code,
    message: e.message,
    fields: {
      severity: e.severity,
      detail: text(e.detail),
      hint: text(e.hint),
      position: position !== void 0 && /^\d+$/.test(position) ? Number(position) : void 0,
      where: text(e.where),
      schema: text(e.schema ?? e.schema_name),
      table: text(e.table ?? e.table_name),
      column: text(e.column ?? e.column_name),
      dataType: text(e.dataType ?? e["data type_name"]),
      constraint: text(e.constraint ?? e.constraint_name)
    }
  };
}
function mysqlError(error) {
  const e = record(error);
  if (!e || typeof e.message !== "string")
    return void 0;
  let { errno, sqlState } = e;
  let message = text(e.sqlMessage) ?? text(e.text) ?? e.message;
  if (errno === void 0) {
    const m = /^(?:[\s\S]*?desc = )?([\s\S]*?) \(errno (\d+)\) \(sqlstate ([0-9A-Z]{5})\)/.exec(e.message);
    if (!m)
      return void 0;
    [message, errno, sqlState] = [m[1], Number(m[2]), m[3]];
  }
  if (typeof errno !== "number" || !Number.isInteger(errno) || errno <= 0 || typeof sqlState !== "string" || !SQLSTATE.test(sqlState))
    return void 0;
  if (errno > 45e3 && errno < 46e3 && /^\(conn[:=]/.test(e.message))
    return void 0;
  return { errno, sqlState, message };
}
function mysqlNames(errno, message) {
  const names = {};
  let m;
  switch (errno) {
    case 1062:
    // ER_DUP_ENTRY
    case 1586:
      if (m = /^Duplicate entry '[\s\S]*' for key '([\s\S]*)'$/.exec(message))
        names.key = m[1];
      break;
    case 1451:
    // ER_ROW_IS_REFERENCED_2
    case 1452:
      if (m = /a foreign key constraint fails \(`(?:[^`]|``)*`\.`((?:[^`]|``)*)`, CONSTRAINT `((?:[^`]|``)*)`/.exec(message)) {
        names.table = m[1].replaceAll("``", "`");
        names.constraint = m[2].replaceAll("``", "`");
      }
      break;
    case 3819:
      if (m = /^Check constraint '([\s\S]*)' is violated\.$/.exec(message))
        names.constraint = m[1];
      break;
    case 1048:
      if (m = /^Column '([\s\S]*)' cannot be null$/.exec(message))
        names.column = m[1];
      break;
    case 1364:
      if (m = /^Field '([\s\S]*)' doesn't have a default value$/.exec(message))
        names.column = m[1];
      break;
    case 1264:
    // ER_WARN_DATA_OUT_OF_RANGE
    case 1265:
    // WARN_DATA_TRUNCATED
    case 1292:
    // ER_TRUNCATED_WRONG_VALUE
    case 1366:
    // ER_TRUNCATED_WRONG_VALUE_FOR_FIELD
    case 1406:
      if (m = / for column '([\s\S]*)' at row \d+$/.exec(message))
        names.column = m[1];
      break;
  }
  return { key: names.key, constraint: names.constraint, table: names.table, column: names.column };
}
const SQLITE_NAMES = new Map(Object.entries(SQLITE_CODES).map(([name, code]) => [code, name]));
const SQLITE_NAME = /^SQLITE_[A-Z_]+$/;
function sqliteError(error) {
  const e = record(error);
  if (!e || typeof e.message !== "string")
    return void 0;
  let message = e.message;
  const codes = [];
  let named = false;
  const name = (v) => {
    if (typeof v !== "string" || !SQLITE_NAME.test(v))
      return;
    named = true;
    const code = SQLITE_CODES[v];
    if (code !== void 0)
      codes.push(code);
  };
  name(e.extendedCode);
  name(e.code);
  if (typeof e.errcode === "number" && e.code === "ERR_SQLITE_ERROR")
    codes.push(e.errcode);
  if (typeof e.rawCode === "number")
    codes.push(e.rawCode);
  if (typeof e.errno === "number" && named)
    codes.push(e.errno);
  if (named && typeof e.code === "string" && message.startsWith(`${e.code}: `))
    message = message.slice(e.code.length + 2);
  if (!named && !codes.length) {
    const tail = /^(?:D1_ERROR: )?([\s\S]*): (SQLITE_[A-Z_]+)(?: \(extended: (SQLITE_[A-Z_]+)\))?$/.exec(message);
    const turso = e.code === "GenericFailure" ? /^(?:prepare|step) failed: (?:Runtime error: )?([\s\S]*?)(?: \((\d+)\))?$/.exec(message) : null;
    if (tail) {
      message = tail[1];
      name(tail[3]);
      name(tail[2]);
    } else if (turso) {
      message = turso[1];
      if (turso[2])
        codes.push(Number(turso[2]));
    } else
      return void 0;
  }
  const errcode = codes.find((c) => c > 255) ?? codes[0];
  return { code: errcode === void 0 ? void 0 : SQLITE_NAMES.get(errcode), errcode, message };
}
function sqliteNames(errcode, message) {
  const names = {};
  let m;
  if (errcode !== void 0 && (errcode & 255) === SQLITE_CODES.SQLITE_CONSTRAINT) {
    if (m = /^UNIQUE constraint failed: index '([\s\S]*)'$/.exec(message))
      names.constraint = m[1];
    else if (m = /^(?:UNIQUE|NOT NULL) constraint failed: ([\s\S]+)$/.exec(message)) {
      const columns = m[1].split(", ").map((c) => /^([^.]+)\.([\s\S]+)$/.exec(c));
      const table = columns[0]?.[1];
      if (columns.every((c) => c && c[1] === table)) {
        names.table = table;
        names.columns = columns.map((c) => c[2]);
      }
    } else if (m = /^CHECK constraint failed: ([\s\S]*)$/.exec(message))
      names.constraint = m[1];
    else if (m = /^cannot store \S+ value in \S+ column ([^.]+)\.([\s\S]+)$/.exec(message)) {
      names.table = m[1];
      names.columns = [m[2]];
    }
  }
  return { table: names.table, columns: names.columns, constraint: names.constraint };
}
