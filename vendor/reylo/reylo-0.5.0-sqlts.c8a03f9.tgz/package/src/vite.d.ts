export default function reylo(): {
    name: string;
    enforce: "pre";
    resolveId: {
        order: "pre";
        handler(source: string, importer: string | undefined): string | null;
    };
    load(this: {
        addWatchFile(id: string): void;
    }, id: string): Promise<{
        code: string;
        map: null;
    } | null>;
    buildEnd(): Promise<void>;
};
