import type { EngineType } from "./engine-type.ts";
export { describe, zoned } from "./values.ts";
type Dialect = "postgres" | "mysql" | "sqlite";
export type RowsType = Extract<EngineType, {
    kind: "rows";
}>;
export type RowField = RowsType["fields"][number];
/** One comma-separated list of an insert's expansion, as UTF-16 offsets into the module's `text`: an entry per member, in the column list's order. */
export type StructuredList = {
    readonly start: number;
    readonly end: number;
    readonly entries: readonly string[];
};
/** A structured parameter in insert position and the lists the run time writes again for the keys a call carries. */
export type Structured = {
    readonly name: string;
    readonly lists: readonly StructuredList[];
};
/**
 * Checks a structured parameter's value against its column list, and gives the value to bind:
 * on Postgres the JSON value, which the run time binds as it binds every JSON parameter, and on
 * MySQL and SQLite its JSON text. `inserted` is a parameter whose rows a MySQL insert writes, whose
 * lists the run time writes again, so its keys are the same in every row; `present` is the keys
 * they carry.
 */
export declare function prepareRows(name: string, type: RowsType, value: unknown, dialect: Dialect, inserted: boolean): {
    value: unknown;
    present: ReadonlySet<string>;
};
/**
 * Checks the value of a parameter written `:p::type` on MySQL or SQLite, whose cast turns a value
 * it cannot read into 0 or NULL instead of failing (`CAST('abc' AS SIGNED)` is 0, and SQLite's
 * `CAST('1.9' AS INTEGER)` is 1), against the type as written, before the statement runs; the
 * value is bound as it is. `type` is the engine's type for the parameter. On SQLite every integer
 * is 64 bits, whatever the cast calls it.
 */
export declare function checkCast(name: string, written: string, type: EngineType, v: unknown, dialect: Dialect): void;
/** The statement with each list of a structured parameter written again for the keys present (MySQL): an entry stays when its key is required or present. */
export declare function variant(text: string, structured: Structured, fields: readonly RowField[], present: ReadonlySet<string>): string;
