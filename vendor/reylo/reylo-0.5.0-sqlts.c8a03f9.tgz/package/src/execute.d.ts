import { type Columns } from "./values.ts";
import type { EngineType } from "./engine-type.ts";
import type { JsonSchema } from "./engine-type.ts";
import type { Checks } from "./checks.ts";
import type { Structured } from "./rows.ts";
import { type Fresh } from "./fresh.ts";
export type Dialect = "postgres" | "mysql" | "sqlite";
/**
 * pg's Pool, Client and PoolClient; PGlite and its transactions; Neon's Pool and Client;
 * pg-promise's database, tasks and transactions; @vercel/postgres: query(text, values) → { rows }
 * (pg-promise resolves to the rows themselves, and its types say any).
 */
export type PgQueryClient = {
    query(text: string, values?: any[]): PromiseLike<{
        rows: unknown[];
    }>;
    /** mariadb's query() resolves to any as well; its escapeId() tells it apart. */
    escapeId?: never;
};
/**
 * Neon's neon() function from 1.0: query(text, values) → rows. Its transaction() tells it from
 * mysql2/promise, whose query(text, values) resolves to a [rows, fields] array as well.
 */
export type NeonHttpClient = {
    query(text: string, values?: any[]): PromiseLike<Record<string, unknown>[]>;
    transaction(...args: any[]): unknown;
};
/** postgres.js `sql`, its begin and savepoint transactions and reserved connections; Bun.sql, likewise: unsafe(text, params) → rows. */
export type UnsafeClient = {
    unsafe(text: string, params?: any[]): PromiseLike<unknown[]>;
};
/** Bun.sql on MySQL or SQLite; commitDistributed() tells it from postgres.js, which has unsafe() too. */
export type BunSqlClient = UnsafeClient & {
    commitDistributed(name: string): Promise<unknown>;
};
/** Neon's neon() function before 1.0, which is called with (text, params). */
export type CallableClient = (text: string, params?: any[]) => PromiseLike<unknown[] | {
    rows: unknown[];
}>;
/** Slonik's pool, connections, transactions and savepoints, whose query() takes only its sql tag's queries. */
export type SlonikClient = {
    query(sql: any): PromiseLike<unknown>;
    maybeOneFirst(...args: any[]): unknown;
    anyFirst(...args: any[]): unknown;
};
/**
 * mysql2/promise Pool, Connection and PoolConnection (→ [rows, fields]); PlanetScale's Connection,
 * Client and transaction from 1.x (→ { rows }). PlanetScale 2.0 binds no parameters, so its
 * execute(query, options) is not one of these.
 */
export type MysqlExecuteClient = {
    execute(text: string, values?: any[]): PromiseLike<[unknown, unknown] | {
        rows: unknown[];
        statement: string;
    }>;
};
/** mysql2's callback Pool, Connection and PoolConnection, run through their promise() wrapper. */
export type Mysql2CallbackClient = {
    promise(): MysqlExecuteClient;
};
/** mariadb's Pool, Connection and PoolConnection: query(text, values) → rows, or an OK packet for a write. */
export type MariadbClient = {
    query(text: string, values?: any): Promise<unknown>;
    batch(text: string, values?: any): Promise<unknown>;
};
/** The same from mariadb's callback API (`mariadb/callback`): query(text, values, callback). */
export type MariadbCallbackClient = {
    query(text: string, values: any, callback: (error: Error | null, rows?: any) => void): void;
    batch(text: string, values: any, callback: (error: Error | null, result?: any) => void): void;
};
/**
 * better-sqlite3, node:sqlite's DatabaseSync, bun:sqlite's Database and the Database of Turso's
 * `@tursodatabase/database/compat`, which answer at once: `runSync` takes them and returns the
 * result itself, so it works inside their `db.transaction(fn)`, whose function must not await.
 */
export type SyncSqliteClient = {
    prepare(sql: string): {
        all(...params: any[]): unknown[];
    };
};
/**
 * A SQLite-backed Durable Object's SQL storage, `ctx.storage.sql`: exec(sql, ...values) answers at
 * once with a cursor, so `runSync` takes it, inside `ctx.storage.transactionSync(fn)` too.
 */
export type DurableObjectSql = {
    exec(query: string, ...bindings: any[]): {
        toArray(): unknown[];
    };
    readonly databaseSize: number;
};
/** A Durable Object's storage, `ctx.storage`, which `drizzle-orm/durable-sqlite` keeps: `run` takes its `sql`. */
export type DurableObjectStorage = {
    readonly sql: DurableObjectSql;
};
/** Cloudflare D1's database and sessions: prepare(sql).bind(...values).all() → { results }. */
export type D1Client = {
    prepare(sql: string): {
        bind(...values: any[]): {
            all(): Promise<{
                results: unknown[];
            }>;
        };
    };
};
/** @libsql/client's Client and Transaction: execute({ sql, args }) → { rows }. */
export type LibsqlClient = {
    execute(statement: {
        sql: string;
        args: any[];
    }): Promise<{
        rows: unknown[];
    }>;
    /** mariadb's execute() takes an object with sql and resolves to any; executeMultiple() tells libSQL apart. */
    executeMultiple(sql: string): Promise<unknown>;
};
/**
 * Turso's new engine, `@tursodatabase/database`: the Database `connect()` resolves to and the
 * Transaction `transactionAsync()` hands its callback, whose statements answer through a promise:
 * prepare(sql).all(...values) → rows. Its types say prepare() returns a promise of the statement
 * from 0.6, and the statement itself before; it returns the statement itself in every release.
 */
export type TursoClient = {
    prepare(sql: string): TursoStatement | PromiseLike<TursoStatement>;
    /** postgres.js's transaction has a prepare(name) of any type too; exec() tells Turso's apart. */
    exec(sql: string): Promise<unknown>;
};
type TursoStatement = {
    all(...params: any[]): Promise<unknown[]>;
};
/** The sqlite3 package's callback Database: all(sql, params, callback). */
export type Sqlite3Client = {
    all(sql: string, params: any[], callback: (error: Error | null, rows: any[]) => void): unknown;
};
/** The sqlite package's promise Database: all(sql, params) → rows. */
export type SqlitePromiseClient = {
    all(sql: string, params?: any): Promise<unknown[]>;
    getDatabaseInstance(): unknown;
};
/**
 * A Drizzle database over one of these clients (`drizzle(pool)`, whose `$client` is the pool):
 * `run` runs on the driver client underneath, so the values are what Reylo decodes on that driver.
 */
export type DrizzleDatabase<C> = {
    readonly $client: C;
};
/**
 * A transaction or savepoint a Drizzle database hands out (`db.transaction(async (tx) => …)`),
 * which `run` runs on through the transaction's own connection. Each dialect's is known by what
 * only it has: `setTransaction()` on Postgres, `get()` and `all()` on SQLite, neither on MySQL.
 */
export type DrizzlePgTransaction = {
    rollback(): never;
    setTransaction(config: any): Promise<void>;
};
export type DrizzleMysqlTransaction = {
    rollback(): never;
    execute(query: any): unknown;
    setTransaction?: never;
    get?: never;
};
export type DrizzleSqliteTransaction = {
    rollback(): never;
    get(query: any): unknown;
    all(query: any): unknown;
};
/** A transaction of a synchronous SQLite driver's Drizzle database, whose `all()` returns the rows themselves. */
export type DrizzleSyncSqliteTransaction = {
    rollback(): never;
    get(query: any): unknown;
    all(query: any): unknown[];
};
/** Every Postgres client `run` takes, or a transaction, savepoint or connection taken from one. */
export type PostgresClient = PgQueryClient | NeonHttpClient | UnsafeClient | CallableClient | SlonikClient | DrizzleDatabase<PgQueryClient | NeonHttpClient | UnsafeClient | CallableClient> | DrizzlePgTransaction;
/** Every MySQL client `run` takes, or a transaction or connection taken from one. */
export type MysqlClient = MysqlExecuteClient | Mysql2CallbackClient | MariadbClient | MariadbCallbackClient | BunSqlClient | DrizzleDatabase<MysqlExecuteClient | Mysql2CallbackClient | MariadbClient | BunSqlClient> | DrizzleMysqlTransaction;
/** Every SQLite client `run` takes, or a transaction taken from one. */
export type SqliteClient = SyncSqliteClient | DurableObjectSql | D1Client | LibsqlClient | TursoClient | Sqlite3Client | SqlitePromiseClient | BunSqlClient | DrizzleDatabase<SyncSqliteClient | DurableObjectStorage | D1Client | LibsqlClient | BunSqlClient> | DrizzleSqliteTransaction;
export type ClientFor<D extends Dialect> = D extends "postgres" ? PostgresClient : D extends "mysql" ? MysqlClient : SqliteClient;
/** The clients `runSync` takes: the synchronous SQLite drivers, and none for Postgres or MySQL. */
export type SyncClientFor<D extends Dialect> = D extends "sqlite" ? SyncSqliteClient | DurableObjectSql | DrizzleDatabase<SyncSqliteClient | DurableObjectStorage> | DrizzleSyncSqliteTransaction : never;
export type QueryModule<D extends Dialect = Dialect> = {
    readonly dialect: D;
    /** The statement as written, with Reylo's placeholders (`:id`) left in place: the query's `raw`. */
    readonly sql: string;
    /** Parameter names in placeholder order, so an object of params binds positionally. */
    readonly params: readonly string[];
    /** The statement as the engine compiled it for the database, when a build step ran: the query's `sql`. A query without it is compiled by `compile` below. */
    readonly text?: string | undefined;
    /** The binding order for `text`: one name per placeholder of the rewritten statement. */
    readonly order?: readonly string[] | undefined;
    /** What the analysis found of each parameter, by name (every build step puts it in the module). */
    readonly inputs?: Inputs | undefined;
    /** Each output column's name and kind (src/values.ts), in order: what the run time gives each value (every build step puts it in the module). */
    readonly columns?: Columns | undefined;
    /** Each structured parameter in insert position, with the lists of `text` the run time writes again for the keys a call carries. */
    readonly structured?: readonly Structured[] | undefined;
    /** The catalog facts the statement relied on, checked before it runs (src/fresh.ts). */
    readonly fresh?: Fresh | undefined;
    /** The `.sql` file the module was built from, relative to the project's root, for messages. */
    readonly source?: string | undefined;
    /** The checks of a typed JSON, structured or cast parameter (src/checks.ts), which a build step passes where the statement has one. */
    readonly checks?: Checks | undefined;
};
/**
 * Each parameter by name: `type` is the engine's type for it. The run time reads it where a
 * driver binds a value of one type wrong (an array to a SQL array on postgres.js and Bun.sql, to
 * JSON on pg); a query without it, defined by hand or built before 2026-10-12, binds every value
 * as it is. A typed JSON parameter (wiki/typed-json-params.md) carries its schema beside it, and
 * a parameter cast with `::` on MySQL or SQLite the type as written (src/rows.ts, `checkCast`).
 * `nullable` is false where the statement takes no null for the parameter, which the run time
 * then refuses, given or left out; a query defined by hand without it binds what it is given.
 */
export type Inputs = Readonly<Record<string, {
    readonly type: EngineType;
    readonly schema?: JsonSchema;
    readonly cast?: string;
    readonly nullable?: boolean;
}>>;
/**
 * The parameters: an object keyed by name, or by number for positional placeholders (`$1` and
 * `?` give `{ 1: ..., 2: ... }`, and `params` is `["1", "2"]`). An array is refused, since
 * 2026-10-20 (wiki/design.md §9).
 */
export type ParamsInput = Record<string, unknown>;
/**
 * Runs the statement and returns its rows (an empty array for a statement that returns none).
 * On a synchronous SQLite client the rows come back at once and an error is thrown; on every
 * other client they come back as a promise, which rejects with the driver's own error.
 */
export declare function execute<D extends Dialect>(client: ClientFor<D>, query: QueryModule<D>, params?: ParamsInput): unknown[] | Promise<unknown[]>;
/** The synchronous path alone, for `runSync`: any other client is refused before anything runs. */
export declare function executeSync<D extends Dialect>(client: SyncClientFor<D>, query: QueryModule<D>, params?: ParamsInput): unknown[];
/**
 * A Postgres array literal, written as pg writes one (`arrayString` in pg/lib/utils.js): a nested
 * array in braces, null and undefined as NULL, binary data as `\\x` and its hex, and every other
 * element quoted, with `"` and `\` escaped: a Date as its local time and offset, an object as
 * its JSON, anything else as its string. The elements are separated by `delim`, the element type's
 * delimiter: the server reads `{"a","b"}` as one element of a `geometry[]`, whose delimiter is `:`.
 */
export declare function arrayLiteral(array: readonly unknown[], delim?: string): string;
/**
 * The statement as Reylo sends it to the database, and the parameter each placeholder binds: the
 * engine's compiled text where a build step wrote one into the module. Without it (a query
 * defined by hand) the run time lexes the placeholders itself (`lex.ts`); the engine's lexer is
 * the authoritative one, and the two agree on every statement the fallback is meant for.
 * Postgres numbers each distinct parameter once; MySQL has only `?`, and better-sqlite3 reads
 * SQLite's `?NNN` as a named parameter, so both get one `?` per placeholder and a repeated name is
 * repeated in the binding order.
 */
export declare function compile(query: QueryModule): {
    text: string;
    order: readonly string[];
};
export {};
