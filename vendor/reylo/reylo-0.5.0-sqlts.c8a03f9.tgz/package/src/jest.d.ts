type Options = {
    supportsStaticESM: boolean;
    configString: string;
};
declare function getCacheKey(_source: string, path: string, options: Options): string;
declare function transform(_source: string, path: string, options: Options): {
    code: string;
};
declare const _default: {
    getCacheKey: typeof getCacheKey;
    process: typeof transform;
};
export default _default;
