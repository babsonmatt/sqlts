import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
const PACKAGES = ["@reylosql/postgres", "@reylosql/mysql", "@reylosql/sqlite"];
const VERSION = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8")).version;
let loaded;
export function tooling(from = process.cwd()) {
  if (!loaded) {
    const loading = load(from);
    loading.catch(() => {
      if (loaded === loading)
        loaded = void 0;
    });
    loaded = loading;
  }
  return loaded;
}
export async function releaseConnections() {
  const loading = loaded;
  if (loading)
    await (await loading.catch(() => void 0))?.releaseConnections();
}
async function load(from) {
  let other;
  for (const base of [join(from, "package.json"), import.meta.url]) {
    const require = createRequire(base);
    for (const name of PACKAGES) {
      let path;
      try {
        path = require.resolve(`${name}/tooling`);
      } catch {
        try {
          const manifest = require.resolve(`${name}/package.json`);
          other ??= { name, version: versionAt(manifest), dir: dirname(manifest) };
        } catch {
        }
        continue;
      }
      const version = versionAt(join(dirname(path), "package.json"));
      if (version !== VERSION) {
        other ??= { name, version, dir: dirname(path) };
        continue;
      }
      return require(path).default;
    }
  }
  if (other)
    throw new Error(`reylo ${VERSION} runs with ${other.name} ${VERSION}, and the one installed is ${other.version ?? "of no version"} (${other.dir}): npm install -D ${other.name}@${VERSION}`);
  throw new Error(`reylo's build steps run in a database's engine, and none is installed: npm install -D @reylosql/postgres, @reylosql/mysql or @reylosql/sqlite, the one for your database`);
}
function versionAt(manifest) {
  try {
    return JSON.parse(readFileSync(manifest, "utf8")).version;
  } catch {
    return void 0;
  }
}
