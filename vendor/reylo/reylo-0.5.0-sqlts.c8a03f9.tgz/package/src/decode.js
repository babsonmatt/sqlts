import { coerce, DecodeError, scalarKind, textDecoder, utf8 } from "./values.js";
import { lexPlaceholders } from "./lex.js";
const FIRST_USER_OID = 1e4;
const SCALAR_OIDS = {
  16: "bool",
  17: "bytes",
  20: "int8",
  21: "int",
  23: "int",
  26: "int",
  700: "float",
  701: "float",
  1700: "decimal",
  1082: "date",
  1114: "timestamp",
  1184: "timestamptz",
  1186: "interval",
  114: "json",
  3802: "json"
};
const ARRAY_OIDS = /* @__PURE__ */ new Map([
  [143, 142],
  [199, 114],
  [271, 5069],
  [629, 628],
  [651, 650],
  [719, 718],
  [775, 774],
  [791, 790],
  [1e3, 16],
  [1001, 17],
  [1002, 18],
  [1003, 19],
  [1005, 21],
  [1006, 22],
  [1007, 23],
  [1008, 24],
  [1009, 25],
  [1010, 27],
  [1011, 28],
  [1012, 29],
  [1013, 30],
  [1014, 1042],
  [1015, 1043],
  [1016, 20],
  [1017, 600],
  [1018, 601],
  [1019, 602],
  [1020, 603],
  [1021, 700],
  [1022, 701],
  [1027, 604],
  [1028, 26],
  [1034, 1033],
  [1040, 829],
  [1041, 869],
  [1115, 1114],
  [1182, 1082],
  [1183, 1083],
  [1185, 1184],
  [1187, 1186],
  [1231, 1700],
  [1263, 2275],
  [1270, 1266],
  [1561, 1560],
  [1563, 1562],
  [2201, 1790],
  [2207, 2202],
  [2208, 2203],
  [2209, 2204],
  [2210, 2205],
  [2211, 2206],
  [2949, 2970],
  [2951, 2950],
  [3221, 3220],
  [3643, 3614],
  [3644, 3642],
  [3645, 3615],
  [3735, 3734],
  [3770, 3769],
  [3807, 3802],
  [3905, 3904],
  [3907, 3906],
  [3909, 3908],
  [3911, 3910],
  [3913, 3912],
  [3927, 3926],
  [4073, 4072],
  [4090, 4089],
  [4097, 4096],
  [4192, 4191],
  [5039, 5038],
  [6150, 4451],
  [6151, 4532],
  [6152, 4533],
  [6153, 4534],
  [6155, 4535],
  [6157, 4536]
]);
const BOX_ARRAY = 1020;
function builtin(oid) {
  const scalar = SCALAR_OIDS[oid];
  if (scalar)
    return { kind: scalar, delim: "," };
  const element = ARRAY_OIDS.get(oid);
  if (element !== void 0)
    return { kind: `${SCALAR_OIDS[element] ?? "text"}[]`, delim: oid === BOX_ARRAY ? ";" : "," };
  return oid < FIRST_USER_OID ? { kind: "text", delim: "," } : void 0;
}
const builtinDecoders = /* @__PURE__ */ new Map();
function builtinDecoder(oid) {
  let d = builtinDecoders.get(oid);
  if (d === void 0) {
    const b = builtin(oid);
    if (!b)
      return void 0;
    builtinDecoders.set(oid, d = textDecoder(b.kind, b.delim));
  }
  return d;
}
const learned = /* @__PURE__ */ new WeakMap();
const learnedOf = (key) => {
  let l = learned.get(key);
  if (!l)
    learned.set(key, l = /* @__PURE__ */ new Map());
  return l;
};
const catalogSql = (oids) => {
  const list = `'{${oids.map((o) => Math.trunc(o)).join(",")}}'::pg_catalog.oid[]`;
  return `with recursive d(oid, base) as (
  select oid, typbasetype from pg_catalog.pg_type where typtype = 'd'
  union all
  select d.oid, t.typbasetype from d join pg_catalog.pg_type t on t.oid = d.base where t.typtype = 'd'
)
select e.typarray::int8::text, b.oid::int8::text, (b.typtype = 'c' or b.typcategory = 'A')::text, e.typdelim::text, e.oid::int8::text, b.typname::text
from pg_catalog.pg_type e
join pg_catalog.pg_type b on b.oid = coalesce((select d.base from d join pg_catalog.pg_type t on t.oid = d.base where d.oid = e.oid and t.typtype <> 'd'), e.oid)
where e.typarray = any(${list}) or (e.oid = any(${list}) and e.typcategory <> 'A')`;
};
async function learn(key, oids, load) {
  const known = learnedOf(key);
  const missing = new Set([...oids].filter((oid) => !known.has(oid)));
  if (!missing.size)
    return;
  const rows = await load(catalogSql([...missing]));
  const arrays = /* @__PURE__ */ new Set();
  for (const [array, base, isText, delim, oid, name] of rows) {
    const element = isText === "true" ? void 0 : builtin(Number(base))?.kind ?? (name ? scalarKind(name, "postgres") : "text");
    if (missing.has(Number(array))) {
      arrays.add(Number(array));
      known.set(Number(array), element === void 0 || element.endsWith("[]") ? { kind: "text", delim: "," } : { kind: `${element}[]`, delim: delim ?? "," });
    }
    if (missing.has(Number(oid)) && !arrays.has(Number(oid)))
      known.set(Number(oid), { kind: element ?? "text", delim: "," });
  }
  for (const oid of missing)
    if (!known.has(oid))
      known.set(oid, { kind: "text", delim: "," });
}
async function fieldDecoders(fields, columns, key, load) {
  const byColumn = columns && columns.length === fields.length ? columns : void 0;
  const created = fields.filter((f) => f.oid >= FIRST_USER_OID);
  const known = learnedOf(key);
  if (byColumn)
    created.forEach((f) => known.has(f.oid) || known.set(f.oid, { kind: byColumn[fields.indexOf(f)][1], delim: byColumn[fields.indexOf(f)][2] ?? "," }));
  else if (created.length)
    await learn(key, created.map((f) => f.oid), load);
  return fields.map((f) => {
    const b = builtinDecoder(f.oid);
    if (b)
      return b;
    const k = known.get(f.oid) ?? { kind: "text", delim: "," };
    return textDecoder(k.kind, k.delim);
  });
}
class Pending {
  oid;
  text;
  constructor(oid, text) {
    this.oid = oid;
    this.text = text;
  }
}
const BINARY = /* @__PURE__ */ Symbol("binary");
function pgTypes(key) {
  const known = learnedOf(key);
  let binary = false;
  let pending = false;
  const table = {
    getTypeParser(oid, format) {
      if (format !== void 0 && format !== "text") {
        binary = true;
        return () => BINARY;
      }
      const b = builtinDecoder(oid);
      if (b)
        return b;
      const k = known.get(oid);
      if (k)
        return textDecoder(k.kind, k.delim);
      pending = true;
      return (text) => new Pending(oid, text);
    }
  };
  return { table, sawBinary: () => binary, sawPending: () => pending };
}
const refuseBinary = () => new TypeError(`Reylo cannot read this pg client's results: it was set up with binary: true (or pg.defaults.binary), which pg 8 reads wrong (an int8 comes back as another number). Reylo decodes every value from the server's text; leave binary off.`);
async function pgFamily(key, run, columns, load) {
  const types = pgTypes(key);
  const result = await run(types.table);
  const rows = Array.isArray(result) ? result : result.rows;
  if (types.sawBinary())
    throw refuseBinary();
  if (!types.sawPending())
    return rows;
  if (result.fields && !Array.isArray(result))
    await fieldDecoders(result.fields.map((f) => ({ name: f.name, oid: f.dataTypeID })), columns, key, load);
  const oids = /* @__PURE__ */ new Set();
  for (const row of rows)
    for (const v of Object.values(row))
      if (v instanceof Pending)
        oids.add(v.oid);
  await learn(key, oids, load);
  const known = learnedOf(key);
  const decoders = new Map([...oids].map((oid) => [oid, textDecoder(known.get(oid).kind, known.get(oid).delim)]));
  for (const row of rows) {
    for (const name in row) {
      const v = row[name];
      if (v instanceof Pending)
        row[name] = decoders.get(v.oid)(v.text);
    }
  }
  return rows;
}
const asText = { getTypeParser: () => (x) => x };
export async function queryPostgres(c, text, values, columns) {
  if (typeof c.manyOrNone === "function")
    return pgPromise(c, text, values, columns);
  if (typeof c.getTypeParser === "function") {
    if (c.binary === true)
      throw refuseBinary();
    const load = async (sql) => (await c.query({ text: sql, rowMode: "array", types: asText })).rows;
    return pgFamily(c, (types) => c.query({ text, values, types }), columns, load);
  }
  if (isPglite(c))
    return pglite(c, text, values, columns);
  if (typeof c.connect === "function" && typeof c.Client === "function") {
    if (c.options?.binary === true)
      throw refuseBinary();
    const load = async (sql) => (await c.query({ text: sql, rowMode: "array", types: asText })).rows;
    return pgFamily(c, (types) => c.query({ text, values, types }), columns, load);
  }
  if (typeof c.transaction === "function") {
    const load = async (sql) => (await c.query(sql, [], { arrayMode: true, fullResults: true, types: asText })).rows;
    return pgFamily(c, (types) => c.query(text, values, { fullResults: true, arrayMode: false, types }), columns, load);
  }
  const result = await c.query(text, values);
  return Array.isArray(result) ? result : result.rows;
}
async function pgPromise(db, text, values, columns) {
  if (typeof db.$config?.options?.receive === "function")
    throw refuseReceive();
  const run = (query) => typeof db.result === "function" ? db.result(query) : db.query(query);
  const load = async (sql) => {
    const r = await run({ text: sql, rowMode: "array", types: asText });
    return Array.isArray(r) ? r : r.rows;
  };
  const rows = await pgFamily(db, (types) => run({ text, values, types }), columns, load);
  const first = rows[0];
  if (first && columns && columns.length && !columns.every(([name]) => Object.prototype.hasOwnProperty.call(first, name)))
    throw refuseReceive();
  return rows;
}
const refuseReceive = () => new TypeError(`Reylo cannot run on this pg-promise database: its receive event rewrites every result, Reylo's rows too, so they would not have the types the query declares. Run Reylo's queries on a database initialized without receive (pgp({ ... }) with no receive), or on its pool (db.$pool).`);
export function neonCallable(c, text, values, columns) {
  const load = async (sql) => (await c(sql, [], { arrayMode: true, fullResults: true, types: asText })).rows;
  return pgFamily(c, (types) => c(text, values, { fullResults: true, arrayMode: false, types }), columns, load);
}
const isPglite = (c) => typeof c.query === "function" && typeof c.exec === "function" && (typeof c.refreshArrayTypes === "function" || typeof c.rollback === "function" && "closed" in c);
const pgliteOids = /* @__PURE__ */ new Map();
const PGLITE_STATEMENTS = 2e3;
const builtinOids = [...Object.keys(SCALAR_OIDS).map(Number), ...ARRAY_OIDS.keys()];
const keepText = (x) => x;
async function pglite(db, text, values, columns) {
  let named = pgliteOids.get(text);
  const oids = named ?? /* @__PURE__ */ new Set([...builtinOids, ...Object.keys(db.parsers ?? {}).map(Number)]);
  const parsers = {};
  for (const oid of oids)
    parsers[oid] = builtinDecoder(oid) ?? keepText;
  const result = await db.query(text, values, { rowMode: "object", parsers });
  const rows = result.rows;
  const fields = (result.fields ?? []).map((f) => ({ name: f.name, oid: f.dataTypeID }));
  const after = fields.map((f, i) => [f, i]).filter(([f]) => f.oid >= FIRST_USER_OID || !oids.has(f.oid));
  if (after.length) {
    const load = async (sql) => (await db.query(sql, [], { rowMode: "array", parsers: { 25: keepText } })).rows;
    const decoders = await fieldDecoders(fields, columns, db, load);
    const kinds = fields.map((f, i) => columns && columns.length === fields.length ? columns[i][1] : builtin(f.oid)?.kind ?? learnedOf(db).get(f.oid)?.kind ?? "text");
    for (const [f, i] of after) {
      const decode = decoders[i];
      for (const row of rows) {
        const v = row[f.name];
        if (v !== null && v !== void 0)
          row[f.name] = typeof v === "string" ? decode(v) : coerce(kinds[i], v, f.name);
      }
    }
  }
  if (!named || fields.some((f) => !named.has(f.oid))) {
    if (pgliteOids.size >= PGLITE_STATEMENTS)
      pgliteOids.clear();
    pgliteOids.set(text, named = /* @__PURE__ */ new Set([...named ?? [], ...fields.map((f) => f.oid)]));
  }
  return rows;
}
const textOf = utf8;
export async function postgresJs(c, text, params, columns) {
  const pending = c.unsafe(text, params, { prepare: true });
  if (typeof pending?.raw !== "function")
    return bunRows(await pending, columns);
  const raw = await pending.raw();
  const fields = (raw.columns ?? []).map((f) => ({ name: f.name, oid: f.type }));
  if (!raw.length)
    return [];
  for (const row of raw) {
    if (!Array.isArray(row) || row.length !== fields.length || !row.every((v) => v === null || v instanceof Uint8Array)) {
      throw new TypeError(`Reylo cannot read this postgres.js client's rows: its transform.row rewrites every row, Reylo's too, so they would not have the types the query declares. Run Reylo's queries on a postgres() instance without transform.row.`);
    }
  }
  const load = async (sql) => (await c.unsafe(sql).raw()).map((r) => r.map((v) => v === null ? null : textOf(v)));
  const decoders = await fieldDecoders(fields, columns, c, load);
  const names = columns && columns.length === fields.length ? columns.map(([name]) => name) : fields.map((f) => f.name);
  const n = names.length;
  const out = new Array(raw.length);
  for (let r = 0; r < raw.length; r++) {
    const values = raw[r];
    const row = {};
    for (let i = 0; i < n; i++) {
      const v = values[i];
      row[names[i]] = v === null || v === void 0 ? null : decoders[i](textOf(v));
    }
    out[r] = row;
  }
  return out;
}
const BUN_KINDS = /^(bool|int8|date|timestamp|timestamptz|interval|bytes|vector|hstore)$|\[\]$|\|/;
export function bunRows(rows, columns) {
  if (!Array.isArray(rows) || !rows.length)
    return Array.isArray(rows) ? rows : [];
  const first = rows[0];
  const work = columns ? columns.filter(([, kind]) => BUN_KINDS.test(kind)) : Object.keys(first).map((name) => [name, "unknown"]);
  if (!work.length)
    return rows;
  for (const row of rows) {
    for (const [name, kind, delim] of work) {
      const v = row[name];
      if (v === null || v === void 0)
        continue;
      row[name] = kind === "unknown" ? byType(v, name) : bunValue(kind, v, name, delim);
    }
  }
  return rows;
}
function bunValue(kind, v, name, delim) {
  if (typeof v === "string" && kind.includes("|") && kind.split("|").includes("int8") && /^[+-]?\d+$/.test(v))
    return BigInt(v);
  return coerce(kind, v, name, delim);
}
function byType(v, name) {
  if (v instanceof Date)
    return coerce("timestamptz", v, name);
  if (ArrayBuffer.isView(v) && !(v instanceof Uint8Array) && !(v instanceof DataView))
    return coerce("float[]", v, name);
  return v;
}
const SLONIK_TEXT = [
  "bool",
  "bytea",
  "int2",
  "int4",
  "int8",
  "oid",
  "float4",
  "float8",
  "numeric",
  "money",
  "date",
  "timestamp",
  "timestamptz",
  "interval",
  "json",
  "jsonb",
  "point",
  "circle",
  "int4range",
  "int8range",
  "numrange",
  "tsrange",
  "tstzrange",
  "daterange"
];
const SLONIK_STRICT = /^(decimal|date|timestamp|timestamptz|interval)(\[\])*$/;
let slonikModule;
const slonikTags = /* @__PURE__ */ new Map();
function loadSlonik() {
  if (slonikModule)
    return slonikModule;
  const proc = globalThis.process;
  const createRequire = proc?.getBuiltinModule?.("node:module")?.createRequire;
  if (!proc || !createRequire)
    throw new TypeError(`Reylo runs a query on Slonik with a sql tag from the app's own slonik package, which it loads through Node's process.getBuiltinModule, and this runtime has none.`);
  let failure;
  for (const from of [proc.argv?.[1], `${proc.cwd()}/`]) {
    if (!from)
      continue;
    try {
      return slonikModule = createRequire(from)("slonik");
    } catch (e) {
      failure = e;
    }
  }
  throw new TypeError(`Reylo runs a query on Slonik with a sql tag from the app's own slonik package, which it could not load (a server that is bundled keeps slonik external, so that it loads from node_modules at run time): ${failure.message}`);
}
function slonikTag(c) {
  const { createSqlTag } = loadSlonik();
  const own = (c.configuration ?? c.clientConfiguration)?.typeParsers?.map((p) => p.name) ?? [];
  const names = [.../* @__PURE__ */ new Set([...SLONIK_TEXT, ...own])];
  const key = names.join(",");
  let tag = slonikTags.get(key);
  if (tag === void 0)
    slonikTags.set(key, tag = createSqlTag({ typeParsers: names.map((name) => ({ name, parse: (value) => value })) }));
  return tag;
}
function slonikTemplate(text, values) {
  const { params, placeholders } = lexPlaceholders(text, "postgres");
  if (placeholders.length > params.length) {
    throw new TypeError(`Reylo cannot run this statement on Slonik: it uses a parameter more than once, and Slonik's sql tag binds each use on its own, so the server would type each one separately. Use each parameter once, and select it in a with to read it twice.`);
  }
  const strings = [];
  let last = 0;
  for (const p of placeholders) {
    strings.push(text.slice(last, p.start));
    last = p.end;
  }
  strings.push(text.slice(last));
  const template = Object.freeze(Object.assign(strings, { raw: Object.freeze([...strings]) }));
  return [template, placeholders.map((p) => values[Number(p.name) - 1])];
}
export async function slonik(c, text, values, columns) {
  const interceptors = (c.configuration ?? c.clientConfiguration)?.interceptors;
  if (interceptors?.some((i) => typeof i?.transformRow === "function" || typeof i?.transformRowAsync === "function"))
    throw refuseSlonikRows();
  const tag = slonikTag(c);
  const [template, ordered] = slonikTemplate(text, values);
  const query = tag.unsafe(template, ...ordered);
  if (query.typeParsers === void 0) {
    throw new TypeError(`Reylo cannot run on this Slonik: its sql tag takes no type parsers per query (createSqlTag's typeParsers option), so its pool's parsers would turn numeric, timestamp and interval values into lossy numbers. Upgrade slonik to 49.12.0 or later.`);
  }
  const result = await c.query(query);
  return slonikRows(result.rows, result.fields, columns);
}
function slonikRows(rows, fields, columns) {
  if (!rows.length)
    return rows;
  const work = columns ?? fields.map((f) => {
    const b = builtin(f.dataTypeId);
    return b ? [f.name, b.kind, b.delim] : [f.name, "text"];
  });
  for (const row of rows) {
    for (const [name, kind, delim] of work)
      row[name] = slonikValue(kind, row[name], name, delim);
  }
  return rows;
}
function slonikValue(kind, v, name, delim) {
  if (v === null || v === void 0)
    return null;
  if (typeof v === "string")
    return textDecoder(kind, delim)(v);
  if (Array.isArray(v) && kind.endsWith("[]"))
    return v.map((e) => Array.isArray(e) ? slonikValue(kind, e, name, delim) : slonikValue(kind.slice(0, -2), e, name, delim));
  if (SLONIK_STRICT.test(kind)) {
    throw new DecodeError(`Column "${name}" reached Reylo already converted by Slonik's driver (${v instanceof Date ? "a Date" : typeof v}), which ignored the query's type parsers, as a custom driverFactory may: Reylo refuses it rather than return a value that may have been rounded.`);
  }
  return coerce(kind, v, name, delim);
}
const refuseSlonikRows = () => new TypeError(`Reylo cannot run on this Slonik client: one of its interceptors rewrites every row (transformRow or transformRowAsync, such as slonik-interceptor-field-name-transformation), Reylo's too, so they would not have the columns the query declares. Run Reylo's queries on a pool made without that interceptor.`);
export { DecodeError, parseArray } from "./values.js";
